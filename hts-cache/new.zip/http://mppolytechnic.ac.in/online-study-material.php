<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>MP POLYTECHNIC - GORAKHPUR U.P. INDIA</title>
<link rel="shortcut icon" href="images/favicon.ico">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="author" content="www.mppolytechnic.ac.in">

<meta name="description" content=" Maharana Pratap Polytechnic Gorakhpur (UP) India is Aided Polytechnic Affiliated to Board of Technical education Uttar Pradesh and approved By AICTE which provides Diploma in Engineering in Mechanical,Civil,Electrical,Computer Science, Electronics and Architectural Assitantship  established in 1956." data-react-helmet="true" />

<meta name="keywords" content="mppolytechnic,mppolytechnic gorakhpur,Maharana Pratap Polytechnic Gorakhpur (UP),Aided Polytechnic in Uttar Pradesh, Diploma in computer Science|Electronics Engineering | Electrical enginnering | Mechanical engineering | Civil engineering, Board of Technical Education, Polytechnic in Gorakhpur,List of Polytechnic in Uttar Pradesh " data-react-helmet="true" />

<meta name="geo.region" content="IN-UP" />
<meta name="geo.placename" content="MP Polytechnic GORAKHPUR" />
<meta name="geo.position" content="22.351115;78.667743" />
<meta name="ICBM" content="22.351115, 78.667743" />



<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" media="all">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
<link href="css/animate.min.css" rel="stylesheet" type="text/css" media="all">
  <!-- Bootstrap core CSS-->
  <!-- <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet"> -->
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

   <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>
        <script src="js/sb-admin-datatables.min.js"></script>
        <!-------------------datepicker js-------->

  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 <!-- <link rel="stylesheet" href="/resources/demos/style.css">-->

  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<!--------------------------------------------------------------------------->


 <style>

.card:hover {
  box-shadow: 0 20px 20px rgba(0, 0, 0, 0.19), 0 6px 6px rgba(0, 0, 0, 0.23);
  
}
.card{
background:#feeeb7a8;
}

</style>


<!------------------->
<style>
#mainav a{
text-decoration:none;
}
*{
font-family: 'Work Sans', sans-serif;
margin:0px;
padding:0px;
}
#phone{
font-size:16px;
}
@media (max-width: 991px){
#gov {
display:none;
 
	}
	}
</style>
<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.HORIZONTAL}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>


</head>

<body id="top">

<div class="wrapper row0">
  <div id="topbar" class="hoc clear"> 
   
    <div class="fl_left">
      <ul class="nospace inline pushright">
   <li><i class="fa fa-envelope-o" style="color:#FFFF33;font-size:20px;"></i> <span style="font-size:20px;">mppolygorakhpur@rediffmail.com</span></li>
       <!--<li><i class="fa fa-phone" style="color:#3a9fe5;font-size:20px;"></i> <span style="font-size:20px;">+91 888 766 7635</span></li>
       <li><strong>A GOVERNMENT POLYTECHNIC (U.P) INDIA</strong></li>-->
               <li> <div id="google_translate_element"></div></li>

         
      </ul>
    </div>
    <div class="fl_right">
      <ul class="faico clear">
        <li><i class="fa fa-phone" style="color:#FFFF33;font-size:20px;"></i> <span style="font-size:20px;">0551 2255551</span></li>
    </ul>
    </div>
    
  </div>
</div>

<!-- <nav class="navbar  navbar-expand-lg  navbar-dark bg-primary sticky-top">
<a href="index.php" class="navbar-brand" >MAHARANA PRATAP POLYTECHNIC</a>

<button type="button"  class="navbar-toggler" data-toggle="collapse" data-target="#menubar"><span class="navbar-toggler-icon"></span></button>



<div id="menubar" class="collapse navbar-collapse">
<ul class="navbar-nav">
<li class="nav-item"><a href="index.php" class="nav-link active">Dashboard</a></li>
<li class="nav-item"><a href="registration.php" class="nav-link  active">Registration</a></li>


<li class="nav-item dropdown active"><a href="#" class="nav-link dropdown-toggle " data-toggle="dropdown"> Library Book Details</a>
<div class="dropdown-menu">
     <a class="dropdown-item"  href="library-search-books.php" > Search Library Book Details</a>
  <a class="dropdown-item"  href="library-books-transactions.php" >View  Library Book Transactions</a>
</div>
</li>
<li class="nav-item"><a href="notes-search.php" class="nav-link  active">View Study Material </a></li>
<li class="nav-item"><a href="change-password.php" class="nav-link  active">Change Password</a></li>


</ul>

<ul  class="navbar-nav ml-auto " >

<li class="nav-item active"><a class="nav-link text-light" href="Subject.php">Add Subject</a> </li>
      <li class="nav-item active"><a class="nav-link text-light" href="Test.php">Add Test</a> </li>
       <li class="nav-item active"><a class="nav-link text-light" href="Question.php">Insert Question</a></li>

      <li class="nav-item active"><a class="nav-link text-light" href="viewData.php">View Question</a></li>

  

<li class="nav-item">
<a class="nav-link  active" href="logout.php">Logout</a>
</li>

</ul>
</div>
</nav> -->
<!-- ################################################################################################ -->

<div class="wrapper row1">
  <header id="header"> 
 
    <div  class="row" id="logo" >
    <div class="col-lg-8 col-12">
      <a href="index.php"><img src="images/new-mpp.png" class="img-fluid"></a>
    </div>
    
    <div class="col-lg-4 col-12" id="gov">
    
      <a href="#" target="_blank"><img src="images/logo/mahant-circle.png" class="img-fluid"></a>


         </div>
         
    <!--<div class="col-lg-2 col-6" >
          <a href="https://swachhbharatmission.gov.in" target="_blank" ><img src="images/logo/swach-bharat-logo.png" class="img-fluid"></a>    </div>-->
   
 </div>
 
   
  </header>
</div>
<!-- ################################################################################################ -->


<nav class="navbar  navbar-expand-lg  sticky-top row2" >
   <a class="navbar-brand" href="index.php" style="color:#FFFFFF;"><i class="fa fa-institution"></i> </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"><i class="fa fa-navicon"></i></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav" style="color:#FFFFFF;"> 
    <ul class="navbar-nav">
    <li class="nav-item active">
      <a class="nav-item nav-link active" href="index.php" style="color:#FFFFFF;">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="about-us.php" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          About Us
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="about-us.php">About Institute</a>
          <a class="dropdown-item" href="mission-vision.php">Mission &#038; Vision</a>
          <a class="dropdown-item" href="principal-msg.php">Principal’s Message</a>
          <a class="dropdown-item" href="#">Rules and Regulations</a>
          <a class="dropdown-item" href="#">Infrastructure</a>
          
        </div>
      </li>
            <li class="nav-item dropdown">
                  <!--     <a class="nav-item nav-link active" href="commitee.php" style="color:#FFFFFF;">Governance</span></a>-->
  <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Governance
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="chairman.php">List of Chairman</a>
          <a class="dropdown-item" href="List-of-principal.php">List of Principal</a>
          <a class="dropdown-item" href="commitee.php">List of Committee</a>
       </div>
   <!--  <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Governance
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="principal-msg.php">Principal</a>
          <a class="dropdown-item" href="commitee.php">Academic Committee</a>
          <a class="dropdown-item" href="finance-commitee.php">Finance Committee</a>
          <a class="dropdown-item" href="aicte-commitee.php">AICTE Committee</a>
          <a class="dropdown-item" href="scholarship-commitee.php">Scholarship Committee</a>
          <a class="dropdown-item" href="sport-commitee.php">Sports Committee</a>
          <a class="dropdown-item" href="proctorial-commitee.php">Proctorial Committee</a>
          <a class="dropdown-item" href="security-commitee.php">Security &amp; Gardening Committee</a>
          <a class="dropdown-item" href="tnp-commitee.php">Training &#038; Placement Committee</a>
       </div>-->
      </li>
        <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          AICTE
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            


     <a href="attachment/EOA_AICTE/EOA_Report_2019-20.PDF" target="_blank" class="dropdown-item">EOA Letter</a>

           <a class="dropdown-item" href="#"></a>
       </div>
      </li>
      <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Academics
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="academic-programmes.php">Academic Programmes</a>
          
          <a class="dropdown-item" href="syllabus.php">Syllabus</a>
          <a class="dropdown-item" href="admission.php">Admissions</a>
          <a class="dropdown-item" href="fee-structure.php">Fees Structure</a>
           


        </div>
      </li>
     

      <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Departments
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
        <a class="dropdown-item" href="civil-department.php">Civil Engineering</a>
         <a class="dropdown-item" href="electrical-department.php">Electrical Engineering</a>
          <a class="dropdown-item" href="mechanical-department.php">Mechanical (Production)</a>
           <a class="dropdown-item" href="mechanical-cad-department.php">Mechanical (CAD)</a>
         <a class="dropdown-item" href="computer-science-department.php">Computer Science &amp; Engineering</a>
           <a class="dropdown-item" href="electronics-department.php">Electronics Engineering</a>
             <a class="dropdown-item" href="architecture-department.php">Architectural Assistantship</a>
          
                    <a class="dropdown-item" href="marketing-sales-management.php">Marketing &amp; Sales Management</a>

      
          
        </div>
      </li>
    
      <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Training &#038; Placement
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
        <a class="dropdown-item" href="#">Training Statistics</a>
          <a class="dropdown-item" href="#">Placement Statistics</a>
          <a class="dropdown-item" href="single-student-placement.php">Placed Students Details</a>
          <a class="dropdown-item" href="#">Recruiting Partners</a>
         
        </div>
      </li>
     
      <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Facilities &#038; Resources
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="hostel.php">Hostels</a>
          <a class="dropdown-item" href="library.php">Central Library</a>
          <a class="dropdown-item" href="sport.php">Sport &#038; Atheletics</a>
          <a class="dropdown-item" href="seminar.php">Auditorium &#038; Seminar Halls</a>
           <a class="dropdown-item" href="power.php">24*7 Power Supply</a>
          
        </div>
      </li>
    
     <!-- <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Alumni
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="alumni.php">Alumni Registration</a>
       </div>
      </li>
      <li class="nav-item active">
      <a class="nav-item nav-link" href="alumni.php" style="color:#FFFFFF;">Alumni</span></a>
      </li>-->
      
      <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="contact-us.php" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Contact us
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="contact-us.php">Address</a>
          <a class="dropdown-item" href="map-location.php">Maps &#038; Location</a>
          <a class="dropdown-item" href="phone-directory.php">Phone Directory</a>
          <a class="dropdown-item" href="feedback.php" role="tab" aria-controls="settings">Feedback / Query</a>
       </div>
      </li>
   </ul>
    </div>
  </div>
</nav>


<div>
    
    


    
    </div>







<div class="container-fluid" style="margin-top:50px;">
<div class="row">
<div class="col-sm-12 ">
<div class="card alert alert-warning">
<div class="card-header alert alert-primary">
<center><h6>Search Study Materials</h6></center>
</div>
<div class="card-body">
<!-- Example DataTables Card-->
      
        <div class="card-body">
  
                            <!--  -->
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                <th>Added by Teacher</th>	
              
                <th>Subject Name</th>
                <th>Branch</th>
                <th>Semester</th><th>Chapter Name</th>
			        				<th>Topic Name</th>
			        				<th>Video Lecture Link</th>
			        				<th>View Notes</th>
                </tr>
              </thead>
           
              <tbody> 
           
			        						<tr>
			        						    <td>PREM PRAKASH SINGH</td>

			        							<td>TRANSMISSION AND DISTRIBUTION OF ELECTRICAL POWER</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>GENERATION AND DRISTIBUTION</td>
			        							<td>EARTHING</td>                                              <td><a href='https://youtu.be/8pbZXeeNMec' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>YASH RAJ</td>

			        							<td>COMMUNICATION SKILL-II</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>Ch-3</td>
			        							<td>CONJUNCTION (INTRODUCTION)</td>                                              <td><a href='https://youtu.be/G0-mKjU1NoY' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>JOGENDRA KUMAR</td>

			        							<td>APPLIED MATHEMATICS II</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>Circle</td>
			        							<td>Chord  and diameter related</td>                                              <td><a href='https://youtu.be/OnNybtQ892A' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS226classpdf06-01-20201324031.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>JOGENDRA KUMAR</td>

			        							<td>APPLIED MATHEMATICS II</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>Circle</td>
			        							<td>Chord and diameter related</td>                                              <td><a href='https://youtu.be/OnNybtQ892A' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS398classpdf06-01-20201324031.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>JOGENDRA KUMAR</td>

			        							<td>APPLIED MATHEMATICS II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Circle</td>
			        							<td>Chord and diameter related</td>                                              <td><a href='https://youtu.be/OnNybtQ892A' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS20classpdf06-01-20201324031.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>JOGENDRA KUMAR</td>

			        							<td>Applied  Mathematics - II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Circle</td>
			        							<td>Chord and diameter related</td>                                              <td><a href='https://youtu.be/OnNybtQ892A' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS747classpdf06-01-20201324031.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>JOGENDRA KUMAR</td>

			        							<td>APPLIED MATHEMATICS II</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>Circle</td>
			        							<td>Chord and diameter related</td>                                              <td><a href='https://youtu.be/OnNybtQ892A' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS108classpdf06-01-20201324031.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>NAVEEN KUMAR RAO</td>

			        							<td>HYDRAULICS AND PNEUMATICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>FLOW OF FLUIDS</td>
			        							<td>BERNOULLIS THEOREM</td>                                              <td><a href='https://youtu.be/CPdvS8UDbsA' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>NAVEEN KUMAR RAO</td>

			        							<td>HYDRAULICS AND PNEUMATICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>FLOW OF FLUIDS</td>
			        							<td>VENTURI METER </td>                                              <td><a href='https://youtu.be/TQcBY5Xpo0g' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>NAVEEN KUMAR RAO</td>

			        							<td>HYDRAULICS AND PNEUMATICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>FLOW OF FLUIDS</td>
			        							<td>PITOT TUBE</td>                                              <td><a href='https://youtu.be/Hd3Dpst8xuI' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>NAVEEN KUMAR RAO</td>

			        							<td>HYDRAULICS AND PNEUMATICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>FLOW THROUGH PIPES</td>
			        							<td>DARCY EQUATION</td>                                              <td><a href='https://youtu.be/a1RvvygRqDI' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>NAVEEN KUMAR RAO</td>

			        							<td>HYDRAULICS AND PNEUMATICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>FLOW THROUGH PIPES</td>
			        							<td>darcy equation ( numerical)</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC771NewDoc04-02-2020122252.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRATIKSHA AGARWAL</td>

			        							<td>ENERGY CONSERVATION</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Waste heat recovery and co-generation</td>
			        							<td>Waste heat recovery</td>                                              <td><a href='https://youtu.be/SMZuEeQFVcY' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EE534IMG20200601123146.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRATIKSHA AGARWAL</td>

			        							<td>ENERGY CONSERVATION</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Lighting systems</td>
			        							<td>Basic definitions</td>                                              <td><a href='https://youtu.be/d9bG0VSftgE' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EE306lightingsystems.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>NAVEEN KUMAR RAO</td>

			        							<td>HYDRAULICS AND PNEUMATICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Introduction to oil power hydraulics and pneumatics</td>
			        							<td>Pascal Law</td>                                              <td><a href='https://youtu.be/Qldl0mkW-g4' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Antonyms </td>
			        							<td>Antonyms1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS437Screenshot20200601-164332CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Antonyms </td>
			        							<td>Antonyms1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS519Screenshot20200601-164332CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Antonyms </td>
			        							<td>Antonyms1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS793Screenshot20200601-164332CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Antonyms </td>
			        							<td>Antonyms1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS789Screenshot20200601-164332CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>Antonyms </td>
			        							<td>Antonyms1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS589Screenshot20200601-164332CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Antonyms </td>
			        							<td>Antonyms1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS704Screenshot20200601-164335CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Antonyms </td>
			        							<td>Antonyms1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS430Screenshot20200601-164337CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Antonyms </td>
			        							<td>Antonyms1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS283Screenshot20200601-164337CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Antonyms </td>
			        							<td>Antonyms1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS824Screenshot20200601-164337CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Antonyms </td>
			        							<td>Antonyms1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS408Screenshot20200601-164337CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>Antonyms </td>
			        							<td>Antonyms1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS592Screenshot20200601-164337CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Antonyms </td>
			        							<td>Antonyms1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS207Screenshot20200601-164335CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Antonyms </td>
			        							<td>Antonyms1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS471Screenshot20200601-164335CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Antonyms </td>
			        							<td>Antonyms1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS366Screenshot20200601-164335CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Antonyms </td>
			        							<td>Antonyms1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS316Screenshot20200601-164335CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>Antonyms </td>
			        							<td>Antonyms1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS405Screenshot20200601-164335CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>NAVEEN KUMAR RAO</td>

			        							<td>HYDRAULICS AND PNEUMATICS</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>FLOW OF FLUIDS</td>
			        							<td>BERNOULLIS THEOREM</td>                                              <td><a href='https://youtu.be/CPdvS8UDbsA' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>NAVEEN KUMAR RAO</td>

			        							<td>HYDRAULICS AND PNEUMATICS</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>FLOW OF FLUIDS</td>
			        							<td>venturi meter</td>                                              <td><a href='https://youtu.be/TQcBY5Xpo0g' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>NAVEEN KUMAR RAO</td>

			        							<td>HYDRAULICS AND PNEUMATICS</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>FLOW OF FLUIDS</td>
			        							<td>PITOT TUBE</td>                                              <td><a href='https://youtu.be/Hd3Dpst8xuI' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>NAVEEN KUMAR RAO</td>

			        							<td>HYDRAULICS AND PNEUMATICS</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Flow through pipes</td>
			        							<td> Darcy equation</td>                                              <td><a href='https://youtu.be/a1RvvygRqDI' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>NAVEEN KUMAR RAO</td>

			        							<td>HYDRAULICS AND PNEUMATICS</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Introduction to oil power hydraulics and pneumatics</td>
			        							<td>Pascal Law</td>                                              <td><a href='https://youtu.be/Qldl0mkW-g4' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>NAVEEN KUMAR RAO</td>

			        							<td>BASICS OF MECHANICAL AND ELECTRICAL ENGINEERING</td>
			        							<td>Civil Engineering</td>
			        							<td>2</td>
			        							<td>Sources of energy</td>
			        							<td> nuclear power plant</td>                                              <td><a href='https://youtu.be/4TOf8cNtbvk' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>PRATIKSHA AGARWAL</td>

			        							<td>BASICS OF ELECTRICAL AND ELECTRONICS ENGINEERING</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>DC circuits</td>
			        							<td>Ohm ka niyam</td>                                              <td><a href='https://youtu.be/XaNJE2ivzvg' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EE544ohmlaw.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAVESH KUMAR CHAUHAN</td>

			        							<td>E COMMERCE AND DIGITAL MARKETING</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Search Engine Optimization Unit 4</td>
			        							<td>Search Engine Optimization (SEO)</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS866seo-ebook.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAVESH KUMAR CHAUHAN</td>

			        							<td>E COMMERCE AND DIGITAL MARKETING</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Search Engine Optimization Unit 4</td>
			        							<td>Search Engine Optimization (SEO)</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS442seo-ebook.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAVESH KUMAR CHAUHAN</td>

			        							<td>E COMMERCE AND DIGITAL MARKETING</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Search Engine Optimization Unit 4</td>
			        							<td>SEO guidelines for content writers for better rankings</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS151SEOguidelinesforcontentwritersforbetterrankings.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAVESH KUMAR CHAUHAN</td>

			        							<td>E COMMERCE AND DIGITAL MARKETING</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Search Engine Optimization Unit 4</td>
			        							<td>SEO Keywords</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS399WhatAreSEOKeywords.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAVESH KUMAR CHAUHAN</td>

			        							<td>E COMMERCE AND DIGITAL MARKETING</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Search Engine Optimization Unit 4</td>
			        							<td>Search Engine Optimization (SEO)</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS460SEOcompletenotes.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAVESH KUMAR CHAUHAN</td>

			        							<td>E COMMERCE AND DIGITAL MARKETING</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Search Engine Optimization Unit 4</td>
			        							<td>Structuring SEO URLs Correctly</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS963StructuringSEOURLsCorrectly.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAVESH KUMAR CHAUHAN</td>

			        							<td>E COMMERCE AND DIGITAL MARKETING</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Search Engine Optimization Unit 4</td>
			        							<td>Site Structure That Will Enhance SEO</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS37SiteStructureThatWillEnhanceSEO.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAVESH KUMAR CHAUHAN</td>

			        							<td>E COMMERCE AND DIGITAL MARKETING</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Search Engine Optimization Unit 4</td>
			        							<td>Localized SEO</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS332LocalizedSEO.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAVESH KUMAR CHAUHAN</td>

			        							<td>E COMMERCE AND DIGITAL MARKETING</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Search Engine Optimization Unit 4</td>
			        							<td>Website Speed</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS632PageSpeed.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>CONCEPT OF PROGRAMMING USING C</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Pointer</td>
			        							<td>Introduction to Pointers</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS223-03-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AKHILESH TRIVEDI</td>

			        							<td>BASICS OF MECHANICAL AND ELECTRICAL ENGINEERING E</td>
			        							<td>Civil Engineering</td>
			        							<td>2</td>
			        							<td>Types of power plants</td>
			        							<td>Thermal power plant</td>                                              <td><a href='https://youtu.be/I78kuGIIHaU' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>CONCEPT OF PROGRAMMING USING C</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Pointers</td>
			        							<td>Operators that are used with Pointers</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS52024-03-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>CONCEPT OF PROGRAMMING USING C</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Pointers</td>
			        							<td>Pointer Arithmetic</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS34925-03-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>CONCEPT OF PROGRAMMING USING C</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Pointers</td>
			        							<td>Array of Pointers</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS7526-03-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>CONCEPT OF PROGRAMMING USING C</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Pointers</td>
			        							<td>Pointers to Function</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS83927-03-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>CONCEPT OF PROGRAMMING USING C</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Pointers</td>
			        							<td>Pointers Example</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS38828-03-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>CONCEPT OF PROGRAMMING USING C</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Pointers</td>
			        							<td>Pointers Static & Dynamic memory allocation</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS66529-03-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>CONCEPT OF PROGRAMMING USING C</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>File Handling</td>
			        							<td>Introduction to File Handling</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS131-03-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>CONCEPT OF PROGRAMMING USING C</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>File Handling</td>
			        							<td>C-File system Function</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS86002-04-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>CONCEPT OF PROGRAMMING USING C</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Control Structure</td>
			        							<td>(Loop) Print half pyramid using *</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS52801-04-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>CONCEPT OF PROGRAMMING USING C</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Control Structure</td>
			        							<td>(Loop)  Print half pyramid using alphabets</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS65203-04-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>CONCEPT OF PROGRAMMING USING C</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Control Structure</td>
			        							<td>(For Loop) Print full pyramid using *</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS80406-04-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>CONCEPT OF PROGRAMMING USING C</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Array</td>
			        							<td>Add Two Matrices Using Multi-dimensional Arrays</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS56007-04-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>CONCEPT OF PROGRAMMING USING C</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Function</td>
			        							<td> Find cube using function</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS80408-04-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>CONCEPT OF PROGRAMMING USING C</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Functions</td>
			        							<td>Find maximum and minimum between two numbers using functions</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS36017-04-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>CONCEPT OF PROGRAMMING USING C</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Pointers</td>
			        							<td> Largest of three numbers</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS22109-04-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHASHI PRAKASH PANDEY</td>

			        							<td>APPLIED MECHANICS E</td>
			        							<td>Civil Engineering</td>
			        							<td>2</td>
			        							<td>5</td>
			        							<td>Centre of Gravity</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CE217‎Untitled.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>CONCEPT OF PROGRAMMING USING C</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Pointers</td>
			        							<td>Pointers in C</td>                                              <td><a href='https://youtu.be/O50VjqpCsKk' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>CONCEPT OF PROGRAMMING USING C</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Pointers</td>
			        							<td>More About Pointers In C</td>                                              <td><a href='https://youtu.be/Iku1PCkqdM4' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>CONCEPT OF PROGRAMMING USING C</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Pointers</td>
			        							<td>Array of Pointers in C</td>                                              <td><a href='https://youtu.be/9sWQ5Jds1jQ' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>CONCEPT OF PROGRAMMING USING C</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Pointers</td>
			        							<td>Increment and Decrement on Pointer in C</td>                                              <td><a href='https://youtu.be/dJPuyMuOj18' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>CONCEPT OF PROGRAMMING USING C</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Pointers</td>
			        							<td>Pointer to Pointer</td>                                              <td><a href='https://youtu.be/omwQVZ-uDOs' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>CONCEPT OF PROGRAMMING USING C</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Pointers</td>
			        							<td>Passing pointers to functions</td>                                              <td><a href='https://youtu.be/FEd4AAgAGKU' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>CONCEPT OF PROGRAMMING USING C</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Pointers</td>
			        							<td>Pointers Functions</td>                                              <td><a href='https://youtu.be/PFnaHr3soCI' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>CONCEPT OF PROGRAMMING USING C</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Pointers</td>
			        							<td>Void Pointers</td>                                              <td><a href='https://youtu.be/9Ge2Y5jtfd0' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>CONCEPT OF PROGRAMMING USING C</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Pointers</td>
			        							<td>Examples of Void Pointers</td>                                              <td><a href='https://youtu.be/JVm698XBW44' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>CONCEPT OF PROGRAMMING USING C</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Pointers</td>
			        							<td>Pointers Structure</td>                                              <td><a href='https://youtu.be/25uPAfiinWc' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>CONCEPT OF PROGRAMMING USING C</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>File Handling</td>
			        							<td>File Management fopen() and fclose() in C</td>                                              <td><a href='https://youtu.be/QToupvpxfMc' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>CONCEPT OF PROGRAMMING USING C</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>File Handling</td>
			        							<td>File Management getc() and putc() in C</td>                                              <td><a href='https://youtu.be/F8ci5HBa3C8' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>CONCEPT OF PROGRAMMING USING C</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>File Handling</td>
			        							<td>Program for fprintf() and fscanf() in C</td>                                              <td><a href='https://youtu.be/sdkvKOvqwAA' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>CONCEPT OF PROGRAMMING USING C</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>File Handling</td>
			        							<td>Program for feof() and ferror()</td>                                              <td><a href='https://youtu.be/-f_9CIAj8c0' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>UNIVERSAL HUMAN VALUE</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Chapter 1</td>
			        							<td>Explain how production skills and human values are complementary</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS336CS2ndyrUHVSwatimall.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>UNIVERSAL HUMAN VALUE</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Chapter 2</td>
			        							<td>How do sensations and pre-conditionings influence our imagination</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS654swatiUhv30-03-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>UNIVERSAL HUMAN VALUE</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Chapter 3</td>
			        							<td>Natural acceptance is innate, invariant and universal</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS45uhvSwatimall.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>UNIVERSAL HUMAN VALUE</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Chapter 4</td>
			        							<td>Self exploration is a process of dialogue between ‘what you are’ and ‘what you really want to be’</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS976UHVCs2ndyrswatimall.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHASHI PRAKASH PANDEY</td>

			        							<td>APPLIED MECHANICS E</td>
			        							<td>Civil Engineering</td>
			        							<td>2</td>
			        							<td>Friction</td>
			        							<td>Friction</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CE127‎Untitledcompressed.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>YASH RAJ</td>

			        							<td>COMMUNICATION SKILL-II</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>ch-03</td>
			        							<td>Conjunction [types]</td>                                              <td><a href='https://youtu.be/d3N0byGjz6c' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>YASH RAJ</td>

			        							<td>COMMUNICATION SKILLS II E</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>ch-03</td>
			        							<td>Conjunction {Introduction}</td>                                              <td><a href='https://youtu.be/G0-mKjU1NoY' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>YASH RAJ</td>

			        							<td>COMMUNICATION  SKILL-II.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>ch-03</td>
			        							<td>Conjunction {Introduction}</td>                                              <td><a href='https://youtu.be/G0-mKjU1NoY' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>YASH RAJ</td>

			        							<td>COMMUNICATION SKILLS II E</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>ch-03</td>
			        							<td>Conjunction {Introduction}</td>                                              <td><a href='https://youtu.be/d3N0byGjz6c' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>YASH RAJ</td>

			        							<td>COMMUNICATION SKILLS II E</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>ch-03</td>
			        							<td>Conjunction [types]</td>                                              <td><a href='https://youtu.be/d3N0byGjz6c' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>YASH RAJ</td>

			        							<td>COMMUNICATION  SKILL-II.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>ch-03</td>
			        							<td>Conjunction [types]</td>                                              <td><a href='https://youtu.be/d3N0byGjz6c' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Unit 2  DIGITAL SWITCHINHG SYSTEM</td>
			        							<td>C Dot Exchange</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL453elx3mcs20-3pm.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Unit 2  DIGITAL SWITCHINHG SYSTEM</td>
			        							<td>E 10B Exchange</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL302mcselx3pm21-03.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>YASH RAJ</td>

			        							<td>COMMUNICATION SKILL-II</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>ch-02</td>
			        							<td>Framing Question</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS518CommuncationSkills-II,StudymaterialforELX,EEE,MPE,2ndYearStudents,byYashRajSir.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>YASH RAJ</td>

			        							<td>COMMUNICATION SKILLS II E</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>ch-02</td>
			        							<td>Framing Question</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS943CommuncationSkills-II,StudymaterialforELX,EEE,MPE,2ndYearStudents,byYashRajSir.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>YASH RAJ</td>

			        							<td>COMMUNICATION  SKILL-II.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>ch-02</td>
			        							<td>Framing Question</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS18CommuncationSkills-II,StudymaterialforELX,EEE,MPE,2ndYearStudents,byYashRajSir.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Unit 2  DIGITAL SWITCHINHG SYSTEM</td>
			        							<td>EWSD</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL391mcselx3pm23-03.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AMIT KUMAR PANDEY</td>

			        							<td>TRANSMISSION AND DISTRIBUTION OF ELECTRICAL POWER E</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Transmission System</td>
			        							<td>String efficiency</td>                                              <td><a href='https://www.youtube.com/watch?v=Ni-nVMxqEkM&t=302s' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EE315StringEfficiency.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHASHI PRAKASH PANDEY</td>

			        							<td>APPLIED MECHANICS E</td>
			        							<td>Civil Engineering</td>
			        							<td>2</td>
			        							<td>Moment</td>
			        							<td>Couple</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CE552‎Untitled.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHASHI PRAKASH PANDEY</td>

			        							<td>APPLIED MECHANICS E</td>
			        							<td>Civil Engineering</td>
			        							<td>2</td>
			        							<td>Simple machine</td>
			        							<td>Simple machine </td>                                              <td><a href='https://youtu.be/PVclZ87VG_A' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SHASHI PRAKASH PANDEY</td>

			        							<td>APPLIED MECHANICS E</td>
			        							<td>Civil Engineering</td>
			        							<td>2</td>
			        							<td>Simple machine</td>
			        							<td>determination of velocity ratio, mechanical advantage and efficiency</td>                                              <td><a href='https://youtu.be/fz3VXDR6KKk' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ANKITA SRIVASTAVA</td>

			        							<td>OBJECT ORIENTED PROGRAMMING USING JAVA</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Constructors in java</td>
			        							<td>Constructors</td>                                              <td><a href='https://youtu.be/E7hT5mkY-cQ' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ANKITA SRIVASTAVA</td>

			        							<td>OBJECT ORIENTED PROGRAMMING USING JAVA</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Constructor </td>
			        							<td>Constructor inheritance</td>                                              <td><a href='https://youtu.be/E7hT5mkY-cQ' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ANIL KUMAR YADAV</td>

			        							<td>ELECTRICAL DESIGN DRAWING AND ESTIMATING II E</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Electric substation</td>
			        							<td>Pole mounted type substation</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE76EDDE-2,3EE,by-AKyadav(3).pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PREM PRAKASH SINGH</td>

			        							<td>ELECTRICAL DESIGN DRAWING AND ESTIMATING II</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>EARTHING</td>
			        							<td>PIPE EARTHING</td>                                              <td><a href='https://youtu.be/a4kL7dZGh6g' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>AMIT KUMAR PANDEY</td>

			        							<td>BASIC ELECTRICAL ENGINEERING E</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>Various types of Power Plants</td>
			        							<td>Thermal Power Plant</td>                                              <td><a href='https://www.youtube.com/watch?v=5lX5UroCQ8E&t=29s' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EE566ThermalPowerPlant.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PREM PRAKASH SINGH</td>

			        							<td>TRANSMISSION AND DISTRIBUTION OF ELECTRICAL POWER</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>UNDERGROUND CABEL</td>
			        							<td>GENERAL CONSTRICTION OFCABEL</td>                                              <td><a href='https://youtu.be/E7aOcflOU_o' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>PREM PRAKASH SINGH</td>

			        							<td>TRANSMISSION AND DISTRIBUTION OF ELECTRICAL POWER</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>UNDERGROUND CABLES</td>
			        							<td>METHOD OF LAYING OF CABLES (DIRECT SYSTEM)</td>                                              <td><a href='https://youtu.be/8pbZXeeNMec' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>KM SHALINI MISHRA</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Civil Engineering</td>
			        							<td>2</td>
			        							<td>Moment and couple </td>
			        							<td>Topic 1</td>                                              <td><a href='https://youtu.be/QT_AoME3nG4' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>KM SHALINI MISHRA</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Civil Engineering</td>
			        							<td>2</td>
			        							<td>General conditions of equilibrium </td>
			        							<td>Topic 2</td>                                              <td><a href='https://youtu.be/ZLQwsz3AJWc' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>KM SHALINI MISHRA</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Civil Engineering</td>
			        							<td>2</td>
			        							<td>Friction </td>
			        							<td>Topic 3</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CE3511styrcivil(m)friction.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATH-II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>2</td>
			        							<td>The point in space</td>                                              <td><a href='https://youtu.be/3qD_h8ZKL6Y' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS135Lecture-106-02-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHEMATICS 1 B</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>2</td>
			        							<td>The point in space </td>                                              <td><a href='https://youtu.be/3qD_h8ZKL6Y' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS429Lecture-106-02-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHS II</td>
			        							<td>Civil Engineering</td>
			        							<td>2</td>
			        							<td>2</td>
			        							<td>The point in space  </td>                                              <td><a href='https://youtu.be/3qD_h8ZKL6Y' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS226Lecture-106-02-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHEMATICS II</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>2 </td>
			        							<td>The point in space   </td>                                              <td><a href='https://youtu.be/3qD_h8ZKL6Y' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS884Lecture-106-02-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATH-II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>2  </td>
			        							<td>The point in space   </td>                                              <td><a href='https://youtu.be/oYaVX6Cairs ' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS521Lecture-206-02-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHEMATICS 1 B</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>2   </td>
			        							<td>The point in space   </td>                                              <td><a href='https://youtu.be/oYaVX6Cairs ' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS434Lecture-206-02-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHS II</td>
			        							<td>Civil Engineering</td>
			        							<td>2</td>
			        							<td>2    </td>
			        							<td>The point in space   </td>                                              <td><a href='https://youtu.be/oYaVX6Cairs ' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS269Lecture-206-02-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHEMATICS II</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>2     </td>
			        							<td>The point in space   </td>                                              <td><a href='https://youtu.be/oYaVX6Cairs ' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS735Lecture-206-02-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DR AVINASH BAHADUR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Ecology</td>
			        							<td>Ecology</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS386Screenshot2020-06-02-10-18-37-376comskytekpdfcreator.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DR AVINASH BAHADUR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Ecology</td>
			        							<td>Ecology</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS358IMG20200602102038.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DR AVINASH BAHADUR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Environmental impact assessment</td>
			        							<td>Environmental impact assessment</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS934IMG20200602102348.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHIVANI SHIVHARE</td>

			        							<td>UTILIZATION OF ELECTRICAL ENERGY</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Economics of Power generation</td>
			        							<td>Factors releted to power economics</td>                                              <td><a href='https://youtu.be/ejOClfshBgk' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EE487differentfactors.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AMIT KUMAR PANDEY</td>

			        							<td>TRANSMISSION AND DISTRIBUTION OF ELECTRICAL POWER E</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Transmission System</td>
			        							<td>Corona effect in transmission line</td>                                              <td><a href='https://www.youtube.com/watch?v=Vz5721De_84&t=446s' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EE145CoronaeffectintransmissionlineTDEP.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PANKAJ CHAUHAN</td>

			        							<td>CONSTRUCTION AND MATERIAL C</td>
			        							<td>Architecture Assistantship</td>
			        							<td>6</td>
			        							<td>Temporary work </td>
			        							<td>Topic 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AA582topic-1.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DR AVINASH BAHADUR SINGH</td>

			        							<td>ENVIRONMENTAL STUDIES</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Environmental impact assessment</td>
			        							<td>Environmental impact assessment</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS10IMG20200602102038.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DR AVINASH BAHADUR SINGH</td>

			        							<td>ENVIRONMENTAL STUDIES</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Environmental impact assessment</td>
			        							<td>Environmental impact assessment</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS883IMG20200602102348.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DR AVINASH BAHADUR SINGH</td>

			        							<td>ENVIRONMENTAL STUDIES</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Environmental impact assessment</td>
			        							<td>Environmental impact assessment</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS130IMG20200602102038.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DR AVINASH BAHADUR SINGH</td>

			        							<td>ENVIRONMENTAL STUDIES</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Environmental impact assessment</td>
			        							<td>Environmental impact assessment</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS496IMG20200602102038.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DINESH PRATAP SINGH</td>

			        							<td>SURVEYING I</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>Introduction</td>
			        							<td>surveying-1</td>                                              <td><a href='https://youtu.be/dMVxZUe5kvg' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CE536dp1-4.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>GAURAV KUMAR KASHYAP</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Introduction</td>
			        							<td>Force</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC855IntroductionPart2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>GAURAV KUMAR KASHYAP</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Force system</td>
			        							<td>System of forces</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC907ForcesystemPart1.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>GAURAV KUMAR KASHYAP</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Force system</td>
			        							<td>System of forces</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC922ForcesystemPart2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>GAURAV KUMAR KASHYAP</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Moment</td>
			        							<td>Moment-1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC603Momentpart1.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>GAURAV KUMAR KASHYAP</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Moment</td>
			        							<td>Moment-2</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC801MomentPart2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>GAURAV KUMAR KASHYAP</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Couple</td>
			        							<td>Couple</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC447Couplespart1.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>GAURAV KUMAR KASHYAP</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>General Conditions of Equilibrium</td>
			        							<td>Laws of Equilibrium</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC205Equilibriumpart1.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>GAURAV KUMAR KASHYAP</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>General Conditions of Equilibrium</td>
			        							<td>Numericals</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC262Equilibriumpart2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>GAURAV KUMAR KASHYAP</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Machines</td>
			        							<td>Machines/ M.A. & V.R.</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC601Machinespart1.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>GAURAV KUMAR KASHYAP</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Machines</td>
			        							<td>System of pulleys</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC701MachinePart2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRATIKSHA AGARWAL</td>

			        							<td>BASICS OF ELECTRICAL AND ELECTRONICS ENGINEERING</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>D C circuits</td>
			        							<td>Effect of temp on resistance and heating effect of current</td>                                              <td><a href='https://youtu.be/XIdrHzPwFWs' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EE534effectoftemponresistanceandheatingeffectofcurrent.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>GAURAV KUMAR KASHYAP</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Machines</td>
			        							<td>Weston diff pulley</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC420MachinePart3.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PANKAJ CHAUHAN</td>

			        							<td>CONSTRUCTION AND MATERIAL C</td>
			        							<td>Architecture Assistantship</td>
			        							<td>6</td>
			        							<td>Temporary work </td>
			        							<td>Topic 2</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AA912topic-2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PANKAJ CHAUHAN</td>

			        							<td>CONSTRUCTION AND MATERIAL C</td>
			        							<td>Architecture Assistantship</td>
			        							<td>6</td>
			        							<td>Temporary work </td>
			        							<td>Topic 3</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AA894topic3.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>GAURAV KUMAR KASHYAP</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Center of gravity</td>
			        							<td>Center of gravity & Centroid</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC267Centerofgravitypart1.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>GAURAV KUMAR KASHYAP</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Center of gravity</td>
			        							<td>Numericals</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC29CenterofgravityPart2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATH-II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>2      </td>
			        							<td>The point in space   </td>                                              <td><a href='https://youtu.be/6sAdH9V6Rn4' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS200Lecture-306-02-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATH-II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>2      </td>
			        							<td>The point in space   </td>                                              <td><a href='https://youtu.be/6sAdH9V6Rn4' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS347Lecture-306-02-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHEMATICS 1 B</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>2     </td>
			        							<td>The point in space   </td>                                              <td><a href='https://youtu.be/6sAdH9V6Rn4' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS916Lecture-306-02-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHS II</td>
			        							<td>Civil Engineering</td>
			        							<td>2</td>
			        							<td>2    </td>
			        							<td>The point in space   </td>                                              <td><a href='https://youtu.be/6sAdH9V6Rn4' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS449Lecture-306-02-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PANKAJ CHAUHAN</td>

			        							<td>CONSTRUCTION AND MATERIAL C</td>
			        							<td>Architecture Assistantship</td>
			        							<td>6</td>
			        							<td>Temporary work </td>
			        							<td>Topic 4</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AA909topic4.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHEMATICS II</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>2  </td>
			        							<td>The point in space   </td>                                              <td><a href='https://youtu.be/6sAdH9V6Rn4' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS108Lecture-306-02-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATH-II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>2  </td>
			        							<td>The point in space   </td>                                              <td><a href='https://youtu.be/_E400i9SdQA' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS890Lecture-406-02-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHEMATICS 1 B</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>2  </td>
			        							<td>The point in space   </td>                                              <td><a href='https://youtu.be/_E400i9SdQA' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS209Lecture-406-02-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHS II</td>
			        							<td>Civil Engineering</td>
			        							<td>2</td>
			        							<td>2  </td>
			        							<td>The point in space   </td>                                              <td><a href='https://youtu.be/_E400i9SdQA' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS689Lecture-406-02-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHEMATICS II</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>2  </td>
			        							<td>The point in space   </td>                                              <td><a href='https://youtu.be/_E400i9SdQA' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS961Lecture-406-02-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>REETA</td>

			        							<td>MULTIMEDIA AND ANIMATION</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Unit 1</td>
			        							<td>Introduction to Multimedia</td>                                              <td><a href='https://www.youtube.com/watch?v=VaarLRfR3fI' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CS836Chp1-Introductiontomultimedia.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PANKAJ CHAUHAN</td>

			        							<td>ARCHITECTURAL DESIGN A BASIC DESIGN</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>Theory of design </td>
			        							<td>Topic 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AA224theoryAD-A.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PANKAJ CHAUHAN</td>

			        							<td>ARCHITECTURAL DESIGN A BASIC DESIGN</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>Theory of design </td>
			        							<td>Topic 2</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AA4412.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PANKAJ CHAUHAN</td>

			        							<td>ARCHITECTURAL DESIGN A BASIC DESIGN</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>Theory of design </td>
			        							<td>Topic 3</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AA8083.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PANKAJ CHAUHAN</td>

			        							<td>CONSTRUCTION AND MATERIAL A</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>Materials</td>
			        							<td>Cement manufacturing </td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AA404cement1.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAVESH KUMAR CHAUHAN</td>

			        							<td>E COMMERCE AND DIGITAL MARKETING</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Google AdWords Unit 5</td>
			        							<td>Google AdWords introducton</td>                                              <td><a href='https://cdn2.hubspot.net/hubfs/4193479/How_to_Use_Google_AdWords.pdf' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>PRAVESH KUMAR CHAUHAN</td>

			        							<td>E COMMERCE AND DIGITAL MARKETING</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Google AdWords Unit 5</td>
			        							<td>Google AdWords_ Structure</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS347GoogleAdWordsStructure.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>REETA</td>

			        							<td>MULTIMEDIA AND ANIMATION</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Unit 1</td>
			        							<td>Hardware requirement of multimedia</td>                                              <td><a href='https://www.youtube.com/watch?v=9q28QBIpRPg&t=199s' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CS294Lec2hardware.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>REETA</td>

			        							<td>MULTIMEDIA AND ANIMATION</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Unit 1</td>
			        							<td>Software Requirement of Multimedia</td>                                              <td><a href='https://www.youtube.com/watch?v=rh51bQf5iAk' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CS788Lec3Software.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>REETA</td>

			        							<td>MULTIMEDIA AND ANIMATION</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Unit 3</td>
			        							<td>Types of compression</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS98Typesofcompression.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>REETA</td>

			        							<td>MULTIMEDIA AND ANIMATION</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Unit 3</td>
			        							<td>TIFF</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS672TIFF.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAVESH KUMAR CHAUHAN</td>

			        							<td>E COMMERCE AND DIGITAL MARKETING</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Google AdWords Unit 5</td>
			        							<td>Google AdWords Key planner use guide</td>                                              <td><a href='https://ahrefs.com/blog/google-keyword-planner/' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>REETA</td>

			        							<td>MULTIMEDIA AND ANIMATION</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Unit 3</td>
			        							<td>Standaredization of algorithm</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS643Standaredizationofalgorithm.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAVESH KUMAR CHAUHAN</td>

			        							<td>E COMMERCE AND DIGITAL MARKETING</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Google AdWords Unit 5</td>
			        							<td>Google AdWords Organizing Adgroup</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS144OrganiseAdGroup.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SAURABH KUMAR SONI</td>

			        							<td>PRODUCTION TECHNOLOGY II</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>Quality control</td>
			        							<td>Quality</td>                                              <td><a href='https://youtu.be/21yhLK70LFU' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SAURABH KUMAR SONI</td>

			        							<td>CNC MACHINE AND AUTOMATION</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>Quality control</td>
			        							<td>Quality</td>                                              <td><a href='https://youtu.be/21yhLK70LFU' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>PRAVESH KUMAR CHAUHAN</td>

			        							<td>E COMMERCE AND DIGITAL MARKETING</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Google AdWords Unit 5</td>
			        							<td>Creating An Effective Ad</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS509CreatingAnEffectiveAd-TargetPublicMarketing.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAVESH KUMAR CHAUHAN</td>

			        							<td>E COMMERCE AND DIGITAL MARKETING</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Google AdWords Unit 5</td>
			        							<td>Create a video campaign - YouTube</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS839Createavideocampaign-YouTubeHelp.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ANIL KUMAR YADAV</td>

			        							<td>ELECTRICAL DESIGN DRAWING AND ESTIMATING II E</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Estimation of service connections</td>
			        							<td>Service connection and its type.</td>                                              <td><a href='https://youtu.be/BD7xFeW4upM' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ANIL KUMAR YADAV</td>

			        							<td>ELECTRICAL DESIGN DRAWING AND ESTIMATING II E</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Estimation of substations</td>
			        							<td>Pole mounted type substation</td>                                              <td><a href='https://youtu.be/UZxPJGemylo' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>PRAVESH KUMAR CHAUHAN</td>

			        							<td>E COMMERCE AND DIGITAL MARKETING</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Google Analytics Unit 6</td>
			        							<td>Google Analytics Introduction</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS108webanalyticstutorial.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATH-II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>2  </td>
			        							<td>The point in space   </td>                                              <td><a href='https://youtu.be/RzXUfWpsewI' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS858Lecture-506-02-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHEMATICS 1 B</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>2  </td>
			        							<td>The point in space   </td>                                              <td><a href='https://youtu.be/RzXUfWpsewI' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS89Lecture-506-02-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHS II</td>
			        							<td>Civil Engineering</td>
			        							<td>2</td>
			        							<td>2  </td>
			        							<td>The point in space   </td>                                              <td><a href='https://youtu.be/RzXUfWpsewI' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS430Lecture-506-02-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHEMATICS II</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>2  </td>
			        							<td>The point in space   </td>                                              <td><a href='https://youtu.be/RzXUfWpsewI' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS363Lecture-506-02-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>POONAM SHARMA</td>

			        							<td>COMMUNICATION SKILLS II E</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>1</td>
			        							<td>Preposition</td>                                              <td><a href='https://youtu.be/hTU4pzL2ip0' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Tense 1</td>
			        							<td>Simple present </td>                                              <td><a href='https://youtu.be/XyBSvWKu0NE' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Tense 1</td>
			        							<td>Simple present </td>                                              <td><a href='https://youtu.be/XyBSvWKu0NE' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Tense 1</td>
			        							<td>Simple present </td>                                              <td><a href='https://youtu.be/XyBSvWKu0NE' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>Tense 1</td>
			        							<td>Simple present </td>                                              <td><a href='https://youtu.be/XyBSvWKu0NE' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>POONAM SHARMA</td>

			        							<td>COMMUNICATION SKILLS II E</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>1</td>
			        							<td>Preposition</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS177prepositionspart-1.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ARJUN KUMAR AGRAWAL</td>

			        							<td>REINFORCED CEMENT CONCRETE STRUCTURES</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>introduction of R.C.C. Limit State & Design singly R.C.C.Beam</td>
			        							<td>Basic concept for design singly R.C.C.Beam</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CE46601lectureondesignRCCbeambylimitmethod(1STPART)(1).pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>POONAM SHARMA</td>

			        							<td>COMMUNICATIONS SKILLS II</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>1</td>
			        							<td>Preposition</td>                                              <td><a href='https://youtu.be/hTU4pzL2ip0' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS559prepositionspart-1.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ARJUN KUMAR AGRAWAL</td>

			        							<td>REINFORCED CEMENT CONCRETE STRUCTURES</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td></td>
			        							<td>Basic concept for design  one way slab with numrical</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CE38302lectureondesignonewayslabRCCbylimitmethod(1).pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ARJUN KUMAR AGRAWAL</td>

			        							<td>REINFORCED CEMENT CONCRETE STRUCTURES</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>introduction of R.C.C. Limit State & Design  Two way slab</td>
			        							<td>Basic concept for design  two  way slab with numerical</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CE86603lectureondesignTwowayRCCslabbylimitmethod.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>UTKERSH TRIPATHI</td>

			        							<td>CNC MACHINE & AUTOMATION.</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>AUTOMATION & N.C.MACHINE</td>
			        							<td>AUTOMATION</td>                                              <td><a href='https://youtu.be/g-RQ7-Rm_kc' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>JOGENDRA KUMAR</td>

			        							<td>APPLIED MATHEMATICS II</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>Circle</td>
			        							<td>Centre and radius</td>                                              <td><a href='https://youtu.be/k2NVj8QKlaA' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS190CamScanner06-02-20201631331.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>UTKERSH TRIPATHI</td>

			        							<td>CNC MACHINE & AUTOMATION.</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>AUTOMATION & N.C.MACHINE</td>
			        							<td>ASSEMBLY PROCESS</td>                                              <td><a href='https://youtu.be/nBCmrDu7m4o' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>JOGENDRA KUMAR</td>

			        							<td>APPLIED MATHEMATICS II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Circle</td>
			        							<td>Centre and radius</td>                                              <td><a href='https://youtu.be/k2NVj8QKlaA' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS768CamScanner06-02-20201631331.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>POONAM SHARMA</td>

			        							<td>FUNCTIONAL COMMUNICATION</td>
			        							<td>Architecture Assistantship</td>
			        							<td>4</td>
			        							<td>Chapter 5</td>
			        							<td>Buying Second Hand Bicycle</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS699AAIIndYear(FC)(6).pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ADARSH TRIPATHI</td>

			        							<td>ENERGY CONSERVATION</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>03</td>
			        							<td>TRANSFORMER </td>                                              <td><a href='https://youtu.be/N_ssIiNGKbk' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>JOGENDRA KUMAR</td>

			        							<td>Applied  Mathematics - II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Circle</td>
			        							<td>Centre and radius</td>                                              <td><a href='https://youtu.be/k2NVj8QKlaA' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS166CamScanner06-02-20201631331.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ADARSH TRIPATHI</td>

			        							<td>ENERGY CONSERVATION</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>03</td>
			        							<td>TRANSFORMER </td>                                              <td><a href='https://youtu.be/pe1ahabYTEM' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ADARSH TRIPATHI</td>

			        							<td>ENERGY CONSERVATION</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>03</td>
			        							<td>TRANSFORMER </td>                                              <td><a href='https://youtu.be/rwz7qzBQ6Lw' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>POONAM SHARMA</td>

			        							<td>FUNCTIONAL COMMUNICATION</td>
			        							<td>Architecture Assistantship</td>
			        							<td>4</td>
			        							<td>Chapter 5</td>
			        							<td>Buying A Second Hand Bicycle</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS607AAIIndYear(FC)(6).pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ARJUN KUMAR AGRAWAL</td>

			        							<td>REINFORCED CEMENT CONCRETE STRUCTURES</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>introduction of R.C.C. Limit State & Design Doubly R.C.C.Beam</td>
			        							<td>Basic concept for design  doubly with numerical</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CE17804lectureondesignRCCdoublybeambylimitmethod.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>UTKERSH TRIPATHI</td>

			        							<td>PRODUCTION TECHNOLOGY-II.</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>PRODUCTION OF PLASTICS</td>
			        							<td>Plastics moulding</td>                                              <td><a href='https://youtu.be/LOQnng-gbIk' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ARJUN KUMAR AGRAWAL</td>

			        							<td>REINFORCED CEMENT CONCRETE STRUCTURES</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>introduction of R.C.C. Limit State & Design singly R.C.C. T Beam </td>
			        							<td>Basic concept for design  T Beam  with numerical</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CE86405lectureondesignRCCTbeam.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>UTKERSH TRIPATHI</td>

			        							<td>PRODUCTION TECHNOLOGY-II.</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>PRODUCTION OF PLASTICS</td>
			        							<td>Plastics moulding</td>                                              <td><a href='https://youtu.be/19rp91dGJyk' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>UTKERSH TRIPATHI</td>

			        							<td>PRODUCTION TECHNOLOGY-II.</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>PRODUCTION OF PLASTICS</td>
			        							<td>Plastics moulding</td>                                              <td><a href='https://youtu.be/w9m3Ah6kKSY' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ADARSH TRIPATHI</td>

			        							<td>ENERGY CONSERVATION</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>05</td>
			        							<td>TRANSMISSIONS OF ELECTRICITY </td>                                              <td><a href='https://youtu.be/WOy4leXFHnU' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>AMIT KUMAR PANDEY</td>

			        							<td>BASIC ELECTRICAL ENGINEERING E</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>Various types of Power Plants</td>
			        							<td>Nuclear Power Plant</td>                                              <td><a href='https://www.youtube.com/watch?v=uPLIgON5OtE' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EE680NuclearPowerPlant.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>UMAPATI TRIPATHI</td>

			        							<td>PRINCIPLES OF ADVERTISING MANAGEMENT</td>
			        							<td>MSM</td>
			        							<td>2</td>
			        							<td>UNIT-1</td>
			        							<td>Advertising</td>                                              <td><a href='https://youtu.be/VBi43KM2NII' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>PRATIKSHA AGARWAL</td>

			        							<td>ENERGY CONSERVATION</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Lighting and DG systems</td>
			        							<td>DG set</td>                                              <td><a href='https://youtu.be/gzfX5IahOz0' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EE952dgset1.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>VAPOUR ABSORPTION REFRIGERATION SYSTEM</td>
			        							<td>PRINCIPLE AND WORKING OF VARS</td>                                              <td><a href='https://www.youtube.com/watch?v=zHepTHbGPw4&t=3s' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP941VARS.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAVESH KUMAR CHAUHAN</td>

			        							<td>E COMMERCE AND DIGITAL MARKETING</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Google_analytics Unit 6</td>
			        							<td>Google_analytics introduction</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS542Googleanalytics.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>COMPUTER AIDED DESIGN AND MANUFACTURING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>SURFACE AND SOLID MODELLING USING CAD/CAM</td>
			        							<td>MODELLING DETAILS</td>                                              <td><a href='https://www.youtube.com/watch?v=l7s9aW9EgnU&t=15s' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ADARSH TRIPATHI</td>

			        							<td>ENERGY CONSERVATION</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>09</td>
			        							<td>GENERAL ENERGY SAVING TIPS </td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MP680CamScanner04-16-2020174647.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>LAW OF FORCES</td>
			        							<td>SYSTEM OF FORCES</td>                                              <td><a href='https://www.youtube.com/watch?v=nPPIUI8o5Nw&t=4s' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP126SYSTEMOFFORCES.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>MACHINES</td>
			        							<td>SINGLE AND DOUBLE PURCHASE WINCH CRAB</td>                                              <td><a href='https://www.youtube.com/watch?v=0aknoKHrAno&t=1009s' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP152MACHINES.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>VAPOUR ABSORPTION REFRIGERATION SYSTEM</td>
			        							<td>ELECTROLUX REFRIGERATOR</td>                                              <td><a href='https://www.youtube.com/watch?v=iHAF441m2Vw' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP223DOMESTICELECTROLUXREFRIGERATOR.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAVESH KUMAR CHAUHAN</td>

			        							<td>E COMMERCE AND DIGITAL MARKETING</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Google_analytics Unit 6</td>
			        							<td>Create a Custom Google Analytics Dashboard</td>                                              <td><a href='https://support.google.com/analytics/answer/1068218?hl=en' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CS326CreateaCustomGoogleAnalyticsDashboard.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>VIVEKANAND YADAV</td>

			        							<td>APPLIED MECHANICS.</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Unit-3</td>
			        							<td>Numerical based on moment</td>                                              <td><a href='https://youtu.be/EQtPdpTrsgw' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ADARSH TRIPATHI</td>

			        							<td>ENGINEERING  DRAWING -II.</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>10</td>
			        							<td>AUTOCAD</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MP169CamScanner04-16-2020180512.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>VIVEKANAND YADAV</td>

			        							<td>APPLIED MECHANICS.</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Unit-5</td>
			        							<td>Numerical based on centre of gravity</td>                                              <td><a href='https://youtu.be/UyyQNWPFv4I' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>VIVEKANAND YADAV</td>

			        							<td>APPLIED MECHANICS.</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Unit-5</td>
			        							<td>Numerical based on centre of gravity of solid body</td>                                              <td><a href='https://youtu.be/JJmBB3ifCOQ' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ADARSH TRIPATHI</td>

			        							<td>ENERGY CONSERVATION</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>7</td>
			        							<td>ECBC</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MP416NewDoc03-31-2020195809.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>VIVEKANAND YADAV</td>

			        							<td>APPLIED MECHANICS.</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Unit-5</td>
			        							<td>Centre of gravity theory part</td>                                              <td><a href='https://youtu.be/Z7-bXbOlAfI' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ADARSH TRIPATHI</td>

			        							<td>ENERGY CONSERVATION</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>7</td>
			        							<td>ECBC</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MP769NewDoc03-31-2020200228.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SAUMYA MISHRA</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Psychrometry</td>
			        							<td>Psychrometry</td>                                              <td><a href='https://www.youtube.com/watch?v=hXOXtetom0c&t=66s' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MC570Psycho1-Copy.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>VIVEKANAND YADAV</td>

			        							<td>HYDRAULICS AND  PNEUMATICS.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Unit-3</td>
			        							<td>Flow of fluids</td>                                              <td><a href='https://youtu.be/8bTy8U3fSt0' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SAUMYA MISHRA</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Psychrometry</td>
			        							<td>Psychrometry Part-2</td>                                              <td><a href='https://www.youtube.com/watch?v=LKvTrHRdb0g' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MC588psycho2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Relational Database Design</td>
			        							<td>Concept of Normalization</td>                                              <td><a href='https://youtu.be/ONDwrF_SjY0' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Relational Database Design</td>
			        							<td>First Normal Form</td>                                              <td><a href='https://youtu.be/hzOeNVk9NHI' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Database System Concept and Data Modeling</td>
			        							<td>Database Language</td>                                              <td><a href='https://youtu.be/MhKDQ5nyZKA' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS  II</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>unit 3</td>
			        							<td>current electricity</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS135NewDoc04-09-2020164335.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS  II</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>unit 4 </td>
			        							<td>current electricity</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS924NewDoc04-09-2020164335.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION & DISASTER MANAGEMENT</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Unit 1</td>
			        							<td>Acid Rain</td>                                              <td><a href='https://youtu.be/GCHYNnFKvyg' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS  II</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>unit 4</td>
			        							<td>current electricity</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS439NewDoc04-10-2020153204.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Relational Model</td>
			        							<td>Definition of Relation and Introduction to Relational Model</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS74720-03-2020CSIIndYearDBMS.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>UMAPATI TRIPATHI</td>

			        							<td>PRINCIPLES OF ADVERTISING MANAGEMENT</td>
			        							<td>MSM</td>
			        							<td>2</td>
			        							<td>UNIT-2</td>
			        							<td>Advertising Media</td>                                              <td><a href='https://youtu.be/zr12ucBVIcg' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS  II</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>unit 4</td>
			        							<td>current electricity</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS636CamScanner04-13-2020152213.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS  II</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>unit 4</td>
			        							<td>current electricity</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS5CamScanner04-15-2020160048.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS  II</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>unit 4</td>
			        							<td>current electricity</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS188CamScanner04-16-2020150512.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>UMAPATI TRIPATHI</td>

			        							<td>PRINCIPLES OF ADVERTISING MANAGEMENT</td>
			        							<td>MSM</td>
			        							<td>2</td>
			        							<td>UNIT-3</td>
			        							<td>Advertising Copy</td>                                              <td><a href='https://youtu.be/Feg0XVT4vFo' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>UMAPATI TRIPATHI</td>

			        							<td>PRINCIPLES OF ADVERTISING MANAGEMENT</td>
			        							<td>MSM</td>
			        							<td>2</td>
			        							<td>UNIT-3</td>
			        							<td>Advertising Copy</td>                                              <td><a href='https://youtu.be/Q-9bI1eqnUU' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Relational Model</td>
			        							<td>Integrity Constraints, Domain Constraints, Entity Constraints and Equi Join</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS203IntegrityConstraints,EntityConstraintsandEquiJoin.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS  II</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>unit 4</td>
			        							<td>current electricity</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS217CURRENTELECTRICITY.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS  II</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>unit 3</td>
			        							<td>electrostatics</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS708ELECTROSTATICS.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KM SHALINI MISHRA</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Civil Engineering</td>
			        							<td>2</td>
			        							<td>Applied mechanics (machine )</td>
			        							<td>Topic 4</td>                                              <td><a href='https://youtu.be/hicvO0rrVvY' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT E</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Unit 1</td>
			        							<td>Acid Rain</td>                                              <td><a href='https://youtu.be/GCHYNnFKvyg' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Relational Model</td>
			        							<td>Referential Integrity Constraints and Key Constraints</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS589ReferentialIntegrityConstraints,KeyConstraints.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS  II</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>unit 5</td>
			        							<td>magnetism</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS562MAGNETIC-EFFECTS-OF-CURRENT-MAGNETISM.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS  II</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>unit 5</td>
			        							<td>electromagnetic induction and alternating current</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS628ELECTROMAGNETICINDUCTIONALTERNATINGCURRENTS.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT E</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Unit 1</td>
			        							<td>Ozone layer depletion</td>                                              <td><a href='https://youtu.be/GCHYNnFKvyg' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Relational Model</td>
			        							<td>Relational Calculas</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS618RelationalCalculas.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS  II</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>unit 6</td>
			        							<td>semiconductor physics</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS804semiconductorphysics.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>unit 2</td>
			        							<td>optics</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS643OPTICS.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>unit 3</td>
			        							<td>electrostatics</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS828ELECTROSTATICS.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Relational Model</td>
			        							<td>Relational Algebraic Operation (Selection Operation)</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS410RelationalAlgebra.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>unit 4</td>
			        							<td>current electricity</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS613CURRENTELECTRICITY.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>unit 5</td>
			        							<td>magnetism</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS487MAGNETIC-EFFECTS-OF-CURRENT-MAGNETISM.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>unit 5</td>
			        							<td>electromagnetic induction</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS136ELECTROMAGNETICINDUCTIONALTERNATINGCURRENTS.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Relational Model</td>
			        							<td>Relation Algebraic (Project,Union, Set Intersection and Set Difference Operation)</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS148ProjectOperation,UnionoperationandSetIntersectionandSetDifference.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Relational Model</td>
			        							<td>Relational Algebra (Cartesian Product, Rename and Join Operation)</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS165Cartesianproduct,RenameOperationandJoinOperation.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>UTKERSH TRIPATHI</td>

			        							<td>PRODUCTION TECHNOLOGY-II.</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>Modern Concept of Quality Control</td>
			        							<td>Quality Control</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MP989Qualitycontrol.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>JOGENDRA KUMAR</td>

			        							<td>APPLIED MATHEMATICS II E</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>Circle</td>
			        							<td>Centre and radius</td>                                              <td><a href='https://youtu.be/k2NVj8QKlaA' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS483CamScanner06-02-20201631331.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>OM PRAKASH MISHRA</td>

			        							<td>ELECTRONIC COMPONENTS AND DEVICES</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>UNIT 2</td>
			        							<td>TYPES OF DIODE.</td>                                              <td><a href='https://youtu.be/l0agaz6GG_4' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EL736TypesofDiode.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>unit 6</td>
			        							<td>semiconductor physics</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS16semiconductorphysics.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>unit 2</td>
			        							<td>optics</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS53OPTICS.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>REETA</td>

			        							<td>MULTIMEDIA AND ANIMATION</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Unit 3</td>
			        							<td>File Formats</td>                                              <td><a href='https://www.youtube.com/watch?v=WPoN0-0fqXI' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CS912FileFormats.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>unit 3</td>
			        							<td>electrostatics</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS875ELECTROSTATICS.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>OM PRAKASH MISHRA</td>

			        							<td>ELECTRONIC COMPONENTS AND DEVICES</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>UNIT -3</td>
			        							<td>COMPARISON OF FET AND BJT.</td>                                              <td><a href='https://youtu.be/UWk9-PWJXZQ' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EL575DifferencebetweenBJTandFET.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>unit 4</td>
			        							<td>current electricity</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS292CURRENTELECTRICITY.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>unit 5</td>
			        							<td>magnetism</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS762MAGNETIC-EFFECTS-OF-CURRENT-MAGNETISM.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>unit 5</td>
			        							<td>electromagnetic induction and alternating current</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS544ELECTROMAGNETICINDUCTIONALTERNATINGCURRENTS.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>unit 6</td>
			        							<td>semiconductor physics</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS457semiconductorphysics.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>OM PRAKASH MISHRA</td>

			        							<td>ELECTRONIC COMPONENTS AND DEVICES</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>UNIT -3</td>
			        							<td>TRANSISTOR</td>                                              <td><a href='https://youtu.be/Wc8QkawyNLM' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EL804Basicconceptoftransistor11.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>REETA</td>

			        							<td>MULTIMEDIA AND ANIMATION</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Unit 4</td>
			        							<td>Multimedia authoring tools</td>                                              <td><a href='https://www.youtube.com/watch?v=RX7j6-rWY9U' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CS253MMAuthoringunit4.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>MITHILESH KUMAR SHARMA</td>

			        							<td>REFRIGERATION AND  AIR CONDITIONING.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>4</td>
			        							<td>Air Refrigeration System </td>                                              <td><a href='https://youtu.be/FKYDff9OqI8' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MC325Airrefrigerationsystem.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>REETA</td>

			        							<td>MULTIMEDIA AND ANIMATION</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Unit 3</td>
			        							<td>Lossy</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS907Lossy.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>OM PRAKASH MISHRA</td>

			        							<td>ELECTRONIC COMPONENTS AND DEVICES</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>UNIT -3</td>
			        							<td>BIASING AND UNBIASING OF TRANSISTER</td>                                              <td><a href='https://youtu.be/Dvb7v3d2heg' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EL7UnbiasingandBiasingofTransistor.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>REETA</td>

			        							<td>MULTIMEDIA AND ANIMATION</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Unit 3</td>
			        							<td>MPEG</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS99CS1stYrMPEG.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>REETA</td>

			        							<td>MULTIMEDIA AND ANIMATION</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Unit 3</td>
			        							<td>RIFF</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS708RIFF.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>OM PRAKASH MISHRA</td>

			        							<td>ELECTRONIC COMPONENTS AND DEVICES</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>UNIT -3</td>
			        							<td>COMPARISON OF FET AND BJT</td>                                              <td><a href='https://youtu.be/UWk9-PWJXZQ' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EL951DifferencebetweenBJTandFET.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>REETA</td>

			        							<td>MULTIMEDIA AND ANIMATION</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Unit 3</td>
			        							<td>MPEG1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS88MPEG2new.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>NAVEEN KUMAR RAO</td>

			        							<td>BASICS OF MECHANICAL AND ELECTRICAL ENGINEERING</td>
			        							<td>Civil Engineering</td>
			        							<td>2</td>
			        							<td> fuel and combustion</td>
			        							<td>Coal and its type</td>                                              <td><a href='https://youtu.be/nV9N5DySAW8' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>OM PRAKASH MISHRA</td>

			        							<td>ELECTRONIC COMPONENTS AND DEVICES</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>UNIT -1</td>
			        							<td>COLOUR CODIND OF RESISTOR</td>                                              <td><a href='https://youtu.be/eAe8m8ZJk78' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>REETA</td>

			        							<td>MULTIMEDIA AND ANIMATION</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Unit 4</td>
			        							<td>Hypermedia Application Design consideration</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS939HypermediaApplicationDesignconsideration.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>REETA</td>

			        							<td>MULTIMEDIA AND ANIMATION</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Unit 4</td>
			        							<td>difference</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS335difference.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>REETA</td>

			        							<td>MULTIMEDIA AND ANIMATION</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Unit 4</td>
			        							<td>user interface </td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS223userinterfacemm.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>OM PRAKASH MISHRA</td>

			        							<td>INDUSTRIAL ELECTRONIC AND TRANSDUCER</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>UNIT -1</td>
			        							<td>SCR</td>                                              <td><a href='https://youtu.be/PQxUfeJkT2A' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EL56SCR.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>REETA</td>

			        							<td>MULTIMEDIA AND ANIMATION</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Unit 5</td>
			        							<td>Zoom Control</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS6196ZoomControl.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ADARSH TRIPATHI</td>

			        							<td>UNIVERSAL HUMAN VALUES</td>
			        							<td>Mechanical CAD</td>
			        							<td>Select Semester</td>
			        							<td>01</td>
			        							<td>Human Values </td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MP711CamScanner06-02-2020182925.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>REETA</td>

			        							<td>MULTIMEDIA AND ANIMATION</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Unit 5</td>
			        							<td>Flash tool</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS6491FlashtoolUNIT-5.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>OM PRAKASH MISHRA</td>

			        							<td>INDUSTRIAL ELECTRONIC AND TRANSDUCER</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>UNIT 2</td>
			        							<td>ADVANTAGE AND APPLICATION OF THYRISTOR</td>                                              <td><a href='https://youtu.be/5ZkCGbzUO0o' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EL184ApplicationandAdvantageofThyristor.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>REETA</td>

			        							<td>MULTIMEDIA AND ANIMATION</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Unit 5</td>
			        							<td> flashTools</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS6612flashTools.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>OM PRAKASH MISHRA</td>

			        							<td>INDUSTRIAL ELECTRONIC AND TRANSDUCER</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>UNIT -3</td>
			        							<td>SMPS</td>                                              <td><a href='https://youtu.be/f5shKXJ1u7g' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EL144SMPS.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>REETA</td>

			        							<td>MULTIMEDIA AND ANIMATION</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Unit 5</td>
			        							<td>Arrow Tool</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS7413ArrowTool.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>REETA</td>

			        							<td>MULTIMEDIA AND ANIMATION</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Unit 5</td>
			        							<td> Pen tool</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS1324Pentool.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>OM PRAKASH MISHRA</td>

			        							<td>INDUSTRIAL ELECTRONIC AND TRANSDUCER</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>UNIT -5</td>
			        							<td>SIGNAL CONDITIONING</td>                                              <td><a href='https://youtu.be/9n6Jo-hMLks' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EL145signalconditioning.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>REETA</td>

			        							<td>MULTIMEDIA AND ANIMATION</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Unit 5</td>
			        							<td>LASSO TOOL</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS8005LASSOTOOL.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>REETA</td>

			        							<td>MULTIMEDIA AND ANIMATION</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Unit 6</td>
			        							<td>Unit 6_Animation</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS774Unit6Animation.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>OM PRAKASH MISHRA</td>

			        							<td>INDUSTRIAL ELECTRONIC AND TRANSDUCER</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>UNIT 2</td>
			        							<td>CYCLOCONVERTER</td>                                              <td><a href='https://youtu.be/X_jmFhWWgjI' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EL846cycloconverter.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>OM PRAKASH MISHRA</td>

			        							<td>ELECTRONIC COMPONENTS AND DEVICES</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>UNIT -3</td>
			        							<td>TRANSISTOR</td>                                              <td><a href='https://youtu.be/Wc8QkawyNLM' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EL899Basicconceptoftransistor.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>MITHILESH KUMAR SHARMA</td>

			        							<td>REFRIGERATION AND  AIR CONDITIONING.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>4</td>
			        							<td>Boot Strap Air Cooling system </td>                                              <td><a href='https://youtu.be/ePoy-p6KuNU' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MC855Airrefrigerationsystempart2bootstrap.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ANKITA SRIVASTAVA</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>6</td>
			        							<td>Air pollution</td>
			        							<td>Air pollution</td>                                              <td><a href='https://youtu.be/TTa-mLLlg4U' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>PRADEEP TIWARI</td>

			        							<td>METROLOGY & MEASURING INSTRUMENTS.</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>Unit 9</td>
			        							<td>Vibration measurement</td>                                              <td><a href='https://youtu.be/BbpX42iY3hs' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>PRADEEP TIWARI</td>

			        							<td>ENERGY CONSERVATION</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Unit 1</td>
			        							<td>Energy and classification</td>                                              <td><a href='https://youtu.be/Fceeg2AEHKU' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>PRADEEP TIWARI</td>

			        							<td>ENERGY CONSERVATION</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Unit 1</td>
			        							<td>Energy conservation act 2001</td>                                              <td><a href='https://youtu.be/2bx_6sq7FZg' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>PRADEEP TIWARI</td>

			        							<td>POWER PLANT ENGINEERING E</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Unit 1</td>
			        							<td>Thermal Power plant part 1</td>                                              <td><a href='https://youtu.be/3fyY75btpa0' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>PRADEEP TIWARI</td>

			        							<td>POWER PLANT ENGINEERING E</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Unit 1</td>
			        							<td>Thermal Power plant part 2</td>                                              <td><a href='https://youtu.be/BhQ-iSXViJc' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ANINDITA TRIVEDI</td>

			        							<td>Marketing Legislation</td>
			        							<td>MSM</td>
			        							<td>2</td>
			        							<td>1</td>
			        							<td>Contract</td>                                              <td><a href='https://youtu.be/8S7ca2EuAjg' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ANKITA SRIVASTAVA</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>6</td>
			        							<td>Disaster Management</td>
			        							<td>Disaster Management</td>                                              <td><a href='https://youtu.be/0HajQYIftQM' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ANKITA SRIVASTAVA</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>6</td>
			        							<td>Disaster Management</td>
			        							<td>Disaster Management</td>                                              <td><a href='https://youtu.be/0HajQYIftQM' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>AKHILESH TRIVEDI</td>

			        							<td>BASICS OF MECHANICAL AND ELECTRICAL ENGINEERING E</td>
			        							<td>Civil Engineering</td>
			        							<td>2</td>
			        							<td>1</td>
			        							<td>A.C circuit</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE967BMEEcivil.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>satellite communication</td>
			        							<td>basic idea of satellite communication</td>                                              <td><a href='https://www.youtube.com/watch?v=AU-tIDXUPT4&t=21s' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>digital switching system</td>
			        							<td>ocb-283</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL215mcselx3pm24-03.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>satellite communication</td>
			        							<td>block diagram of satellite communication</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL785mcselx3pm25-03.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AMIT KUMAR PANDEY</td>

			        							<td>BASIC ELECTRICAL ENGINEERING E</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>Various types of Power Plants</td>
			        							<td>Hydro Power Plant</td>                                              <td><a href='https://www.youtube.com/watch?v=-FfpQ9GLvKM&t=26s' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EE234HydroPowerPlant.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>satellite communication</td>
			        							<td>orbital velocity of satellite</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL58mcselx3pm26-03.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>satellite communication</td>
			        							<td>time period of satellite and geo stationary satellite</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL27mcselx3pm27-03.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>satellite communication</td>
			        							<td>launching of satellite</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL5mcselx3pm28-03.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>satellite communication</td>
			        							<td>apogee, perigee and  communication satellite link</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL168mcselx3pm30-03.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DHIRENDRA PAL</td>

			        							<td>APPLIED MATHEMATICS II</td>
			        							<td>Civil Engineering</td>
			        							<td>2</td>
			        							<td>INTEGRAL CALCULAS</td>
			        							<td>INTEGRATION BY SUBSTITUTION </td>                                              <td><a href='https://youtu.be/aog7QzM1110' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS918DMATH.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SUGANDHA TEJESWEE</td>

			        							<td>MICROPROCESSOR AND ITS APPLICATION</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Assembly language programme</td>
			        							<td>Addressing mode in 8085</td>                                              <td><a href='https://youtu.be/vA-aD4Ro6sg' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EL756SugandhaMPAELEX3rdGeneral(2).pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DHIRENDRA PAL</td>

			        							<td>APPLIED MATHEMATICS II</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>integral calculus</td>
			        							<td> Integration by Parts</td>                                              <td><a href='https://youtu.be/aog7QzM1110' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>satellite communication</td>
			        							<td>different sub system of satellite</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL373mcselx3pm31-03.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>satellite communication</td>
			        							<td>different sub system of satellite</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL523mcselx3pm31-03.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>satellite communication</td>
			        							<td>transponder</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL705mcselx3pm01-04.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>satellite communication</td>
			        							<td>satellite antenna  system</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL309mcselx3pm03-04.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>satellite communication</td>
			        							<td>gain pattern of antenna</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL42mcselx3pm4-4-20.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>satellite communication</td>
			        							<td>earth station technology</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL508mcselx3pm6-4-20.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>JAINESHWAR VERMA</td>

			        							<td>DESIGN OF STEEL AND MASONRY STRUCTURE E</td>
			        							<td>Civil Engineering</td>
			        							<td>6</td>
			        							<td>COLUMN BASE</td>
			        							<td> DSMS (COLUMN BASE-6)</td>                                              <td><a href='https://www.youtube.com/watch?v=_xw0tzL0wA0' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>JAINESHWAR VERMA</td>

			        							<td>GENERAL ENGINEERING</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>TIMBER</td>
			        							<td>TIMBER</td>                                              <td><a href='https://www.youtube.com/watch?v=4P99_9BkvEM' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>DEEPSHIKHA MISHRA</td>

			        							<td>RCC DRAWING E</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>Slab reinforcement </td>
			        							<td>One way slab</td>                                              <td><a href='https://youtu.be/BaLNnHLdiVo' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SUGANDHA TEJESWEE</td>

			        							<td>MICROPROCESSOR AND ITS APPLICATION</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Stack & Subroutines</td>
			        							<td> Instructions in 8085 (call and return)</td>                                              <td><a href='https://youtu.be/7loWzL1EUEk' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EL39SugandhaMPAELEX3rdyrGeneral(1).pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>MADHAVENDRA RAJ</td>

			        							<td>INDUSTRIAL ENGINEERING AND SAFETY</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>Production planning and control </td>
			        							<td>Production systems </td>                                              <td><a href='https://youtu.be/TqRpxjl0v8w' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>MADHAVENDRA RAJ</td>

			        							<td>INDUSTRIAL ENGINEERING AND SAFETY</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>Production planning and control </td>
			        							<td>Production systems </td>                                              <td><a href='https://youtu.be/TqRpxjl0v8w' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>GAURAV KUMAR KASHYAP</td>

			        							<td>ENVIRONMENTAL EDUCATION & DISASTER MANAGEMENT</td>
			        							<td>MSM</td>
			        							<td>2</td>
			        							<td>Disaster Management</td>
			        							<td>Disaster Management 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC376DisasterManagement1.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>GAURAV KUMAR KASHYAP</td>

			        							<td>ENVIRONMENTAL EDUCATION & DISASTER MANAGEMENT</td>
			        							<td>MSM</td>
			        							<td>2</td>
			        							<td>Disaster Management</td>
			        							<td>Disaster Management 2</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC131DisasterManagement2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>GAURAV KUMAR KASHYAP</td>

			        							<td>ENVIRONMENTAL EDUCATION & DISASTER MANAGEMENT</td>
			        							<td>MSM</td>
			        							<td>2</td>
			        							<td>Noise pollution</td>
			        							<td>Noise pollution 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC64EEDMध्वनिप्रदूषण.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>GAURAV KUMAR KASHYAP</td>

			        							<td>ENVIRONMENTAL EDUCATION & DISASTER MANAGEMENT</td>
			        							<td>MSM</td>
			        							<td>2</td>
			        							<td>Water pollution</td>
			        							<td>Water pollution 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC231Waterpollution.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>GAURAV KUMAR KASHYAP</td>

			        							<td>ENVIRONMENTAL EDUCATION & DISASTER MANAGEMENT</td>
			        							<td>MSM</td>
			        							<td>2</td>
			        							<td>Environmental Policies</td>
			        							<td>Environmental Policies 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC863EEDMपर्यावरणनीतियाँ.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>CONCEPT OF PROGRAMMING USING C</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Chapter No 2</td>
			        							<td>Operators</td>                                              <td><a href='https://youtu.be/i3hrD1rMJFk' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>GAURAV KUMAR KASHYAP</td>

			        							<td>ENVIRONMENTAL EDUCATION & DISASTER MANAGEMENT</td>
			        							<td>MSM</td>
			        							<td>2</td>
			        							<td>Acidic Rain</td>
			        							<td>Acidic Rain</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC110अम्लीयवर्षा.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>CONCEPT OF PROGRAMMING USING C</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Chapter 2</td>
			        							<td>Types of Operators</td>                                              <td><a href='https://youtu.be/DQmtGa-lNzo' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>GAURAV KUMAR KASHYAP</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT</td>
			        							<td>Mechanical CAD</td>
			        							<td>6</td>
			        							<td>Disaster Management</td>
			        							<td>Disaster Management 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC336DisasterManagement1.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>MITHILESH KUMAR SHARMA</td>

			        							<td>REFRIGERATION AND  AIR CONDITIONING.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Unit 5 </td>
			        							<td>Vapour Absorption System </td>                                              <td><a href='https://youtu.be/TlCIZNmt9Yo' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MC506vapourabsorptionsystem.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>GAURAV KUMAR KASHYAP</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT</td>
			        							<td>Mechanical CAD</td>
			        							<td>6</td>
			        							<td>Disaster Management</td>
			        							<td>Disaster Management 2</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC46DisasterManagement2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>MITHILESH KUMAR SHARMA</td>

			        							<td>REFRIGERATION AND  AIR CONDITIONING.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Unit 4</td>
			        							<td>Flexible Manufacturing System</td>                                              <td><a href='https://youtu.be/HVwzPsWGh9Y' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MC642CAD&MfgFMSpart1.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>GAURAV KUMAR KASHYAP</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT</td>
			        							<td>Mechanical CAD</td>
			        							<td>6</td>
			        							<td>Noise pollution</td>
			        							<td>Noise pollution</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC587EEDMध्वनिप्रदूषण.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SUGANDHA TEJESWEE</td>

			        							<td>MICROPROCESSOR AND ITS APPLICATION</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Pdf on I/O interfacing,Video on data transfer instructions</td>
			        							<td>IC 8255, IC 8253</td>                                              <td><a href='https://youtu.be/r8PKyCh79TY' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EL298NewDoc2020-06-02214451compressed.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>GAURAV KUMAR KASHYAP</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT</td>
			        							<td>Mechanical CAD</td>
			        							<td>6</td>
			        							<td>Water pollution</td>
			        							<td>Water pollution 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC341Waterpollution.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DILIP UPADHYAY</td>

			        							<td>ESTIMATING COSTING AND SPECIFICATION</td>
			        							<td>Architecture Assistantship</td>
			        							<td>4</td>
			        							<td>valuation </td>
			        							<td>valuation </td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AA344AA2NDYEAR,ESTIMATIONvaluation-).pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>GAURAV KUMAR KASHYAP</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT</td>
			        							<td>Mechanical CAD</td>
			        							<td>6</td>
			        							<td>Environmental policies</td>
			        							<td>Environmental policies 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC682EEDMपर्यावरणनीतियाँ.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DILIP UPADHYAY</td>

			        							<td>ESTIMATING COSTING AND SPECIFICATION</td>
			        							<td>Architecture Assistantship</td>
			        							<td>4</td>
			        							<td>Detail estimate</td>
			        							<td>center line estimate </td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AA482building-estimate-centre-line-methodcompressed.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>GAURAV KUMAR KASHYAP</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT</td>
			        							<td>Mechanical CAD</td>
			        							<td>6</td>
			        							<td>Acidic Rain</td>
			        							<td>Acidic Rain 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC987अम्लीयवर्षा.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>MITHILESH KUMAR SHARMA</td>

			        							<td>REFRIGERATION AND  AIR CONDITIONING.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Unit 4</td>
			        							<td>Requirements, Needs Advantage and Limitation of Flexible Manufacturing System</td>                                              <td><a href='https://youtu.be/IWAeTCjfwaA' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MC743CAD&MfgFMSpart2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL  STUDIES.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Impact Of Energy Usage on Environment</td>
			        							<td>ozone layer depletion</td>                                              <td><a href='https://youtu.be/3z2040CXOd0' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>GAURAV KUMAR KASHYAP</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>General Conditions of Equilibrium</td>
			        							<td>General Conditions of Equilibrium</td>                                              <td><a href='https://www.youtube.com/playlist?list=PLnYtEOqB8jFIasz5Y5_suL92UZrFc2gs2' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL  STUDIES.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Impact of energyusage on environment</td>
			        							<td>Acid Rain</td>                                              <td><a href='https://youtu.be/GCHYNnFKvyg' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>GAURAV KUMAR KASHYAP</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Center of gravity & Centroid</td>
			        							<td>Center of gravity & Centroid</td>                                              <td><a href='https://www.youtube.com/playlist?list=PLnYtEOqB8jFIAfttKAi688iLyaEqa55qhPLnYtEOqB8jFIasz5Y5_suL92UZrFc2gs2' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL  STUDIES.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>impact of energy usage on environment</td>
			        							<td>Green House Effect</td>                                              <td><a href='https://youtu.be/ccOio4QGldA' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL  STUDIES.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Introduction</td>
			        							<td>Water Cycle</td>                                              <td><a href='https://youtu.be/TJIS5Do5C10' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>MISSI K BHASKER</td>

			        							<td>ELECTRONIC INSTRUMENT AND MEASUREMENT</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>Impedance bridge and Q meter</td>
			        							<td>Introduction</td>                                              <td><a href='https://youtu.be/cl2gQRgG3uk' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EL253impedanceandQmeter-Introductionpart.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>GAURAV KUMAR KASHYAP</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Center of gravity & Centroid</td>
			        							<td>Center of gravity & Centroid 1</td>                                              <td><a href='https://youtu.be/Hc4zcPl4q6g' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>GAURAV KUMAR KASHYAP</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Center of gravity & Centroid</td>
			        							<td>Center of gravity & Centroid 2</td>                                              <td><a href='https://youtu.be/n2e61ZqIaSw' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION & DISASTER MANAGEMENT</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Introduction</td>
			        							<td>Acid Rain</td>                                              <td><a href='https://youtu.be/GCHYNnFKvyg' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>GAURAV KUMAR KASHYAP</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Center of gravity & Centroid</td>
			        							<td>Center of gravity & Centroid 3</td>                                              <td><a href='https://youtu.be/vuqPUbM5ZTU' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>MISSI K BHASKER</td>

			        							<td>ELECTRONIC INSTRUMENT AND MEASUREMENT</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>Impedance bridge and Q meter</td>
			        							<td>DC bridge </td>                                              <td><a href='https://youtu.be/ECoGdiEs5RU' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EL536impedanceandQmeter-wheatstoneBridge.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION & DISASTER MANAGEMENT</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Introduction</td>
			        							<td>Water Cycle</td>                                              <td><a href='https://youtu.be/GCHYNnFKvyg' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION & DISASTER MANAGEMENT</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Introduction</td>
			        							<td>Ozone Layer Depletion</td>                                              <td><a href='https://youtu.be/3z2040CXOd0' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION & DISASTER MANAGEMENT</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Introduction</td>
			        							<td>Green House Effect</td>                                              <td><a href='https://youtu.be/ccOio4QGldA' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION & DISASTER MANAGEMENT</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Noise Pollution</td>
			        							<td>Noise pollution</td>                                              <td><a href='https://youtu.be/-sjvDhhQz3g' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>MISSI K BHASKER</td>

			        							<td>ENERGY CONSERVATION</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>Electrical supply system and motors</td>
			        							<td>Electrical supply system</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL290electricalsupplysystemandmotorspart1.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT E</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Introduction</td>
			        							<td>Acid Rain</td>                                              <td><a href='https://youtu.be/GCHYNnFKvyg' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT E</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Introduction</td>
			        							<td>Ozone Layer Depletion</td>                                              <td><a href='https://youtu.be/3z2040CXOd0' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>AMIT KUMAR PANDEY</td>

			        							<td>TRANSMISSION AND DISTRIBUTION OF ELECTRICAL POWER E</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Power Factor</td>
			        							<td>Concept of Power Factor</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE765ConceptofPowerFactor.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>MISSI K BHASKER</td>

			        							<td>ENERGY CONSERVATION</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>Electrical supply system and motors</td>
			        							<td>Transformers</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL143electricalsupplysystemandmorors-Transformers.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT E</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Introduction</td>
			        							<td>Green House Effect</td>                                              <td><a href='https://youtu.be/3z2040CXOd0' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT E</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Introduction</td>
			        							<td>Water Cycle</td>                                              <td><a href='https://youtu.be/TJIS5Do5C10' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT E</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Noise Pollution</td>
			        							<td>Noise Pollution</td>                                              <td><a href='https://youtu.be/TJIS5Do5C10' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>KM SHALINI MISHRA</td>

			        							<td>GENERAL ENGINEERING</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>General engineering (civil)</td>
			        							<td>Raw materials </td>                                              <td><a href='https://youtu.be/soUYwcGbiXc' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>KM SHALINI MISHRA</td>

			        							<td>GENERAL ENGINEERING</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>General engineering (civil)</td>
			        							<td>Raw materials </td>                                              <td><a href='https://youtu.be/a6NqRPJErko' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT.</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>Introduction</td>
			        							<td>water cycle</td>                                              <td><a href='https://youtu.be/TJIS5Do5C10' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>MISSI K BHASKER</td>

			        							<td>ENERGY CONSERVATION</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>Electrical supply system and motors</td>
			        							<td>Electric Motors</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL690electricalsupplysystemandmotors-ELECTRICMOTORS.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT.</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>Introduction</td>
			        							<td>acid rain</td>                                              <td><a href='https://youtu.be/GCHYNnFKvyg' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT.</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>Introduction</td>
			        							<td>Green House Effect</td>                                              <td><a href='https://youtu.be/ccOio4QGldA' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT.</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>Introduction</td>
			        							<td>Ozone layer Depletion</td>                                              <td><a href='https://youtu.be/3z2040CXOd0' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT.</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>Noise Pollution</td>
			        							<td>Noise Pollution</td>                                              <td><a href='https://youtu.be/-sjvDhhQz3g' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>MISSI K BHASKER</td>

			        							<td>ENERGY CONSERVATION</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>Energy efficiency in electrical utilities</td>
			        							<td>Pump</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL524energyefficiencyinelectricalutilities-PUMP.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DINESH PRATAP SINGH</td>

			        							<td>SURVEYING I</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>Introduction-2</td>
			        							<td>surveying-1</td>                                              <td><a href='https://youtu.be/vMJHTeu0GsU' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CE113vvvvv.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Database System Concept and Data Modeling</td>
			        							<td>Three Level of Data Abstraction</td>                                              <td><a href='https://youtu.be/iFQCcOE8_9c' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>RUPESH GOKHLANI</td>

			        							<td>INDUSTRIAL ELECTRONICS AND CONTROL E</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Thyristor</td>
			        							<td>Silicon Controlled Rectifier</td>                                              <td><a href='https://www.youtube.com/watch?v=th35ZBsFw7I&t=18s' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Relational Model</td>
			        							<td>Outer Join</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS450OuterJoin.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DEEPSHIKHA MISHRA</td>

			        							<td>REINFORCED CEMENT CONCRETE STRUCTURES E</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>Introduction to limit state method </td>
			        							<td>Concept of limit state,definitions related to LSM</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CE2470NewDoc2020-06-02212216.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Relational Database Design</td>
			        							<td>Functional Dependency</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS270FunctionalDependency.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Relational Database Design</td>
			        							<td>Purpose of Normalization,Data Redundancy and Updating Anomalies</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS359Normalization.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>MISSI K BHASKER</td>

			        							<td>ENERGY CONSERVATION</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>Energy efficiency in electrical utilities</td>
			        							<td>Compressed air system</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL963energyefficiencyinelectricalutilities-Compressedairsystem.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Relational Database Design</td>
			        							<td>Multivalued Dependency and First Normal Form</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS955MultivaluedDependency.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Relational Database Design</td>
			        							<td>Second Normal Form</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS3692NF-compressed.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Relational Database Design</td>
			        							<td>Third Normal Form and Transitive Dependency</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS2773NFandTransitiveDependency.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Relational Database Design</td>
			        							<td>Boyce - Codd Normal Form</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS756BCNF.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Relational Database Design</td>
			        							<td>Fourth Normal Form and Multivalued Dependency</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS6424NFandMultivaluedDependency.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Relational Database Design</td>
			        							<td>Fifth Normal Form</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS550FifthNormalForm.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>PL-SQL</td>
			        							<td>PL-SQL introduction, User Defined Function, Control of Flow statement of PL- SQL</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS88PL-SQL.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>PL-SQL</td>
			        							<td>PL-SQL Block</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS12PL-SQLBlock.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>PL-SQL</td>
			        							<td>Variable Declaration in PL-SQL, Constants and Literals in PL-SQL</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS927VariableDeclarationinPL-SQL.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>PL-SQL</td>
			        							<td>Operators in PL-SQL</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS139OperatorsinPL-SQL.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>PL-SQL</td>
			        							<td>Cursor in PL-SQL</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS627CursorinPL-SQL.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>PL-SQL</td>
			        							<td>PL-SQL Triggers</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS65PL-SQLTriggers.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>PL-SQL</td>
			        							<td>PL-SQL Triggers</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS889PL-SQLTriggers1.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>PL-SQL</td>
			        							<td>PL-SQL Transaction</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS333PL-SQLTransaction.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>NO-SQL</td>
			        							<td>Introduction to NO-SQL</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS620IntroductiontoNOSQL.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>NO-SQL</td>
			        							<td>Advantages and Application of NO-SQL</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS455AdvantagesofNO-SQL.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Security</td>
			        							<td>Authorisation and Integrity Constraints</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS102AuthorisationandIntegrityConstraints.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Security</td>
			        							<td>Data Encryption</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS147DataEncryptioninDBMS.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Security</td>
			        							<td>Types of Encryption</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS235TypesofEncryption.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td></td>
			        							<td>Data Definition language and Introduction to SQL</td>                                              <td><a href='https://youtu.be/MhKDQ5nyZKA' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CS430SQL.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>My SQL/SQL</td>
			        							<td>Database Language</td>                                              <td><a href='https://youtu.be/MhKDQ5nyZKA' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CS327DatabaseLanguage.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PREM PRAKASH SINGH</td>

			        							<td>TRANSMISSION AND DISTRIBUTION OF ELECTRICAL POWER</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Mechanical Design of Overhead Lines </td>
			        							<td> Overhead Lines   ACCESSORIES</td>                                              <td><a href='https://youtu.be/pnz70-cNFe4' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION & DISASTER MANAGEMENT</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Introduction</td>
			        							<td>Acid Rain</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS359AcidRain.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION & DISASTER MANAGEMENT</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Introduction</td>
			        							<td>Green house effect</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS848GreenHouseEffect.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SUGANDHA TEJESWEE</td>

			        							<td>MICROPROCESSOR AND ITS APPLICATION</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>I/O interfacing </td>
			        							<td>8251 and 8237</td>                                              <td><a href='https://youtu.be/pDOG4Evp1PI' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EL520NewDoc2020-06-03011443.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PREM PRAKASH SINGH</td>

			        							<td>TRANSMISSION AND DISTRIBUTION OF ELECTRICAL POWER</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Mechanical design of overhead lines </td>
			        							<td>accessories </td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE298gg.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>SQL</td>
			        							<td>Introduction to SQL</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS306SQL.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>SQL</td>
			        							<td>SQL Create Index</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS220SQLcreateindex.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT E</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Introduction</td>
			        							<td>Acid Rain</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS534AcidRain.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>SQL</td>
			        							<td>SQL Where Clause</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS354SQLwhereclause.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>SQL</td>
			        							<td>SQL Data type</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS83SQLdatatype.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SUNIL KUMAR SINGH</td>

			        							<td>BASIC ELECTRICAL ENGINEERING</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>DC NETWORK THEOREMS</td>
			        							<td>NORTON THEOREMS </td>                                              <td><a href='https://youtu.be/lppXl0sq_w0' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>My SQL/ SQL</td>
			        							<td>SQL Create Index</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS747SQLcreateindex.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>My SQL/ SQL</td>
			        							<td>SQL Where Clause</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS533SQLwhereclause.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>My SQL/ SQL</td>
			        							<td>SQL data Type</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS984SQLdatatype.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SUNIL KUMAR SINGH</td>

			        							<td>BASIC ELECTRICAL ENGINEERING</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>DC NETWORK THEOREMS</td>
			        							<td>THEVENINS  THEOREM</td>                                              <td><a href='https://youtu.be/-f3B2vliCPw' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SUNIL KUMAR SINGH</td>

			        							<td>ELECTRICAL DESIGN DRAWING AND ESTIMATING I</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>ALARM CIRCUIT</td>
			        							<td>TRAFFIC LIGHT CONTROL CIRCUIT</td>                                              <td><a href='https://youtu.be/d2hlVMM-7uI' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SUNIL KUMAR SINGH</td>

			        							<td>ELECTRICAL DESIGN DRAWING AND ESTIMATING I</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>LIGHT AND FAN CIRCUIT</td>
			        							<td>SINGLE LIGHT POINT CONTROLLED FROM 3 PLACES </td>                                              <td><a href='https://youtu.be/ic_jT_XbK6E' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SUNIL KUMAR SINGH</td>

			        							<td>ELECTRICAL DESIGN DRAWING AND ESTIMATING I</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>LIGHT AND FAN CIRCUIT</td>
			        							<td>STAIR CASE WIRING</td>                                              <td><a href='https://youtu.be/2z-0EuO9qPo' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT.</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>Introduction</td>
			        							<td>Water cycle</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS920watercycle.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL  STUDIES.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Noise pollution</td>
			        							<td>Noise pollution</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS105noisepollution1.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL  STUDIES.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Noise pollution</td>
			        							<td>Noise pollution</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS677noisepollution1.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL  STUDIES.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Introduction</td>
			        							<td>Acid Rain</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS246AcidRain.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL  STUDIES.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Introduction</td>
			        							<td>Acid Rain</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS814AcidRain.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL  STUDIES.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Introduction</td>
			        							<td>Acid Rain</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS127AcidRain.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL  STUDIES.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Introduction</td>
			        							<td>Acid Rain</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS475AcidRain.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ABHAY KUMAR YADAV</td>

			        							<td>DESIGN OF STEEL AND MASONRY STRUCTURE</td>
			        							<td>Civil Engineering</td>
			        							<td>6</td>
			        							<td>4</td>
			        							<td>Compression member</td>                                              <td><a href='abhay5494@gmail.com' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ABHAY KUMAR YADAV</td>

			        							<td>DESIGN OF STEEL AND MASONRY STRUCTURE</td>
			        							<td>Civil Engineering</td>
			        							<td>6</td>
			        							<td>4</td>
			        							<td>Compression member</td>                                              <td><a href='https://youtu.be/X_xIgp9LEiI' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ABHAY KUMAR YADAV</td>

			        							<td>DESIGN OF STEEL AND MASONRY STRUCTURE</td>
			        							<td>Civil Engineering</td>
			        							<td>6</td>
			        							<td>4</td>
			        							<td>Compression member</td>                                              <td><a href='https://youtu.be/FNiSs-T8YYs' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ABHAY KUMAR YADAV</td>

			        							<td>DESIGN OF STEEL AND MASONRY STRUCTURE</td>
			        							<td>Civil Engineering</td>
			        							<td>6</td>
			        							<td>5</td>
			        							<td>Steel beam</td>                                              <td><a href='https://youtu.be/-OAGP-AVWBw' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ABHAY KUMAR YADAV</td>

			        							<td>DESIGN OF STEEL AND MASONRY STRUCTURE</td>
			        							<td>Civil Engineering</td>
			        							<td>6</td>
			        							<td>6</td>
			        							<td>Steel beam</td>                                              <td><a href='https://youtu.be/1Pnq9X6FWjE' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>DEEPSHIKHA MISHRA</td>

			        							<td>REINFORCED CEMENT CONCRETE STRUCTURES E</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>Introduction to limit state method </td>
			        							<td>Stress-Strain relationship for steel & concrete,basic assimptions in lsm</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CE6115911481057411591148091266159114808684215911474111810NewDoc2020-06-02212216.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DEEPSHIKHA MISHRA</td>

			        							<td>REINFORCED CEMENT CONCRETE STRUCTURES E</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>Introduction to limit state method </td>
			        							<td>Analysis of singly reinforced beam </td>                                              <td><a href='https://youtu.be/g8ZCezh90Do' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CE57715911482500460NewDoc2020-06-02212216.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DEEPSHIKHA MISHRA</td>

			        							<td>REINFORCED CEMENT CONCRETE STRUCTURES E</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>Introduction to limit state method </td>
			        							<td>Limiting neutral axis, limiting depth factor for different grade of steel</td>                                              <td><a href='https://youtu.be/tjJ0nDCw_AQ' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CE179159114868177015911486415360NewDoc2020-06-02212216.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DEEPSHIKHA MISHRA</td>

			        							<td>REINFORCED CEMENT CONCRETE STRUCTURES E</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>Introduction to limit state method </td>
			        							<td>Limiting resistance factor,types of sections</td>                                              <td><a href='https://youtu.be/VJRMQscCsvM' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CE1480RCCcivil2nd(evening)-DeepshikhaMishra.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION & DISASTER MANAGEMENT</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Introduction</td>
			        							<td>Acid Rain</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS30AcidRain.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION & DISASTER MANAGEMENT</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Introduction</td>
			        							<td>Green house effect</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS511GreenHouseEffect.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DEEPSHIKHA MISHRA</td>

			        							<td>CIVIL ENGINEERING DRAWING II E</td>
			        							<td>Civil Engineering</td>
			        							<td>6</td>
			        							<td>Steel drawing</td>
			        							<td>Steel roof truss</td>                                              <td><a href='https://youtu.be/1A64ssByvzI' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CE12820200603074154.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DEEPSHIKHA MISHRA</td>

			        							<td>CIVIL ENGINEERING DRAWING II E</td>
			        							<td>Civil Engineering</td>
			        							<td>6</td>
			        							<td>Rcc drawing</td>
			        							<td>One way slab</td>                                              <td><a href='https://youtu.be/BaLNnHLdiVo' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>MISSI K BHASKER</td>

			        							<td>ELECTRONIC INSTRUMENT AND MEASUREMENT</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>Impedance bridge and Q meter</td>
			        							<td>AC Bridges</td>                                              <td><a href='https://youtu.be/JCxXFyao5d0' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EL353impedancebridgeandQmeter-ACBridges.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAVESH KUMAR CHAUHAN</td>

			        							<td>E COMMERCE AND DIGITAL MARKETING</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Google_analytics Unit 6</td>
			        							<td>Types of Goals in Google Analytics</td>                                              <td><a href='https://support.google.com/analytics/answer/1032415?hl=en' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CS204TypesofGoalsinGoogleAnalytics.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAVESH KUMAR CHAUHAN</td>

			        							<td>E COMMERCE AND DIGITAL MARKETING</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Google_analytics Unit 6</td>
			        							<td>Track Social Media Traffic With Google Analytics (Step by Step)</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS432TrackSocialMediaTrafficWithGoogleAnalytics(StepbyStep).pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SUGANDHA TEJESWEE</td>

			        							<td>MICROPROCESSOR AND ITS APPLICATION</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>I/O interfacing </td>
			        							<td>RS-232</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL731SugandhaMPAElex3rdyr(G)(3).pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAVESH KUMAR CHAUHAN</td>

			        							<td>E COMMERCE AND DIGITAL MARKETING</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Google_analytics Unit 6</td>
			        							<td>Track SEO Results Using Google Analytics</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS19TrackSEOResultsUsingGoogleAnalytics.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SUGANDHA TEJESWEE</td>

			        							<td>MICROPROCESSOR AND ITS APPLICATION</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Microcontroller</td>
			        							<td>8051</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL799SUGANDHAMPAElex3rd(G).pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ANIL KUMAR YADAV</td>

			        							<td>ELECTRICAL DESIGN DRAWING AND ESTIMATING II E</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Electrical earthing and safety</td>
			        							<td>Plate type earthing</td>                                              <td><a href='https://youtu.be/42S2kA8yQKY' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ANIL KUMAR YADAV</td>

			        							<td>ELECTRICAL DESIGN DRAWING AND ESTIMATING II E</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Electrical substation</td>
			        							<td>Multi line diagram of substation</td>                                              <td><a href='https://youtu.be/Iq5Lkpyaifg' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>PRAVESH KUMAR CHAUHAN</td>

			        							<td>E COMMERCE AND DIGITAL MARKETING</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Google_analytics Unit 6</td>
			        							<td>Integrating your Google AdWords campaigns into Google Analytics</td>                                              <td><a href='https://support.google.com/analytics/answer/1033961?hl=en' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CS8IntegratingyourGoogleAdWordscampaignsinto.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHIVENDRA PRATAP SINGH</td>

			        							<td>ENERGY  CONSERVATION.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Energy conservation building code</td>
			        							<td>Introduction of ECBC</td>                                              <td><a href='https://youtu.be/jrk8fNhbRjM' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MC169MEP2NDYEAR,ENERGYCONSERVATION,CHAPTER-7,By-SHIVENDRA.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ANIL KUMAR YADAV</td>

			        							<td>ELECTRICAL DESIGN DRAWING AND ESTIMATING II E</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Overhead lines</td>
			        							<td>Determination of size of a cable/AAC</td>                                              <td><a href='https://youtu.be/P02EuVBiQXE' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ABHISHEK SHARMA</td>

			        							<td>UTILIZATION OF ELECTRICAL ENERGY E</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Unit-2</td>
			        							<td>Electrical Tariff,Part-1</td>                                              <td><a href='https://youtu.be/-KOrPxHZnQw' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SHIVENDRA PRATAP SINGH</td>

			        							<td>ENERGY  CONSERVATION.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Energy conservation building code</td>
			        							<td>7.1	ECBC and its salient features </td>                                              <td><a href='https://youtu.be/7E3aTcIY7g8' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MC883MEP2NDYEAR,ENERGYCONSERVATION,CHAPTER-7,By-SHIVENDRA.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SAUMYA MISHRA</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Psychrometry</td>
			        							<td>Applied Psychrometry</td>                                              <td><a href='https://www.youtube.com/watch?v=XevhxmrR_ZU&t=26s' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ABHISHEK SHARMA</td>

			        							<td>UTILIZATION OF ELECTRICAL ENERGY E</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Unit-2</td>
			        							<td>Electrical Tariff, Part-2</td>                                              <td><a href='https://youtu.be/IFPFsWTBVZg' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SAUMYA MISHRA</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Psychrometry</td>
			        							<td>Adiabatic Saturation Process</td>                                              <td><a href='https://www.youtube.com/watch?v=4PSocSfpdOQ&t=48s' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SHIVENDRA PRATAP SINGH</td>

			        							<td>INDUSTRIAL ENGG.& SAFETY.</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>PRODUCTION, PLANNING AND CONTROL</td>
			        							<td>Methods of production</td>                                              <td><a href='https://youtu.be/lH1SXxf8eB4' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MC165MPE3RDYEAR,SUBJECT-IES,CHAPTER-3,BY-SHIVENDRA.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHIVENDRA PRATAP SINGH</td>

			        							<td>INDUSTRIAL ENGG.& SAFETY.</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>PRODUCTION, PLANNING AND CONTROL</td>
			        							<td>Methods of production</td>                                              <td><a href='https://youtu.be/Kdu0dZM7tCg' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MC872MPE3RDYEAR,SUBJECT-IES,CHAPTER-3,BY-SHIVENDRA.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>POONAM SHARMA</td>

			        							<td>COMMUNICATION SKILLS II E</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>Chapter 1 </td>
			        							<td>Prepositions part 2</td>                                              <td><a href='https://youtu.be/Aeb1cN_yj08' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>PRAVESH KUMAR CHAUHAN</td>

			        							<td>E COMMERCE</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>6</td>
			        							<td>E-Marketing Unit 8</td>
			        							<td>E-Marketing Complete Chapter</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS871E-Marketing.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION & DISASTER MANAGEMENT</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Introduction</td>
			        							<td>Green house effect</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS694GreenHouseEffect.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DEEP SHIKHA</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Electrostatic </td>
			        							<td>Concept of charge</td>                                              <td><a href='https://youtu.be/8L0ocRw91KY' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS866IMG20200603085354.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DEEP SHIKHA</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Electrostatic </td>
			        							<td>Concept of charge</td>                                              <td><a href='https://youtu.be/8L0ocRw91KY' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS284IMG20200603084703.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DEEP SHIKHA</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Electrostatic </td>
			        							<td>Concept of charge</td>                                              <td><a href='https://youtu.be/8L0ocRw91KY' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS225IMG20200603084815.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DEEP SHIKHA</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Electrostatic </td>
			        							<td>Concept of charge</td>                                              <td><a href='https://youtu.be/8L0ocRw91KY' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS336IMG20200603084838.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DEEP SHIKHA</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Electrostatic </td>
			        							<td>Concept of charge</td>                                              <td><a href='https://youtu.be/8L0ocRw91KY' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS641IMG20200603084940.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DEEP SHIKHA</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Electrostatic </td>
			        							<td>Concept of charge</td>                                              <td><a href='https://youtu.be/8L0ocRw91KY' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS852IMG20200603085018.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DEEP SHIKHA</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>Electrostatic </td>
			        							<td>Concept of charge</td>                                              <td><a href='https://youtu.be/8L0ocRw91KY' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS862IMG20200603085354.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DEEP SHIKHA</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>Electrostatic </td>
			        							<td>Concept of charge</td>                                              <td><a href='https://youtu.be/8L0ocRw91KY' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS436IMG20200603084703.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DEEP SHIKHA</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>Electrostatic </td>
			        							<td>Concept of charge</td>                                              <td><a href='https://youtu.be/8L0ocRw91KY' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS852IMG20200603084815.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DEEP SHIKHA</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>Electrostatic </td>
			        							<td>Concept of charge</td>                                              <td><a href='https://youtu.be/8L0ocRw91KY' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS20IMG20200603084838.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>POONAM SHARMA</td>

			        							<td>FUNCTIONAL COMMUNICATION</td>
			        							<td>Architecture Assistantship</td>
			        							<td>4</td>
			        							<td>Grammar</td>
			        							<td>Transformation</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS466AAIIndyear(Transformation).pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PC KAUSHIK</td>

			        							<td>METROLOGY AND MEASURING INSTRUEMENTS</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>TRANSDUCER</td>
			        							<td>TRANSDUCER PART-1</td>                                              <td><a href='https://www.youtube.com/watch?v=dpr_Gmhz_iY' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>PC KAUSHIK</td>

			        							<td>METROLOGY AND MEASURING INSTRUEMENTS</td>
			        							<td>Mechanical CAD</td>
			        							<td>6</td>
			        							<td>TRANSDUCER</td>
			        							<td>TRANSDUCER PART-1</td>                                              <td><a href='https://www.youtube.com/watch?v=dpr_Gmhz_iY' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATH-II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>The point in space</td>
			        							<td>Direction Cosines , Direction ratios </td>                                              <td><a href='https://youtu.be/If_-hiyjY_w' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS386Lecture-606-03-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHEMATICS 1 B</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>The point in space </td>
			        							<td>Direction Cosines , Direction ratios  </td>                                              <td><a href='https://youtu.be/If_-hiyjY_w' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS625Lecture-606-03-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHS II</td>
			        							<td>Civil Engineering</td>
			        							<td>2</td>
			        							<td>The point in space   </td>
			        							<td>Direction Cosines , Direction ratios    </td>                                              <td><a href='https://youtu.be/If_-hiyjY_w' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS903Lecture-606-03-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHIVENDRA PRATAP SINGH</td>

			        							<td>INDUSTRIAL ENGG.& SAFETY.</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>PLANT LAYOUT</td>
			        							<td>OBJECTIVE OF PLANT LAYOUT</td>                                              <td><a href='https://youtu.be/N2SgUpHAoeA' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MC926MPE3RDYEAR,SUBJECT-IES,CHAPTER-5,BY-SHIVENDRA.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATH-II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>The point in space      </td>
			        							<td>Direction Cosines , Direction ratios  </td>                                              <td><a href='https://youtu.be/OqhFriWbxOE' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS917Lecture-706-03-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHEMATICS 1 B</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>The point in space       </td>
			        							<td>Direction Cosines , Direction ratios     </td>                                              <td><a href='https://youtu.be/OqhFriWbxOE ' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS662Lecture-706-03-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHS II</td>
			        							<td>Civil Engineering</td>
			        							<td>2</td>
			        							<td>The point in space       </td>
			        							<td>Direction Cosines , Direction ratios       </td>                                              <td><a href='https://youtu.be/OqhFriWbxOE' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS440Lecture-706-03-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHEMATICS II</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>The point in space        </td>
			        							<td>Direction Cosines , Direction ratios       </td>                                              <td><a href='https://youtu.be/OqhFriWbxOE ' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS464Lecture-706-03-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>MADHAVENDRA RAJ</td>

			        							<td>INDUSTRIAL ENGINEERING AND SAFETY</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>Production planning and control </td>
			        							<td>Production systems </td>                                              <td><a href='https://youtu.be/TqRpxjl0v8w' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SAURABH KUMAR SONI</td>

			        							<td>PRODUCTION TECHNOLOGY II</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>ZERO DEFECT  CONCEPT</td>
			        							<td>PROCESS CONTROL</td>                                              <td><a href=' https://youtu.be/9FWzYJYmNNE' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SAURABH KUMAR SONI</td>

			        							<td>CNC MACHINE AND AUTOMATION</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>ZERO DEFECT  CONCEPT</td>
			        							<td>PROCESS CONTROL</td>                                              <td><a href=' https://youtu.be/9FWzYJYmNNE' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>PANKAJ CHAUHAN</td>

			        							<td>CONSTRUCTION AND MATERIAL C</td>
			        							<td>Architecture Assistantship</td>
			        							<td>6</td>
			        							<td>Temporary work </td>
			        							<td>Topic 5</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AA886topic5.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>VIVEKANAND YADAV</td>

			        							<td>HYDRAULICS AND  PNEUMATICS.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Unit-3</td>
			        							<td>Flow of fluids</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MP41Continuityequation.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>VIVEKANAND YADAV</td>

			        							<td>HYDRAULICS AND  PNEUMATICS.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Unit-5</td>
			        							<td>Centre of gravity</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MP784Centreofgravity.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>VIVEKANAND YADAV</td>

			        							<td>APPLIED MECHANICS.</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Unit-5</td>
			        							<td>Centre of gravity</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MP925Centreofgravity.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>UTKERSH TRIPATHI</td>

			        							<td>PRODUCTION TECHNOLOGY-II.</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>PRODUCTION OF PLASTICS(unit-2)</td>
			        							<td>Plastics moulding</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MP153moulding-1.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>NAVEEN KUMAR RAO</td>

			        							<td>HYDRAULICS AND PNEUMATICS</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Flow through pipes</td>
			        							<td> Darcy and chezys equation ( numerical)</td>                                              <td><a href='https://youtu.be/fSzsX9g9qnE' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>UTKERSH TRIPATHI</td>

			        							<td>PRODUCTION TECHNOLOGY-II.</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>PRODUCTION OF PLASTICS(unit-2)</td>
			        							<td>Plastics moulding</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MP813moulding-2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>NAVEEN KUMAR RAO</td>

			        							<td>HYDRAULICS AND PNEUMATICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Flow through pipes</td>
			        							<td> Darcy and chezys equation( numerical)</td>                                              <td><a href='https://youtu.be/fSzsX9g9qnE' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>UTKERSH TRIPATHI</td>

			        							<td>PRODUCTION TECHNOLOGY-II.</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>PRODUCTION OF PLASTICS(unit-2)</td>
			        							<td>Plastics moulding</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MP582moulding-03.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHAHNAZ KHATOON</td>

			        							<td>MICROWAVE AND RADAR ENGG</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Radar</td>
			        							<td>Radar</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL7073rdyrelectronics(MR&E).pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RUPESH GOKHLANI</td>

			        							<td>ANALOG ELECTRONICS E</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>Chapter 2</td>
			        							<td>Bipolar Junction Transistor </td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL950BJTNotescompressed.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RUPESH GOKHLANI</td>

			        							<td>ANALOG ELECTRONICS E</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>Chapter 3</td>
			        							<td>Transistor Biasing </td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL84TransistorBiasingcompressed.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>R R SINGH</td>

			        							<td>IRRIGATION ENGINEERING</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>Irrigation</td>
			        							<td>Introduction of Irrigation Engineering</td>                                              <td><a href='https://youtu.be/Ppskt8M8Xx4' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>R R SINGH</td>

			        							<td>IRRIGATION ENGINEERING</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>Irrigation</td>
			        							<td>Introduction of Irrigation Engineering</td>                                              <td><a href='https://youtu.be/Ppskt8M8Xx4' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>R R SINGH</td>

			        							<td>IRRIGATION ENGINEERING</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>Irrigation </td>
			        							<td>Introduction of irrigation </td>                                              <td><a href='https://youtu.be/Ppskt8M8Xx4' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SHAHNAZ KHATOON</td>

			        							<td>MICROWAVE AND RADAR ENGG</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Microwave </td>
			        							<td>Multi cavity magnetron</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL989magnetron.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>satellite communication</td>
			        							<td>multiple access technique</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL876mcselx3pm7-4-20.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>satellite communication</td>
			        							<td>DTH</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL867mcselx3pm8-4-20.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHAHNAZ KHATOON</td>

			        							<td>MICROWAVE AND RADAR ENGG</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Microwave </td>
			        							<td>Principal of magnetron</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL479principalofmagnetron.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>satellite communication</td>
			        							<td>satellite link design</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL627mcselx3pm9-4-20.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>NAVEEN KUMAR RAO</td>

			        							<td>BASICS OF MECHANICAL AND ELECTRICAL ENGINEERING</td>
			        							<td>Civil Engineering</td>
			        							<td>2</td>
			        							<td>ac fundamentals</td>
			        							<td>basic definition</td>                                              <td><a href='https://youtu.be/NIFSRDR5T6A' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>mobile communication</td>
			        							<td>wireless or mobile communication basic</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL209MCSelx3pm15-04-20.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>NAVEEN KUMAR RAO</td>

			        							<td>BASICS OF MECHANICAL AND ELECTRICAL ENGINEERING</td>
			        							<td>Civil Engineering</td>
			        							<td>2</td>
			        							<td> ac fundamentals</td>
			        							<td> basic definition</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC538acfundamentals.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>mobile communication</td>
			        							<td>amps, frequency reuse</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL655mcselx3pm16-04-20.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>mobile communication</td>
			        							<td>movement of subscriber from one cell area to other,advantage of wireless communication</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL594mcselx3pm17-04-20.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DEEP SHIKHA</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>Electrostatic </td>
			        							<td>Concept of charge</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS174CamScanner06-03-20200856021.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>mobile communication</td>
			        							<td>history of cellular telephone</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL712mcselx3pm18-4-20.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHAHNAZ KHATOON</td>

			        							<td>MICROWAVE AND RADAR ENGG</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Microwave </td>
			        							<td>Trapatt diode</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL677trapatdiode.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAHUL MAURYA</td>

			        							<td>NETWORK FILTERS AND TRANSMISSION LINES</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>ATTENUATORS</td>
			        							<td>attenuator</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL131attenuators-min.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>mobile communication</td>
			        							<td>medium access control</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL463mcselx3pm20-04-20.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>mobile communication</td>
			        							<td>GSM basic</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL653mcselx3pm21-04-20.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>mobile communication</td>
			        							<td>GSM frame structure, GSM system structure and use of GSM</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL997mcselx3pm22-04-20.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>CONCEPT OF PROGRAMMING USING C</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Chapter 2</td>
			        							<td>Operator</td>                                              <td><a href='https://youtu.be/i3hrD1rMJFk' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>mobile communication</td>
			        							<td>GPS </td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL538mcselx3pm23-4-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHAHNAZ KHATOON</td>

			        							<td>MICROWAVE AND RADAR ENGG</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Microwave </td>
			        							<td>Isolator.</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL7193rdyearelectronicsisolators.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHAHNAZ KHATOON</td>

			        							<td>MICROWAVE AND RADAR ENGG</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Microwave </td>
			        							<td>Microwave link</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL317microwavelink.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHAHNAZ KHATOON</td>

			        							<td>MICROWAVE AND RADAR ENGG</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Microwave </td>
			        							<td>Magnetron</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL847magnetron.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHAHNAZ KHATOON</td>

			        							<td>MICROWAVE AND RADAR ENGG</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Microwave </td>
			        							<td>Inter electrode capacitance and lead inductance</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL400interelectrode.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHAHNAZ KHATOON</td>

			        							<td>MICROWAVE AND RADAR ENGG</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Microwave </td>
			        							<td>Klytstron</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL499klystron.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>VISHAL SINGH NEGI</td>

			        							<td>ENERGY CONSERVATION</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Energy Efficiency in Thermal Utilities</td>
			        							<td>Part I</td>                                              <td><a href='https://youtu.be/6lBfuh2IBNM' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SHAHNAZ KHATOON</td>

			        							<td>MICROWAVE AND RADAR ENGG</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Radar</td>
			        							<td>Radar</td>                                              <td><a href='https://youtu.be/8La5F2G0cf0' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SHAHNAZ KHATOON</td>

			        							<td>MICROWAVE AND RADAR ENGG</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Microwave </td>
			        							<td>Waveguides.</td>                                              <td><a href='https://youtu.be/1zLNU4DJrDs' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SHAHNAZ KHATOON</td>

			        							<td>MICROWAVE AND RADAR ENGG</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Microwave </td>
			        							<td>Microwave tee junction</td>                                              <td><a href='https://youtu.be/ai-17ay2aBU' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SHAHNAZ KHATOON</td>

			        							<td>MICROWAVE AND RADAR ENGG</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Microwave </td>
			        							<td>Microwave magic tee junction</td>                                              <td><a href='https://youtu.be/ai-17ay2aBU' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SUGANDHA TEJESWEE</td>

			        							<td>MICROPROCESSOR AND ITS APPLICATION</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>8086 microprocessor</td>
			        							<td>8086</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL880NewDoc2020-06-03125048compressed.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>VISHAL SINGH NEGI</td>

			        							<td>ENERGY CONSERVATION</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Energy Efficiency in Thermal Utilities</td>
			        							<td>Part I</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS595EnergyEfficiencyinElectricalUtilities-5391.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>VISHAL SINGH NEGI</td>

			        							<td>ENERGY CONSERVATION</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Energy Efficiency in Thermal Utilities</td>
			        							<td>Part II</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS91EnergyEfficiencyinElectricalUtilities-5392.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>VISHAL SINGH NEGI</td>

			        							<td>NETWORK ADMINISTRATION AND SECURITY</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>6</td>
			        							<td>VPN</td>
			        							<td>Virtual Private Network </td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS6391587051796content.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SUGANDHA TEJESWEE</td>

			        							<td>MICROPROCESSOR AND ITS APPLICATION</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Data transfer scheme</td>
			        							<td>Data transfer schemes </td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL725Sugandha-MPA-Elex3rd-(G).pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SATYWAN VERMA</td>

			        							<td>PRODUCTION TECH. LAB.</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>Machine shop</td>
			        							<td>Safety</td>                                              <td><a href='https://youtu.be/xBfZJRBTC7I' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ANKITA SRIVASTAVA</td>

			        							<td>OBJECT ORIENTED PROGRAMMING USING JAVA</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Multithreading</td>
			        							<td>Multithreading</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS525Multithreading.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ANKITA SRIVASTAVA</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>6</td>
			        							<td>Water Prevention and Control of Pollution</td>
			        							<td>Water Prevention and Control of Pollution</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS489WaterPreventionandControlofPollution.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ANKITA SRIVASTAVA</td>

			        							<td>OBJECT ORIENTED PROGRAMMING USING JAVA</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Constructors in java</td>
			        							<td>Constructors</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS308Constructor.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ANKITA SRIVASTAVA</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>6</td>
			        							<td>Water Prevention and Control of Pollution Act</td>
			        							<td>Water Prevention and Control of Pollution Act</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS580prevention.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ABHAY KUMAR YADAV</td>

			        							<td>EARTHQUAKE ENGINEERING</td>
			        							<td>Civil Engineering</td>
			        							<td>6</td>
			        							<td>4</td>
			        							<td>Earthquake resistant building</td>                                              <td><a href='https://youtu.be/fd7DzoZM5sM' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ABHAY KUMAR YADAV</td>

			        							<td>EARTHQUAKE ENGINEERING</td>
			        							<td>Civil Engineering</td>
			        							<td>6</td>
			        							<td>6</td>
			        							<td>Earthquake resistant building guidelines</td>                                              <td><a href='https://youtu.be/PVlgPKsmbz0' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>DINESH PRATAP SINGH</td>

			        							<td>SURVEYING I</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>surveying-1</td>
			        							<td>unit-2</td>                                              <td><a href='https://youtu.be/rmAjVzUmueY' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>YASHI TIWARI</td>

			        							<td>INDUSTRIAL ELECTRONICS AND CONTROL</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Chapter 1</td>
			        							<td>Introduction to power electronics </td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL873IECLecture012.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>YASHI TIWARI</td>

			        							<td>ANALOG ELECTRONICS</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>Chapter 1</td>
			        							<td>Introduction to semiconductors </td>                                              <td><a href='https://youtu.be/Se2au5GAVKU' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EL946AnalogElectronicslecture14(2).jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>YASHI TIWARI</td>

			        							<td>INDUSTRIAL ELECTRONICS AND CONTROL</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Chapter 1</td>
			        							<td>Introduction to power electronics </td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL467IECLecture011.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>YASHI TIWARI</td>

			        							<td>ANALOG ELECTRONICS</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>Chapter 1</td>
			        							<td>Introduction to semiconductors </td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL438AnalogElectronicslecture1(1)1.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS  II</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>ch 4</td>
			        							<td>current electricity</td>                                              <td><a href='https://youtu.be/mRlIbxPICs4' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>ch 4</td>
			        							<td>current electricity</td>                                              <td><a href='https://youtu.be/mRlIbxPICs4' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>ch 4</td>
			        							<td>current electricity</td>                                              <td><a href='https://youtu.be/mRlIbxPICs4' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>DR AVINASH BAHADUR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Environmental impact assessment</td>
			        							<td>Environmental impact assessment</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS705IMG20200604080957.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DR AVINASH BAHADUR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Environmental impact assessment</td>
			        							<td>Environmental impact assessment</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS289IMG20200604080957.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DR AVINASH BAHADUR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Environmental impact assessment</td>
			        							<td>Environmental impact assessment</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS145IMG20200604081021.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DR AVINASH BAHADUR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Environmental impact assessment</td>
			        							<td>Environmental impact assessment</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS359IMG20200604081056.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DR AVINASH BAHADUR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Environmental impact assessment</td>
			        							<td>Environmental impact assessment</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS198IMG20200604081114.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DR AVINASH BAHADUR SINGH</td>

			        							<td>ENVIRONMENTAL STUDIES</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Environmental impact assessment</td>
			        							<td>Environmental impact assessment</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS305IMG20200604080957.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DR AVINASH BAHADUR SINGH</td>

			        							<td>ENVIRONMENTAL STUDIES</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Environmental impact assessment</td>
			        							<td>Environmental impact assessment</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS151IMG20200604081021.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DR AVINASH BAHADUR SINGH</td>

			        							<td>ENVIRONMENTAL STUDIES</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Environmental impact assessment</td>
			        							<td>Environmental impact assessment</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS466IMG20200604081056.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DR AVINASH BAHADUR SINGH</td>

			        							<td>ENVIRONMENTAL STUDIES</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Environmental impact assessment</td>
			        							<td>Environmental impact assessment</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS389IMG20200604081114.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DR AVINASH BAHADUR SINGH</td>

			        							<td>ENVIRONMENTAL STUDIES</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Environmental impact assessment</td>
			        							<td>Environmental impact assessment</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS518IMG20200604080957.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DR AVINASH BAHADUR SINGH</td>

			        							<td>ENVIRONMENTAL STUDIES</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Environmental impact assessment</td>
			        							<td>Environmental impact assessment</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS404IMG20200604081021.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DR AVINASH BAHADUR SINGH</td>

			        							<td>ENVIRONMENTAL STUDIES</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Environmental impact assessment</td>
			        							<td>Environmental impact assessment</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS957IMG20200604081056.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DR AVINASH BAHADUR SINGH</td>

			        							<td>ENVIRONMENTAL STUDIES</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Environmental impact assessment</td>
			        							<td>Environmental impact assessment</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS624IMG20200604081114.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DEEP SHIKHA</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>Electrostatic </td>
			        							<td>What is charge</td>                                              <td><a href='https://youtu.be/3nWrd0YrOjY' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS615IMG20200603084703.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DEEP SHIKHA</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Electrostatic </td>
			        							<td>What is charge</td>                                              <td><a href='https://youtu.be/3nWrd0YrOjY' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS201IMG20200603084703.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AMIT KUMAR PANDEY</td>

			        							<td>TRANSMISSION AND DISTRIBUTION OF ELECTRICAL POWER E</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>SUBSTATIONS</td>
			        							<td>Brief idea about substations</td>                                              <td><a href='https://www.youtube.com/watch?v=ILRKQdFDzs8&t=178s' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EE872Briefideaaboutsubstations.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SAUMYA MISHRA</td>

			        							<td>REFRIFGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Psychrometry</td>
			        							<td>Psychrometry part-1</td>                                              <td><a href='https://www.youtube.com/watch?v=hXOXtetom0c&t=44s' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SAUMYA MISHRA</td>

			        							<td>REFRIFGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Psychrometry</td>
			        							<td>Psychrometry part-2</td>                                              <td><a href='https://www.youtube.com/watch?v=LKvTrHRdb0g' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SAUMYA MISHRA</td>

			        							<td>REFRIFGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Psychrometry</td>
			        							<td>Applied Psychrometry</td>                                              <td><a href='https://www.youtube.com/watch?v=XevhxmrR_ZU' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SAUMYA MISHRA</td>

			        							<td>REFRIFGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Psychrometry</td>
			        							<td>Adiabatic Saturation Process</td>                                              <td><a href='https://www.youtube.com/watch?v=4PSocSfpdOQ&t=5s' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SAUMYA MISHRA</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Psychrometry</td>
			        							<td>Adiabatic Saturation Process</td>                                              <td><a href='https://www.youtube.com/watch?v=4PSocSfpdOQ&t=5s' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SAUMYA MISHRA</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Psychrometry</td>
			        							<td>Psychrometry part-1</td>                                              <td><a href='https://www.youtube.com/watch?v=hXOXtetom0c&t=44s' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SAUMYA MISHRA</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Psychrometry</td>
			        							<td>Psychrometry part-2</td>                                              <td><a href='https://www.youtube.com/watch?v=LKvTrHRdb0g' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SAUMYA MISHRA</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Psychrometry</td>
			        							<td>Applied Psychrometry</td>                                              <td><a href='https://www.youtube.com/watch?v=XevhxmrR_ZU' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SHIVENDRA PRATAP SINGH</td>

			        							<td>INDUSTRIAL ENGG.& SAFETY.</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>PLANT LAYOUT</td>
			        							<td>TYPES OF PLANT LAYOUT</td>                                              <td><a href='https://youtu.be/5Z5B6Q48YxU' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SHIVANI SHIVHARE</td>

			        							<td>UTILIZATION OF ELECTRICAL ENERGY</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Economics of Power generation</td>
			        							<td>Electric Load curve</td>                                              <td><a href='https://youtu.be/W56I8F_oeRI' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EE379electricloadcurve.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>VAPOUR ABSORPTION REFRIGERATION SYSTEM</td>
			        							<td>PART-1</td>                                              <td><a href='https://www.youtube.com/watch?v=zHepTHbGPw4&t=279s' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP941UNIT-4PART-1.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>VAPOUR ABSORPTION REFRIGERATION SYSTEM</td>
			        							<td>PART-2</td>                                              <td><a href='https://www.youtube.com/watch?v=iHAF441m2Vw&t=371s' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP812UNIT-4PART-2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>COMPUTER AIDED DESIGN AND MANUFACTURING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>SURFACE AND SOLID MODELLING USING CAD/CAM (UNIT-2)</td>
			        							<td>PART-1</td>                                              <td><a href='https://www.youtube.com/watch?v=l7s9aW9EgnU&t=345s' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>COMPUTER AIDED DESIGN AND MANUFACTURING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>SURFACE/SOLID MODELLING USING CAD/CAM (UNIT-2)</td>
			        							<td>PART-2</td>                                              <td><a href='https://www.youtube.com/watch?v=TPf3wws-Dl4&t=8s' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>SYSTEM OF FORCES (UNIT-2)</td>
			        							<td>PART-1</td>                                              <td><a href='https://www.youtube.com/watch?v=nPPIUI8o5Nw&t=831s' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP233UNIT-2PART-1.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>LAW OF FORCES (UNIT-2)</td>
			        							<td>PART-2</td>                                              <td><a href='https://www.youtube.com/watch?v=aSvtw84PSJI&t=1s' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP512UNIT-2PART-2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>REETA</td>

			        							<td>MULTIMEDIA AND ANIMATION</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Unit 1</td>
			        							<td>Introduction to Multimedia_4 June_11AM</td>                                              <td><a href='https://www.youtube.com/watch?v=VaarLRfR3fI&t=840s' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CS154Chp1-Introductiontomultimedia.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>R R SINGH</td>

			        							<td>IRRIGATION ENGINEERING</td>
			        							<td>Civil Engineering</td>
			        							<td>6</td>
			        							<td>Irrigation Engineering</td>
			        							<td>Introduction of irrigation</td>                                              <td><a href='https://youtu.be/rcBbFMETCWg' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CE335ccccccccccc.png' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAHUL MAURYA</td>

			        							<td>PRINCIPAL OF COMMUNICATION ENGG</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>Phase Modulation</td>
			        							<td>Introduction</td>                                              <td><a href='https://youtu.be/LsrxnOsazvY' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EL8phasemodulation-min.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>R R SINGH</td>

			        							<td>IRRIGATION ENGINEERING</td>
			        							<td>Civil Engineering</td>
			        							<td>6</td>
			        							<td>Irrigation Engineering</td>
			        							<td>Introduction of irrigation</td>                                              <td><a href='https://youtu.be/rcBbFMETCWg' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CE255ccccccccccc.png' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>YASHI TIWARI</td>

			        							<td>ANALOG ELECTRONICS</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>Introduction to semiconductors</td>
			        							<td>Definition of semiconductor </td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL262AnalogElectronicslecture1.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PANKAJ CHAUHAN</td>

			        							<td>CONSTRUCTION AND MATERIAL A</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>Timber </td>
			        							<td>Topic 1</td>                                              <td><a href='https://youtu.be/yRP_SRmZb54' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>YASHI TIWARI</td>

			        							<td>INDUSTRIAL ELECTRONICS AND CONTROL</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Introduction to Power Electronics</td>
			        							<td>Types of Power diode</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL853IECLecture01.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PANKAJ CHAUHAN</td>

			        							<td>CONSTRUCTION AND MATERIAL A</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>Timber </td>
			        							<td>Topic 1</td>                                              <td><a href='https://youtu.be/UkCUh47gAAQ' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>PRAVESH KUMAR CHAUHAN</td>

			        							<td>E COMMERCE AND DIGITAL MARKETING</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Social Media Marketing Unit 7</td>
			        							<td>Social Media Marketing  - Introduction</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS224SocialMediaMarketing-Introduction.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PANKAJ CHAUHAN</td>

			        							<td>CONSTRUCTION AND MATERIAL A</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>Timber </td>
			        							<td>Topic 2</td>                                              <td><a href='https://youtu.be/UkCUh47gAAQ' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>NAVEEN KUMAR RAO</td>

			        							<td>BASICS OF MECHANICAL AND ELECTRICAL ENGINEERING</td>
			        							<td>Civil Engineering</td>
			        							<td>2</td>
			        							<td>gear </td>
			        							<td>geartrain</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC979NewDoc04-04-2020115706.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DINESH PRATAP SINGH</td>

			        							<td>SURVEYING I</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>SURVEYING I</td>
			        							<td>unit-2 part -2</td>                                              <td><a href='https://youtu.be/fkKnzH4py9M' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CE2293compressed.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DINESH PRATAP SINGH</td>

			        							<td>SURVEYING I</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>https://youtu.be/fkKnzH4py9M</td>
			        							<td>unt-2 part-2</td>                                              <td><a href='https://youtu.be/qXOOOpimQNI' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>DINESH PRATAP SINGH</td>

			        							<td>SURVEYING I</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>SURVEYING I</td>
			        							<td>unit-2 part-5</td>                                              <td><a href='https://youtu.be/BWZYzy0rh0Q' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CE8565compressed.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DINESH PRATAP SINGH</td>

			        							<td>SURVEYING I</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>SURVEYING I</td>
			        							<td>unit-2 part-2</td>                                              <td><a href='https://youtu.be/BWZYzy0rh0Q' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CE6704compressed.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DINESH PRATAP SINGH</td>

			        							<td>SURVEYING I</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>SURVEYING I</td>
			        							<td>unit-2 part-6</td>                                              <td><a href='https://youtu.be/sYvBUERSA1Y' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CE3066compressed.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DINESH PRATAP SINGH</td>

			        							<td>SURVEYING I</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>SURVEYING I</td>
			        							<td>unit2 part-7</td>                                              <td><a href='https://youtu.be/xCJF8Eo9MyU' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CE5687compressed.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ANIL KUMAR YADAV</td>

			        							<td>UNIVERSAL HUMAN VALUES E</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Unit 1</td>
			        							<td>Introduction to human value</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE256UHV,AKYADAV,EE2ndshift.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ANIL KUMAR YADAV</td>

			        							<td>UNIVERSAL HUMAN VALUES E</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Unit 1</td>
			        							<td>Basic Human Values</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE541UHVAKyadav,EE(E).pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DINESH PRATAP SINGH</td>

			        							<td>SURVEYING I</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>SURVEYING I</td>
			        							<td>unit 2 part 8</td>                                              <td><a href='https://youtu.be/oKja6IW_SnY' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CE4118compressed.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ANIL KUMAR YADAV</td>

			        							<td>UNIVERSAL HUMAN VALUES E</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Units 2</td>
			        							<td>Role of family, society and educational institutions in inculcating values</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE365UHV,2EE(E)Akyadav.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>UDAY PRATAP SINGH</td>

			        							<td>APPLIED PHYSICS-II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>CURRENT ELECTRICITY</td>
			        							<td>ELECTRIC CURRENT AND OHM LAWS</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS401CamScanner06-01-2020093559.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ANIL KUMAR YADAV</td>

			        							<td>UNIVERSAL HUMAN VALUES E</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Unit 2</td>
			        							<td> Lessons from legends</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE314UHV,2EE(E)Akyadav.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ABHAY KUMAR YADAV</td>

			        							<td>EARTHQUAKE ENGINEERING</td>
			        							<td>Civil Engineering</td>
			        							<td>6</td>
			        							<td>6</td>
			        							<td>Liquefaction of soil during earthquake</td>                                              <td><a href='https://youtu.be/9fPPLGXueCs' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ABHAY KUMAR YADAV</td>

			        							<td>HIGHWAY ENGINEERING</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>4</td>
			        							<td>Geometric design of highway</td>                                              <td><a href='https://youtu.be/CAgRMYKmU5A' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>JAINESHWAR VERMA</td>

			        							<td>BASICS OF MECHANICAL AND CIVIL ENGINEERING</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>TIMBER</td>
			        							<td>TIMBER</td>                                              <td><a href='https://www.youtube.com/watch?v=4P99_9BkvEM&t=250s' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>JAINESHWAR VERMA</td>

			        							<td>DESIGN OF STEEL AND MASONRY STRUCTURE E</td>
			        							<td>Civil Engineering</td>
			        							<td>6</td>
			        							<td>COLUMN BASE</td>
			        							<td>COLUMN BASE</td>                                              <td><a href='https://www.youtube.com/watch?v=_xw0tzL0wA0&t=25s' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION & DISASTER MANAGEMENT</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Introduction</td>
			        							<td>Ozone layer depletion</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS411ozoneLayerdepletionnotes.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>JOGENDRA KUMAR</td>

			        							<td>APPLIED MATHEMATICS II</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>Plane</td>
			        							<td>About plane</td>                                              <td><a href='https://youtu.be/TfbVY2OvZcM' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS832Plane1Plane.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>JOGENDRA KUMAR</td>

			        							<td>APPLIED MATHEMATICS II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Plane</td>
			        							<td>About plane</td>                                              <td><a href='https://youtu.be/TfbVY2OvZcM' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS94Plane1Plane.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>JOGENDRA KUMAR</td>

			        							<td>Applied  Mathematics - II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Plane</td>
			        							<td>About plane</td>                                              <td><a href='https://youtu.be/TfbVY2OvZcM' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS222Plane1Plane.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>JOGENDRA KUMAR</td>

			        							<td>APPLIED MATHEMATICS II E</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>Plane</td>
			        							<td>About plane</td>                                              <td><a href='https://youtu.be/TfbVY2OvZcM' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS374Plane1Plane.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AKHILESH TRIVEDI</td>

			        							<td>INSTALLATION MAINTENANCE AND REPAIR OF ELECTRICAL EQUIPMENT E</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Transformer protection</td>
			        							<td>Transformer protection by R.L.C.D method</td>                                              <td><a href='https://youtu.be/JQv4HHPOSUc' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>AKHILESH TRIVEDI</td>

			        							<td>ENERGY CONSERVATION E</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Energy efficiency in thermal utilities</td>
			        							<td>Boiler</td>                                              <td><a href='https://youtu.be/LWatKy4zhiU' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>JAINESHWAR VERMA</td>

			        							<td>DESIGN OF STEEL AND MASONRY STRUCTURE E</td>
			        							<td>Civil Engineering</td>
			        							<td>6</td>
			        							<td>compression member</td>
			        							<td>introduction-effective length-buckling-slenderness ratio-angle strut</td>                                              <td><a href='https://www.youtube.com/watch?v=Df0s7PRAywE' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>JAINESHWAR VERMA</td>

			        							<td>STRUCTURE A</td>
			        							<td>Architecture Assistantship</td>
			        							<td>4</td>
			        							<td>WELDING</td>
			        							<td>introduction-type of weld-types of fillet weld- size of weld</td>                                              <td><a href='https://www.youtube.com/watch?v=k2bWrJ8AX_w' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>mobile communication</td>
			        							<td>gprs</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL466mcselx3pm23-4-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>mobile communication</td>
			        							<td>GPS</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL101mcselx3pm24-04-20.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>mobile communication</td>
			        							<td>cellular telephone system</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL412mcselx3pm25-4-20.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>mobile communication</td>
			        							<td>ssma</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL441mcselx3pm28-04-20.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>mobile communication</td>
			        							<td>LEO AND MEO</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL748mcselx3pm29-4-20.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>satellite communication</td>
			        							<td>orbital velocity and time period of satellite</td>                                              <td><a href='https://www.youtube.com/watch?v=8BHgnUWvOWU&t=27s' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>UDAY PRATAP SINGH</td>

			        							<td>Applied Physics -II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>CURRENT ELECTRICITY</td>
			        							<td>ELECTRIC CURRENT AND OHM LAWS</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS425CamScanner06-01-2020093559.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>UDAY PRATAP SINGH</td>

			        							<td>APPLIED PHYSICS E</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>CURRENT ELECTRICITY</td>
			        							<td>ELECTRIC CURRENT AND OHM LAWS</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS519CamScanner06-01-2020093559.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRADEEP TIWARI</td>

			        							<td>METROLOGY & MEASURING INSTRUMENTS.</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>Unit 9</td>
			        							<td>Vibration measurement part 2</td>                                              <td><a href='https://youtu.be/UyCSI4_LXMY' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>PC KAUSHIK</td>

			        							<td>METROLOGY AND MEASURING INSTRUEMENTS</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>TRANSDUCER</td>
			        							<td>PART-2</td>                                              <td><a href='https://www.youtube.com/watch?v=TZgrYYNibdo' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>PC KAUSHIK</td>

			        							<td>METROLOGY AND MEASURING INSTRUEMENTS</td>
			        							<td>Mechanical CAD</td>
			        							<td>6</td>
			        							<td>TRANSDUCER</td>
			        							<td>PART-2</td>                                              <td><a href='https://www.youtube.com/watch?v=TZgrYYNibdo' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>GAURAV KUMAR KASHYAP</td>

			        							<td>ENVIRONMENTAL EDUCATION & DISASTER MANAGEMENT</td>
			        							<td>MSM</td>
			        							<td>2</td>
			        							<td>Our Environment</td>
			        							<td>Environment</td>                                              <td><a href='https://youtu.be/yLtdbBcpPxY' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MC609EEDMEnvironment.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>GAURAV KUMAR KASHYAP</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT</td>
			        							<td>Mechanical CAD</td>
			        							<td>6</td>
			        							<td>Our Environment</td>
			        							<td>Environment</td>                                              <td><a href='https://youtu.be/yLtdbBcpPxY' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MC730EEDMEnvironment.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATH-II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>Straight Line</td>
			        							<td>Formula </td>                                              <td><a href='https://youtu.be/4BoXmeHdJ30' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS850Lecture-106-05-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AMIT KUMAR PANDEY</td>

			        							<td>BASIC ELECTRICAL ENGINEERING E</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>Various types of Power Plants</td>
			        							<td>Comparison between various Power Plants</td>                                              <td><a href='https://www.youtube.com/watch?v=PS2MU8l2fB8&t=14s' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EE553COMPARISONBETWEENVARIOUSPOWERPLANTS.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHEMATICS 1 B</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>Straight Line </td>
			        							<td>Formula   </td>                                              <td><a href='https://youtu.be/4BoXmeHdJ30' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS465Lecture-106-05-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHS II</td>
			        							<td>Civil Engineering</td>
			        							<td>2</td>
			        							<td>Straight Line   </td>
			        							<td>Formula     </td>                                              <td><a href='https://youtu.be/4BoXmeHdJ30' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS993Lecture-106-05-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHEMATICS II</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Straight Line     </td>
			        							<td>Formula       </td>                                              <td><a href='https://youtu.be/4BoXmeHdJ30' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS864Lecture-106-05-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ABHISHEK SHARMA</td>

			        							<td>ELECTRICAL ENGG-I</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>Cells and Batteries</td>
			        							<td>Lead Acid Batterie</td>                                              <td><a href='https://youtu.be/GvaZbV8Bq3o' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>LAW OF FORCES</td>
			        							<td>PART-3</td>                                              <td><a href='https://www.youtube.com/watch?v=S3tUp5hs6zQ' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP634UNIT-2PART-3.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>LAW OF FORCES</td>
			        							<td>PART-4</td>                                              <td><a href='https://www.youtube.com/watch?v=ifQinOyeZPI' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP627UNIT-2PART-4.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAVESH KUMAR CHAUHAN</td>

			        							<td>E COMMERCE</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>6</td>
			        							<td>Risks Of E-Commerce Unit 10</td>
			        							<td>Risks Of E-Commerce</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS480RisksOfE-Commerce.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>VIVEKANAND YADAV</td>

			        							<td>HYDRAULICS AND  PNEUMATICS.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Hydraulics machine</td>
			        							<td>Hydraulics brake</td>                                              <td><a href='https://youtu.be/5yPW5cnwQqk' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SUNIL KUMAR SINGH</td>

			        							<td>ELECTRICAL DESIGN DRAWING AND ESTIMATING I</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Estimation of transmission lines</td>
			        							<td>Part-1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE962EDDE-Iestimationoftransmissionlinepart-1.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>R R SINGH</td>

			        							<td>IRRIGATION ENGINEERING</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>Chapter 2</td>
			        							<td>water requirement for crops</td>                                              <td><a href='https://www.youtube.com/watch?v=pTHHHANZ-Ik' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CE100ssssssssssss.PNG' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>R R SINGH</td>

			        							<td>IRRIGATION ENGINEERING</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>Chapter 2</td>
			        							<td>water requirement for crops</td>                                              <td><a href='https://youtu.be/pTHHHANZ-Ik' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CE71ssssssssssss.PNG' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SUNIL KUMAR SINGH</td>

			        							<td>BASIC ELECTRICAL ENGINEERING</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>Various types of power plants</td>
			        							<td>Part-1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE140varioustypesofpowerplantspart-1.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>VIVEKANAND YADAV</td>

			        							<td>APPLIED MECHANICS.</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Centre of gravity</td>
			        							<td>Numerical based on simple lamina</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MP857Screenshot2020-06-01-14-49-15-61.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SUNIL KUMAR SINGH</td>

			        							<td>BASIC ELECTRICAL ENGINEERING</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>Various types of power plants</td>
			        							<td>Part-2</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE497varioustypesofpowerplantspart-2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SUNIL KUMAR SINGH</td>

			        							<td>ELECTRICAL DESIGN DRAWING AND ESTIMATING I</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Estimation of transmission lines</td>
			        							<td>Part-2</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE849estimationoftransmissionlinepart-2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAHUL MAURYA</td>

			        							<td>NETWORK FILTERS AND TRANSMISSION LINES</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>Transmission Lines</td>
			        							<td>Part 1</td>                                              <td><a href='https://youtu.be/ZxachodwS9o' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EL821TransmissionLinepart1.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SWADHEEN SHARMA</td>

			        							<td>GENERAL ENGINEERING</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>DC Circuit</td>
			        							<td>delta star conversion n vice-versa </td>                                              <td><a href='https://youtu.be/JcVmwdkDZ4w' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SUNIL KUMAR SINGH</td>

			        							<td>ELECTRICAL DESIGN DRAWING AND ESTIMATING I</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Estimation of transmission lines</td>
			        							<td>Part-3</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE591estimationoftransmissionlinepart-3.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHASHI PRAKASH PANDEY</td>

			        							<td>APPLIED MECHANICS E</td>
			        							<td>Civil Engineering</td>
			        							<td>2</td>
			        							<td>APPLIED MECHANICS</td>
			        							<td>IMPORTANT QUESTION SOLUTION</td>                                              <td><a href='https://youtu.be/4CDBGbMrhL4' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SHIVANI SHIVHARE</td>

			        							<td>UTILIZATION OF ELECTRICAL ENERGY</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Economics of Power generation</td>
			        							<td>Electric tarriff</td>                                              <td><a href='https://youtu.be/OzyyxZNqv1Y' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EE763electrictariff.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>YASHI TIWARI</td>

			        							<td>INDUSTRIAL ELECTRONICS AND CONTROL</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Thyristor and its type</td>
			        							<td>SCR</td>                                              <td><a href='https://youtu.be/KfqFo_cprqk' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EL936IMG-20200310-WA0066.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHIVANI SHIVHARE</td>

			        							<td>UTILIZATION OF ELECTRICAL ENERGY</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Electric Welding</td>
			        							<td>Electric Arc welding</td>                                              <td><a href='https://youtu.be/riGR-pxJmHg' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EE783electricarcwelding.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>YASHI TIWARI</td>

			        							<td>INDUSTRIAL ELECTRONICS AND CONTROL</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Thyristor and its type</td>
			        							<td>SCR</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL122IECThyristoranditstypes.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>YASHI TIWARI</td>

			        							<td>ANALOG ELECTRONICS</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>Introduction to semiconductors</td>
			        							<td>Band Theory of solids</td>                                              <td><a href='https://youtu.be/RJ-Z5GUFV1A' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>VISHAL SINGH NEGI</td>

			        							<td>NETWORK ADMINISTRATION AND SECURITY</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>6</td>
			        							<td>VPN</td>
			        							<td>Types of VPN and protocols</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS1Documents5.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>VISHAL SINGH NEGI</td>

			        							<td>NETWORK ADMINISTRATION AND SECURITY</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>6</td>
			        							<td>VPN</td>
			        							<td>Introduction and types</td>                                              <td><a href='https://youtu.be/_Bhes3fzOWk' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>VISHAL SINGH NEGI</td>

			        							<td>NETWORK ADMINISTRATION AND SECURITY</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>6</td>
			        							<td>IDS</td>
			        							<td>Intrusion Detection System </td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS318IDS.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>VISHAL SINGH NEGI</td>

			        							<td>NETWORK ADMINISTRATION AND SECURITY</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>6</td>
			        							<td>IDS</td>
			        							<td>Teardrop attack </td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS909Teardropattack.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>VISHAL SINGH NEGI</td>

			        							<td>NETWORK ADMINISTRATION AND SECURITY</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>6</td>
			        							<td>IDS</td>
			        							<td>HIDS</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS738HIDS.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AKHILESH TRIVEDI</td>

			        							<td>BASICS OF MECHANICAL AND ELECTRICAL ENGINEERING E</td>
			        							<td>Civil Engineering</td>
			        							<td>2</td>
			        							<td>Ac 3 phase supply system</td>
			        							<td>3 phase supply circuit</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE424NewDoc06-05-2020190417.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ANURAG KUMAR</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>Radioactive pollution</td>
			        							<td>Radioactive pollution</td>                                              <td><a href='https://youtu.be/1pdIPmPTDT8' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>AKHILESH TRIVEDI</td>

			        							<td>BASICS OF MECHANICAL AND ELECTRICAL ENGINEERING E</td>
			        							<td>Civil Engineering</td>
			        							<td>2</td>
			        							<td>A.C circuit</td>
			        							<td>Star delta connection</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE673Ac.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>VAPOUR ABSORPTION REFRIGERATION SYSTEM</td>
			        							<td>PART-3</td>                                              <td><a href='https://www.youtube.com/watch?v=TlMm1D19G94&t=47s' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP201UNIT-4PART-3.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>VAPOUR ABSORPTION REFRIGERATION SYSTEM</td>
			        							<td>PART-4</td>                                              <td><a href='https://www.youtube.com/watch?v=sOc2dB6yqMA&t=49s' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP753UNIT-4PART-4.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DEEP SHIKHA</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>Electrostatic </td>
			        							<td>Properties of charge </td>                                              <td><a href='https://youtu.be/orPoIhvOYU4' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>DEEP SHIKHA</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Electrostatic </td>
			        							<td>Properties of charge </td>                                              <td><a href='https://youtu.be/orPoIhvOYU4' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SAURABH KUMAR SONI</td>

			        							<td>BASICS OF MECHANICAL AND CIVIL ENGINEERING</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>CEMENT</td>
			        							<td>CEMENT</td>                                              <td><a href='https://youtu.be/7NBkM3D1FP0' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SAURABH KUMAR SONI</td>

			        							<td>PRODUCTION TECHNOLOGY II</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>Intoduction of computer integrated manufacturing</td>
			        							<td>Intoduction of computer integrated manufacturing</td>                                              <td><a href='https://youtu.be/G07loTAIj9c' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SAURABH KUMAR SONI</td>

			        							<td>CNC MACHINE AND AUTOMATION</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>Intoduction of computer integrated manufacturing</td>
			        							<td>Intoduction of computer integrated manufacturing</td>                                              <td><a href='https://youtu.be/G07loTAIj9c' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SAURABH KUMAR SONI</td>

			        							<td>CNC MACHINE AND AUTOMATION</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>production</td>
			        							<td>production</td>                                              <td><a href='https://youtu.be/D5akLCla6Vs' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SAURABH KUMAR SONI</td>

			        							<td>PRODUCTION TECHNOLOGY II</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>production</td>
			        							<td>production</td>                                              <td><a href='https://youtu.be/D5akLCla6Vs' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>RAHUL MAURYA</td>

			        							<td>PRINCIPAL OF COMMUNICATION ENGG</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>Phase Modulation</td>
			        							<td>Part 2</td>                                              <td><a href='https://youtu.be/jtfjw3oHlUw' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SAURABH KUMAR SONI</td>

			        							<td>PRODUCTION TECHNOLOGY II</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>introduction of robot</td>
			        							<td>introduction of robot</td>                                              <td><a href='https://youtu.be/sYWj1QnH1oU' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SAURABH KUMAR SONI</td>

			        							<td>CNC MACHINE AND AUTOMATION</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>introduction of robot</td>
			        							<td>introduction of robot</td>                                              <td><a href='https://youtu.be/sYWj1QnH1oU' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SHIVENDRA PRATAP SINGH</td>

			        							<td>ENERGY  CONSERVATION.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>PRODUCTION, PLANNING AND CONTROL: </td>
			        							<td>Sales forecasting      </td>                                              <td><a href='https://youtu.be/3UZusDDhOjQ' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SHIVENDRA PRATAP SINGH</td>

			        							<td>ENERGY  CONSERVATION.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>PRODUCTION, PLANNING AND CONTROL</td>
			        							<td>Sales forecasting      </td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC666MPE3RDYEAR,SUBJECT-IES,CHAPTER-3,BY-SHIVENDRA.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHIVANI SHIVHARE</td>

			        							<td>UTILIZATION OF ELECTRICAL ENERGY</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Economics of Power generation</td>
			        							<td>Electric Resistance Welding</td>                                              <td><a href='https://youtu.be/GmlA2feyzPU' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EE686resistancewelding.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AMIT KUMAR PANDEY</td>

			        							<td>TRANSMISSION AND DISTRIBUTION OF ELECTRICAL POWER E</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>SUBSTATIONS</td>
			        							<td>Components of Substation</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE89ComponentsofSubstation.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SWADHEEN SHARMA</td>

			        							<td>GENERAL ENGINEERING</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>DC Circuit</td>
			        							<td>delta star conversion n vice-versa </td>                                              <td><a href='https://youtu.be/hmjwexrJlBU' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SWADHEEN SHARMA</td>

			        							<td>GENERAL ENGINEERING</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>DC Circuit</td>
			        							<td>delta star conversion with example</td>                                              <td><a href='https://youtu.be/dbPDmCVvyy8' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SWADHEEN SHARMA</td>

			        							<td>GENERAL ENGINEERING</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>DC Circuit</td>
			        							<td>Star delta conversion Example</td>                                              <td><a href='https://youtu.be/56kRMB0XKv4' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>PANKAJ CHAUHAN</td>

			        							<td>ARCHITECTURAL DESIGN A BASIC DESIGN</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>Problem 2</td>
			        							<td>Shop</td>                                              <td><a href='https://youtu.be/RH1jCpLCWOE' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>R R SINGH</td>

			        							<td>IRRIGATION ENGINEERING</td>
			        							<td>Civil Engineering</td>
			        							<td>6</td>
			        							<td>Chapter 2</td>
			        							<td>Rainfall and Runoff</td>                                              <td><a href='https://youtu.be/scrXrfcgSSg' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CE128lllllllllllllllllllllllll.PNG' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHIVENDRA PRATAP SINGH</td>

			        							<td>ENERGY  CONSERVATION.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>General Energy Saving Tips </td>
			        							<td>General Energy Saving Tips for Fans</td>                                              <td><a href='https://youtu.be/sXCoQM6IOts' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MC301MEP2NDYEAR,ENERGYCONSERVATION,CHAPTER-9,By-SHIVENDRA.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SWATI MALL</td>

			        							<td>CONCEPT OF PROGRAMMING USING C</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Chapter-3</td>
			        							<td>Program for practice</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS7QuesCS-1styr.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SAUMYA MISHRA</td>

			        							<td>COMPUTER AIDED DESIGN AND MANUFACTURING</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Manufacturing Applications-Rapid Prototyping</td>
			        							<td>3D Printing</td>                                              <td><a href='https://www.youtube.com/watch?v=VPUJMOGcS8Y' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SAUMYA MISHRA</td>

			        							<td>COMPUTER AIDED DESIGN AND MANUFACTURING</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Manufacturing Applications-Rapid Prototyping</td>
			        							<td>Fused Deposition Modeling</td>                                              <td><a href='https://www.youtube.com/watch?v=V94vVbvyXSQ' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SAUMYA MISHRA</td>

			        							<td>COMPUTER AIDED DESIGN AND MANUFACTURING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Manufacturing Applications-Rapid Prototyping</td>
			        							<td>Fused Deposition Modeling</td>                                              <td><a href='https://www.youtube.com/watch?v=V94vVbvyXSQ' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SAUMYA MISHRA</td>

			        							<td>COMPUTER AIDED DESIGN AND MANUFACTURING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Manufacturing Applications-Rapid Prototyping</td>
			        							<td>3D Printing</td>                                              <td><a href='https://www.youtube.com/watch?v=VPUJMOGcS8Y' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>KM SHALINI MISHRA</td>

			        							<td>GENERAL ENGINEERING</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>General engineering (civil)</td>
			        							<td>Raw materials </td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CE984CamScanner06-06-2020140605.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ABHISHEK SHARMA</td>

			        							<td>UTILIZATION OF ELECTRICAL ENERGY E</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Unit-2</td>
			        							<td>Electrical Tariff</td>                                              <td><a href='https://youtu.be/_v5BF0S8_mc' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS  II</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Chapter 4</td>
			        							<td>Current electricity</td>                                              <td><a href='https://youtu.be/m-5qM05ORlw' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>Chapter 4</td>
			        							<td>Current electricity</td>                                              <td><a href='https://youtu.be/m-5qM05ORlw' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>Chapter 4</td>
			        							<td>Current electricity</td>                                              <td><a href='https://youtu.be/m-5qM05ORlw' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>AKHILESH TRIVEDI</td>

			        							<td>INSTALLATION MAINTENANCE AND REPAIR OF ELECTRICAL EQUIPMENT E</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Electrical Accident treatment and fire extinguisher</td>
			        							<td>Electrical Accident</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE568Imr1.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AKHILESH TRIVEDI</td>

			        							<td>INSTALLATION MAINTENANCE AND REPAIR OF ELECTRICAL EQUIPMENT E</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Electrical accidents and safety</td>
			        							<td>Fire extinguisher</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE451Fire.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AKHILESH TRIVEDI</td>

			        							<td>ENERGY CONSERVATION E</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Lightning and D.G. systems</td>
			        							<td>D.G set</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE910Ic.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AKHILESH TRIVEDI</td>

			        							<td>ENERGY CONSERVATION E</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Lightning and D.G. systems 2</td>
			        							<td>D.G set 2</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE862Ic2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AKHILESH TRIVEDI</td>

			        							<td>ENERGY CONSERVATION E</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Energy conservation</td>
			        							<td>Energy audit for building</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE22IC3.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AKHILESH TRIVEDI</td>

			        							<td>ENERGY CONSERVATION E</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Energy audit</td>
			        							<td>Energy audit for building</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE771NewDoc06-06-2020191555.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DINESH PRATAP SINGH</td>

			        							<td>SURVEYING I</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>COMPASS SURVEYING 2</td>
			        							<td>UNIT 3</td>                                              <td><a href='https://youtu.be/JKAl-TOg1aA' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CE2931compressed.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DINESH PRATAP SINGH</td>

			        							<td>SURVEYING I</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>COMPASS SURVEYING 2</td>
			        							<td>UNIT-3 PART 2</td>                                              <td><a href='https://youtu.be/R_Q6ZJSyqEo' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CE8112(2).pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DINESH PRATAP SINGH</td>

			        							<td>SURVEYING I</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td></td>
			        							<td>UNIT 2 PART 3</td>                                              <td><a href='https://youtu.be/XYKnBuB1SAQ' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CE50122.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DINESH PRATAP SINGH</td>

			        							<td>SURVEYING I</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td> Plane Table Surveying part1</td>
			        							<td>Unit5</td>                                              <td><a href='https://youtu.be/oKja6IW_SnY' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CE68751compressed.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DINESH PRATAP SINGH</td>

			        							<td>SURVEYING I</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>COMPASS SURVEYING 2</td>
			        							<td>UNIT-5 PART 2</td>                                              <td><a href='https://youtu.be/9sva6Nl-QK4' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CE34052compressed.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PREM PRAKASH SINGH</td>

			        							<td>TRANSMISSION AND DISTRIBUTION OF ELECTRICAL POWER</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>GENERATION AND DISTRIBUTION </td>
			        							<td>SINGLE LINE DIAGRAM</td>                                              <td><a href='https://youtu.be/OpBAvLcMXJI' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EE88Doc1.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ABHAY KUMAR YADAV</td>

			        							<td>HIGHWAY ENGINEERING</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>7</td>
			        							<td>Hill road</td>                                              <td><a href='https://youtu.be/qw0xyYzlBYM' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ABHAY KUMAR YADAV</td>

			        							<td>HIGHWAY ENGINEERING</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>7</td>
			        							<td>Hill road</td>                                              <td><a href='https://youtu.be/QwAuN1R2sC0' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ABHAY KUMAR YADAV</td>

			        							<td>HIGHWAY ENGINEERING</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>7</td>
			        							<td>Earthquake zones</td>                                              <td><a href='https://youtu.be/eyVfFxvetQA' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>AMIT KUMAR PANDEY</td>

			        							<td>BASIC ELECTRICAL ENGINEERING E</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>BATTERIES</td>
			        							<td>Storage cell</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE364Storagecell.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AMIT KUMAR PANDEY</td>

			        							<td>BASIC ELECTRICAL ENGINEERING E</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>BATTERIES</td>
			        							<td>Construction of secondary storage cell</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE718Constructionofstoragecell.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS  II</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Chapter 7</td>
			        							<td>Laser</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS337laser.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS  II</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Chapter 7</td>
			        							<td>Optical fiber</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS963fiberoptics.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>Chapter 7</td>
			        							<td>Laser</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS214laser.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>Chapter 7</td>
			        							<td>Optical fiber</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS273fiberoptics.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>Chapter 7</td>
			        							<td>Laser</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS536laser.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>Chapter 7</td>
			        							<td>Optical fiber</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS929fiberoptics.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS  II</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Chapter 4</td>
			        							<td>Current electricity</td>                                              <td><a href='https://youtu.be/m-5qM05ORlw' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>Chapter 4</td>
			        							<td>Current electricity</td>                                              <td><a href='https://youtu.be/m-5qM05ORlw' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>Chapter 4</td>
			        							<td>Current electricity</td>                                              <td><a href='https://youtu.be/m-5qM05ORlw' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL  STUDIES.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Impact of energy usage on environment</td>
			        							<td>Global warming</td>                                              <td><a href='https://youtu.be/aHw30DtFAjg' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS547globalwarmingnotespdf.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ANURAG KUMAR</td>

			        							<td>UNIVERAL HUMAN VALUES</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>unit 2</td>
			        							<td>UNDERSTANDING HARMONY IN THE HUMAN BEING</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC732UHVUNIT2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ANURAG KUMAR</td>

			        							<td>UNIVERAL HUMAN VALUES</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>UNIT 5</td>
			        							<td>IMPLICATION OF HOLISTIC UNDERSTANDINGOF HARMONY ON PROFESSIONAL ETHICS</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC880UHVUNIT5.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ANURAG KUMAR</td>

			        							<td>UNIVERAL HUMAN VALUES</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>unit 1</td>
			        							<td>NEED ,BASIC GUIDELINES,CONTENT AND PROCESS FOR VALUE EDUCATION</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC470UHVUNIT1-compressed.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ANURAG KUMAR</td>

			        							<td>UNIVERAL HUMAN VALUES</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>unit 3</td>
			        							<td>HARMONY IN FAMILY AND SOCIETY</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC339UHVunit3-compressed.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ANURAG KUMAR</td>

			        							<td>UNIVERAL HUMAN VALUES</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>unit 4</td>
			        							<td>HARMONY IN NATURE AND EXISTENCE</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC384UHVunit4-compressed.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ANURAG KUMAR</td>

			        							<td>PROJECT</td>
			        							<td>Mechanical CAD</td>
			        							<td>6</td>
			        							<td>PROJECT</td>
			        							<td>DESIGN OF MUFF COUPLING</td>                                              <td><a href='https://www.youtube.com/watch?v=OqXaJMpKPfA&t=74s' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ANURAG KUMAR</td>

			        							<td>PROJECT</td>
			        							<td>Mechanical CAD</td>
			        							<td>6</td>
			        							<td>PROJECT</td>
			        							<td>DESIGN OF SUNK KEYS</td>                                              <td><a href='https://www.youtube.com/watch?v=x9Mz8YvW19o&t=804s' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ANURAG KUMAR</td>

			        							<td>PROJECT</td>
			        							<td>Mechanical CAD</td>
			        							<td>6</td>
			        							<td>PROJECT</td>
			        							<td>WEBINAR ON FINDING REACTIONS PROMO</td>                                              <td><a href='https://www.youtube.com/watch?v=auC-PAEQYLc&t=16s' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ANURAG KUMAR</td>

			        							<td>PROJECT</td>
			        							<td>Mechanical CAD</td>
			        							<td>6</td>
			        							<td>PROJECT</td>
			        							<td>FINDING REACTIONS IN CASE OF SIMPLY SUPPORTED BEAM</td>                                              <td><a href='https://www.youtube.com/watch?v=fCAeIL_3GeI&t=225s' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ANURAG KUMAR</td>

			        							<td>PROJECT.</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>PROJECT</td>
			        							<td>DESIGN OF MUFF COUPLING</td>                                              <td><a href='https://www.youtube.com/watch?v=OqXaJMpKPfA&t=173s' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ANURAG KUMAR</td>

			        							<td>PROJECT.</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>PROJECT</td>
			        							<td>DESIGN OF SUNK KEYS</td>                                              <td><a href='https://www.youtube.com/watch?v=x9Mz8YvW19o&t=889s' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ANURAG KUMAR</td>

			        							<td>PROJECT.</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>PROJECT</td>
			        							<td>PROMO OF WEBINAR  ON FINDING </td>                                              <td><a href='https://www.youtube.com/watch?v=auC-PAEQYLc' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ANURAG KUMAR</td>

			        							<td>PROJECT.</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>PROJECT</td>
			        							<td>FINDING REACTIONS IN CASE OF SIMPLY SUPPORTED BEAMS</td>                                              <td><a href='https://www.youtube.com/watch?v=fCAeIL_3GeI&t=225s' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ANURAG KUMAR</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>CHAPTER 7</td>
			        							<td>SOLID WASTE MANAGEMENT</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC528wastemanagement-compressed.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ANURAG KUMAR</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>CHAPTER 8</td>
			        							<td>legislation</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC546EEDMLEGISLATION-compressed.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ANURAG KUMAR</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>CHAPTER 9</td>
			        							<td>environmental impact assesment</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC281EEDMENVIRONMENTALIMPACTASSESSMENT-compressed.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ANURAG KUMAR</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>CHAPTER 10</td>
			        							<td>disaster management</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC725EEDMDisastermanagement-compressed.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>NAVEEN KUMAR RAO</td>

			        							<td>BASICS OF MECHANICAL AND ELECTRICAL ENGINEERING</td>
			        							<td>Civil Engineering</td>
			        							<td>2</td>
			        							<td>Ac fundamentals</td>
			        							<td>Basic definitions part 2</td>                                              <td><a href='https://youtu.be/3_h-plfK7lU' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MC431basicdefinitionspart2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRATIKSHA AGARWAL</td>

			        							<td>GENERAL ENGINEERING.</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Ac fundamentals</td>
			        							<td>Basic definitions</td>                                              <td><a href='https://youtu.be/NIFSRDR5T6A' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EE735acfundamentals.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRATIKSHA AGARWAL</td>

			        							<td>GENERAL ENGINEERING.</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Ac fundamentals</td>
			        							<td>Basic definitions part 2</td>                                              <td><a href='https://youtu.be/3_h-plfK7lU' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EE944basicdefinitionspart2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRATIKSHA AGARWAL</td>

			        							<td>BASICS OF ELECTRICAL AND ELECTRONICS ENGINEERING</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Ac fundamentals</td>
			        							<td>Basic definitions</td>                                              <td><a href='https://youtu.be/NIFSRDR5T6A' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EE301acfundamentals.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRATIKSHA AGARWAL</td>

			        							<td>BASICS OF ELECTRICAL AND ELECTRONICS ENGINEERING</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Ac fundamentals</td>
			        							<td>Basic definitions part 2</td>                                              <td><a href='https://youtu.be/3_h-plfK7lU' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EE928basicdefinitionspart2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SUGANDHA TEJESWEE</td>

			        							<td>MICROPROCESSOR AND ITS APPLICATION</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Overview of microcomputer system</td>
			        							<td>Evolution of Microprocessor</td>                                              <td><a href='https://youtu.be/rIeCh1xrhqU' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ABHAI PRATAP MALL</td>

			        							<td>INDUSTRIAL ENGINEERING AND SAFETY</td>
			        							<td>Mechanical CAD</td>
			        							<td>6</td>
			        							<td>INSPECTION</td>
			        							<td>DEFINITION,OBJECTIVES & TYPES</td>                                              <td><a href='https://youtu.be/JXTPXaMMbHc' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP532INSPECTION1.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ABHAI PRATAP MALL</td>

			        							<td>INDUSTRIAL ENGINEERING AND SAFETY</td>
			        							<td>Mechanical CAD</td>
			        							<td>6</td>
			        							<td>INSPECTION</td>
			        							<td>TYPES OF INSPECTION</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MP827INS2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Unseen Passages </td>
			        							<td>Unseen passages 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS918Screenshot20200607-151209CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Unseen Passages </td>
			        							<td>Unseen passages 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS0Screenshot20200607-151209CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Unseen Passages </td>
			        							<td>Unseen passages 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS732Screenshot20200607-151209CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Unseen Passages </td>
			        							<td>Unseen passages 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS410Screenshot20200607-152849CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Unseen Passages </td>
			        							<td>Unseen passages 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS619Screenshot20200607-152849CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Unseen Passages </td>
			        							<td>Unseen passages 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS223Screenshot20200607-152849CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>Unseen Passages </td>
			        							<td>Unseen passages 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS739Screenshot20200607-152849CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Unseen Passages </td>
			        							<td>Unseen passages 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS130Screenshot20200607-154249CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Unseen Passages </td>
			        							<td>Unseen passages 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS119Screenshot20200607-154249CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Unseen Passages </td>
			        							<td>Unseen passages 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS478Screenshot20200607-154249CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>Unseen Passages </td>
			        							<td>Unseen passages 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS242Screenshot20200607-154249CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>Unseen Passages </td>
			        							<td>Unseen passages 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS835Screenshot20200607-154249CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>MISSI K BHASKER</td>

			        							<td>ELECTRONIC INSTRUMENT AND MEASUREMENT</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>Impedance bridge & Q meter</td>
			        							<td>Maxwell inductance bridge</td>                                              <td><a href='https://youtu.be/BS9fQT9MmMc' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>JOGENDRA KUMAR</td>

			        							<td>APPLIED MATHEMATICS II</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>Plane</td>
			        							<td>About plane</td>                                              <td><a href='https://youtu.be/wQgkCFdopnE' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS995CamScanner06-07-20201820191.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>JOGENDRA KUMAR</td>

			        							<td>APPLIED MATHEMATICS II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>PLANE</td>
			        							<td>About plane</td>                                              <td><a href='https://youtu.be/wQgkCFdopnE' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS93CamScanner06-07-20201820191.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>JOGENDRA KUMAR</td>

			        							<td>Applied  Mathematics - II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>PLANE</td>
			        							<td>About plane</td>                                              <td><a href='https://youtu.be/wQgkCFdopnE' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS469CamScanner06-07-20201820191.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>JOGENDRA KUMAR</td>

			        							<td>APPLIED MATHEMATICS II E</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>PLANE</td>
			        							<td>About plane</td>                                              <td><a href='https://youtu.be/wQgkCFdopnE' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS802CamScanner06-07-20201820191.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AKHILESH TRIVEDI</td>

			        							<td>INSTALLATION MAINTENANCE AND REPAIR OF ELECTRICAL EQUIPMENT E</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Electrical Accident and safety</td>
			        							<td>Merz price protection system</td>                                              <td><a href='https://youtu.be/iJezlNAqNP0' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>POONAM SHARMA</td>

			        							<td>FUNCTIONAL COMMUNICATION</td>
			        							<td>Architecture Assistantship</td>
			        							<td>4</td>
			        							<td>Chapter 5</td>
			        							<td>Buying a second Hand Bicycle </td>                                              <td><a href='https://youtu.be/TpxObuIn1jo' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>YASHI TIWARI</td>

			        							<td>ANALOG ELECTRONICS</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>Types of semiconductors </td>
			        							<td>Concept of holes </td>                                              <td><a href='https://youtu.be/5vQ80Reo178' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EL915conceptofholes.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>YASHI TIWARI</td>

			        							<td>INDUSTRIAL ELECTRONICS AND CONTROL</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>SCR</td>
			        							<td>Two transistors analogy of SCR</td>                                              <td><a href='https://youtu.be/FdJ-vYVG05k' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EL913TransistoranalogyinSCR.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHARDHA VAISH</td>

			        							<td>DATABASE MANAGEMENT SYSTEM</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Database  Management  system</td>
			        							<td>Data Independence </td>                                              <td><a href='https://youtu.be/DkDt1DG2p24' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>YASH RAJ</td>

			        							<td>COMMUNICATION SKILL-II</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>CH2- FRAMING QUESTION</td>
			        							<td>FRAMING QUESTION</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS333FramingQuestion2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>YASH RAJ</td>

			        							<td>COMMUNICATION SKILLS II E</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>CH2- FRAMING QUESTION</td>
			        							<td>FRAMING QUESTION</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS173FramingQuestion2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>YASH RAJ</td>

			        							<td>COMMUNICATION  SKILL-II.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>CH2- FRAMING QUESTION</td>
			        							<td>FRAMING QUESTION</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS281FramingQuestion2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>YASH RAJ</td>

			        							<td>COMMUNICATION  SKILL-II.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>CH2- FRAMING QUESTION</td>
			        							<td>FRAMING QUESTION</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS603FramingQuestion2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>YASH RAJ</td>

			        							<td>COMMUNICATION SKILL-II</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>PREFIX AND SUFFIX</td>
			        							<td>PREFIX AND SUFFIX (examples)</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS133PREFIXANDSUFFIX.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>YASH RAJ</td>

			        							<td>COMMUNICATION SKILLS II E</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>PREFIX AND SUFFIX</td>
			        							<td>PREFIX AND SUFFIX (examples)</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS677PREFIXANDSUFFIX.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>YASH RAJ</td>

			        							<td>COMMUNICATION  SKILL-II.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>CH2- FRAMING QUESTION</td>
			        							<td>FRAMING QUESTION</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS197PREFIXANDSUFFIX.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>YASH RAJ</td>

			        							<td>COMMUNICATION SKILL-II</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>CH2- FRAMING QUESTION</td>
			        							<td>FRAMING QUESTION</td>                                              <td><a href='https://youtu.be/lYZE4TEL8fA' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>YASH RAJ</td>

			        							<td>COMMUNICATION SKILLS II E</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>CH2- FRAMING QUESTION</td>
			        							<td>FRAMING QUESTION</td>                                              <td><a href='https://youtu.be/lYZE4TEL8fA' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>YASH RAJ</td>

			        							<td>COMMUNICATION  SKILL-II.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>CH2- FRAMING QUESTION</td>
			        							<td>FRAMING QUESTION</td>                                              <td><a href='https://youtu.be/lYZE4TEL8fA' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>LAW OF FORCES</td>
			        							<td>PART-5</td>                                              <td><a href='https://www.youtube.com/watch?v=v96fdMl_9IU&list=PLkj0RetP6gunuFkUIdeaMrCW-SO22lJ7L&index=5' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP752UNIT-2PART-5.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>LAW OF FORCES</td>
			        							<td>PART-6</td>                                              <td><a href='https://www.youtube.com/watch?v=LF4cGRGOO2A&list=PLkj0RetP6gunuFkUIdeaMrCW-SO22lJ7L&index=6' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP78UNIT-2PART-6.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>POONAM SHARMA</td>

			        							<td>COMMUNICATIONS SKILLS II</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Chapter 1</td>
			        							<td>Preposition part 2</td>                                              <td><a href='https://youtu.be/Aeb1cN_yj08' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS496prepositionspart-2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PC KAUSHIK</td>

			        							<td>METROLOGY AND MEASURING INSTRUEMENTS</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>MEASUREMENTS OF VIBRATION </td>
			        							<td>PART-1</td>                                              <td><a href='https://www.youtube.com/watch?v=ppZWxlu9Ivw&feature=youtu.be' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>PC KAUSHIK</td>

			        							<td>METROLOGY AND MEASURING INSTRUEMENTS</td>
			        							<td>Mechanical CAD</td>
			        							<td>6</td>
			        							<td>MEASUREMENTS OF VIBRATION </td>
			        							<td>PART-1</td>                                              <td><a href='https://www.youtube.com/watch?v=ppZWxlu9Ivw&feature=youtu.be' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>JAINESHWAR VERMA</td>

			        							<td>STRUCTURE A</td>
			        							<td>Architecture Assistantship</td>
			        							<td>4</td>
			        							<td>WELDING</td>
			        							<td>LECTURE-1</td>                                              <td><a href='https://www.youtube.com/watch?v=k2bWrJ8AX_w&t=92s' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>JAINESHWAR VERMA</td>

			        							<td>STRUCTURE A</td>
			        							<td>Architecture Assistantship</td>
			        							<td>4</td>
			        							<td>WELDING</td>
			        							<td>LECTURE-2</td>                                              <td><a href='https://www.youtube.com/watch?v=Z_EYnOt5K_c&t=62s' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>JAINESHWAR VERMA</td>

			        							<td>STRUCTURE A</td>
			        							<td>Architecture Assistantship</td>
			        							<td>4</td>
			        							<td>WELDING</td>
			        							<td>LECTURE-3</td>                                              <td><a href='https://www.youtube.com/watch?v=7BwyoaY6DTs&t=1097s' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>JAINESHWAR VERMA</td>

			        							<td>DESIGN OF STEEL AND MASONRY STRUCTURE E</td>
			        							<td>Civil Engineering</td>
			        							<td>6</td>
			        							<td>MASONARY AND FOUNDATION STRUCTURE</td>
			        							<td>COLUMN AN RDETAINING WALL</td>                                              <td><a href='https://www.youtube.com/watch?v=3CXOhndQbtg&t=1172s' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>JAINESHWAR VERMA</td>

			        							<td>DESIGN OF STEEL AND MASONRY STRUCTURE E</td>
			        							<td>Civil Engineering</td>
			        							<td>6</td>
			        							<td>COMPRESSION MEMBER</td>
			        							<td>LECTURE-1</td>                                              <td><a href='https://www.youtube.com/watch?v=Df0s7PRAywE' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>JAINESHWAR VERMA</td>

			        							<td>DESIGN OF STEEL AND MASONRY STRUCTURE E</td>
			        							<td>Civil Engineering</td>
			        							<td>6</td>
			        							<td>COMPRESSION MEMBER</td>
			        							<td>LECTURE-2</td>                                              <td><a href='https://www.youtube.com/watch?v=9ydbYlTwtn0' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>JAINESHWAR VERMA</td>

			        							<td>DESIGN OF STEEL AND MASONRY STRUCTURE E</td>
			        							<td>Civil Engineering</td>
			        							<td>6</td>
			        							<td>COMPRESSION MEMBER</td>
			        							<td>LECTURE-3</td>                                              <td><a href='https://www.youtube.com/watch?v=9ydbYlTwtn0' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>JAINESHWAR VERMA</td>

			        							<td>GENERAL ENGINEERING</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>CEMENT</td>
			        							<td>CEMENT</td>                                              <td><a href='https://www.youtube.com/watch?v=7NBkM3D1FP0&t=244s' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>JAINESHWAR VERMA</td>

			        							<td>GENERAL ENGINEERING</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>RCC</td>
			        							<td>RCC</td>                                              <td><a href='https://www.youtube.com/watch?v=x7Qj6ATjh70' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>JAINESHWAR VERMA</td>

			        							<td>GENERAL ENGINEERING</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>FOUNDATION</td>
			        							<td>FOUNDATION</td>                                              <td><a href='https://www.youtube.com/watch?v=3AjXFcRmFSk' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>JAINESHWAR VERMA</td>

			        							<td>GENERAL ENGINEERING</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>CEMENT CONCRETE</td>
			        							<td>CEMENT CONCRETE</td>                                              <td><a href='https://www.youtube.com/watch?v=5y2vBBM8V9E&t=36s' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>JAINESHWAR VERMA</td>

			        							<td>GENERAL ENGINEERING</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>TIMBER</td>
			        							<td>TIMBER</td>                                              <td><a href='https://www.youtube.com/watch?v=4P99_9BkvEM&t=250s' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>UDAY PRATAP SINGH</td>

			        							<td>APPLIED PHYSICS-II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>Current electricity</td>
			        							<td>Factor affecting of resistance </td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS416CamScanner06-08-2020085558.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>UDAY PRATAP SINGH</td>

			        							<td>Applied Physics -II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Current electricity</td>
			        							<td>Factor affecting of resistance </td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS992CamScanner06-08-2020085558.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>UDAY PRATAP SINGH</td>

			        							<td>APPLIED PHYSICS E</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>Current electricity</td>
			        							<td>Factor affecting of resistance </td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS340CamScanner06-08-2020085558.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATH-II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>Straight Line      </td>
			        							<td>Numerical / Questions</td>                                              <td><a href='https://youtu.be/QwkuaCgDUjU' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS451Lecture-206-08-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHEMATICS 1 B</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>Straight Line        </td>
			        							<td>Numerical / Questions </td>                                              <td><a href='https://youtu.be/QwkuaCgDUjU' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS232Lecture-206-08-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHS II</td>
			        							<td>Civil Engineering</td>
			        							<td>2</td>
			        							<td>Straight Line       </td>
			        							<td>Numerical / Questions </td>                                              <td><a href='https://youtu.be/QwkuaCgDUjU' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS134Lecture-206-08-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHEMATICS II</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Straight Line       </td>
			        							<td>Numerical / Questions </td>                                              <td><a href='https://youtu.be/QwkuaCgDUjU' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS939Lecture-206-08-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AKHILESH TRIVEDI</td>

			        							<td>INSTALLATION MAINTENANCE AND REPAIR OF ELECTRICAL EQUIPMENT E</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Electrical accidents and safety</td>
			        							<td>Merz price Transformer protection</td>                                              <td><a href='https://youtu.be/iJezlNAqNP0' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>AKHILESH TRIVEDI</td>

			        							<td>INSTALLATION MAINTENANCE AND REPAIR OF ELECTRICAL EQUIPMENT E</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Electrical accidents and safety</td>
			        							<td>Merz price Transformer protection</td>                                              <td><a href='https://youtu.be/iJezlNAqNP0' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>R R SINGH</td>

			        							<td>IRRIGATION ENGINEERING</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>Chapter 3</td>
			        							<td>Hydrological Cycle, Catchment Area and Run-off</td>                                              <td><a href='https://youtu.be/yJ6_CLhQe4s' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CE146Document71.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>R R SINGH</td>

			        							<td>IRRIGATION ENGINEERING</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>Chapter 3</td>
			        							<td>Hydrological Cycle, Catchment Area and Run-off</td>                                              <td><a href='https://youtu.be/yJ6_CLhQe4s' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CE54Document71.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAHUL MAURYA</td>

			        							<td>NETWORK FILTERS AND TRANSMISSION LINES</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>Transmission Lines</td>
			        							<td>Part 2</td>                                              <td><a href='https://youtu.be/5USFkG622-E' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EL918TransmissionLinePart2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>DATA COMMUNICATION</td>
			        							<td>BASIC OF DATA COMMUNICATION </td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL165mcselx3pm30-4-20.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>DATA COMMUNICATION</td>
			        							<td>MEDIUM FOR COMMUNICATION</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL964mcselx3pm1-5-20.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>DATA COMMUNICATION</td>
			        							<td>REVIEW OF DIGITAL DATA AND ANALOG MULAION,ADVANTAGE OF DIGITAL TRANSMISSION</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL237mcselx3pm2-5-20.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>DATA COMMUNICATION</td>
			        							<td>COMMUNICATION PROTOCAL</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL10mcselx3pm4-5-20.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>DATA COMMUNICATION</td>
			        							<td>OSI MODEL</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL824mcselx3pm5-5-20.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>DATA COMMUNICATION</td>
			        							<td>TCP/IP MODEL AND CONNECTION LESS -CONNECTION ORIENTED SERVICE</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL488mcselx3pm6-5-20.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>DATA COMMUNICATION</td>
			        							<td>DATA LINK LAYER -,BASIC, FUNCTION AND CONTROL</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL942mcselx3pm7-5-20.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>DATA COMMUNICATION</td>
			        							<td>SUB LAYER OF DATA LINK LAYER,VIRUS,SYNCHRONOUS AND ASYNCHRONOUS TRANSMISSION</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL742mcselx3pm8-5-20.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>DATA COMMUNICATION</td>
			        							<td>NETWORK LAYER-BASIC, FUNCTION,INTERNETWORKIN DEVICES,ADDRESSING</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL781mcselx3pm11-5-20.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>DATA COMMUNICATION</td>
			        							<td>TRANSPORT LAYER- BASIC , SERVICE,COMPARASION OF TCP/IP PROTOCAL AND OSI PROTOCAL</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL31mcselx3pm11-5(2).pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>DATA COMMUNICATION</td>
			        							<td>ISDN</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL578mcsISDN12-5.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>DATA COMMUNICATION</td>
			        							<td>INTERNET AND ITS SERVICES(E-MAIL)</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL942mcsinternet13-5.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>DATA COMMUNICATION</td>
			        							<td>internet services(ftp ,telnet, www,browser)</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL577mcsftp14-5.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ABHAI PRATAP MALL</td>

			        							<td>INDUSTRIAL ENGINEERING AND SAFETY</td>
			        							<td>Mechanical CAD</td>
			        							<td>6</td>
			        							<td>MATERIAL HANDLING EQUIPMENTS</td>
			        							<td>MATERIAL HANDLING EQUIPMENTS</td>                                              <td><a href='https://youtu.be/L5JjCtUo-d4' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ABHAI PRATAP MALL</td>

			        							<td>INDUSTRIAL ENGINEERING AND SAFETY</td>
			        							<td>Mechanical CAD</td>
			        							<td>6</td>
			        							<td>INSPECTION</td>
			        							<td>TYPES OF INSPECTION</td>                                              <td><a href='https://youtu.be/JXTPXaMMbHc' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SAUMYA MISHRA</td>

			        							<td>COMPUTER AIDED DESIGN AND MANUFACTURING</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Manufacturing Applications-Rapid Prototyping</td>
			        							<td>Laminated Object Manufacturing</td>                                              <td><a href='https://www.youtube.com/watch?v=Wyr8G6gljWE&t=352s' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SAUMYA MISHRA</td>

			        							<td>COMPUTER AIDED DESIGN AND MANUFACTURING</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Manufacturing Applications-Rapid Prototyping</td>
			        							<td>Selective Laser Sintering</td>                                              <td><a href='https://www.youtube.com/watch?v=C3MlL6Q6_ek&t=3s' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SAUMYA MISHRA</td>

			        							<td>COMPUTER AIDED DESIGN AND MANUFACTURING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Manufacturing Applications-Rapid Prototyping</td>
			        							<td>Selective Laser Sintering</td>                                              <td><a href='https://www.youtube.com/watch?v=C3MlL6Q6_ek&t=3s' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SAUMYA MISHRA</td>

			        							<td>COMPUTER AIDED DESIGN AND MANUFACTURING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Manufacturing Applications-Rapid Prototyping</td>
			        							<td>Laminated Object Manufacturing</td>                                              <td><a href='https://www.youtube.com/watch?v=Wyr8G6gljWE&t=352s' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SHIVENDRA PRATAP SINGH</td>

			        							<td>BASICS OF MECHANICAL AND CIVIL ENGINEERING E</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>Machine Components </td>
			        							<td>PIN JOINT</td>                                              <td><a href='https://youtu.be/ObVewsCgrcs' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MC328For-ELECTRICAL1STYEAR(evening)SUBJECT-BMCE.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHIVENDRA PRATAP SINGH</td>

			        							<td>INDUSTRIAL ENGG.& SAFETY.</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>PRODUCTION, PLANNING AND CONTROL</td>
			        							<td>Sales forecasting      </td>                                              <td><a href='https://youtu.be/2AmG7H9hvp0' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MC978MPE3RDYEAR,SUBJECT-IES,CHAPTER-3,BY-SHIVENDRA.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>JAINESHWAR VERMA</td>

			        							<td>DESIGN OF STEEL AND MASONRY STRUCTURE E</td>
			        							<td>Civil Engineering</td>
			        							<td>6</td>
			        							<td>STEEL ROOF TRUSS</td>
			        							<td>INTRODUCTION,   TYPES,  PARTS OF TRUSS</td>                                              <td><a href='https://www.youtube.com/watch?v=nSJooGRBqiM' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>JAINESHWAR VERMA</td>

			        							<td>DESIGN OF STEEL AND MASONRY STRUCTURE E</td>
			        							<td>Civil Engineering</td>
			        							<td>6</td>
			        							<td>STEEL ROOF TRUSS</td>
			        							<td>LECTURE -2</td>                                              <td><a href='https://www.youtube.com/watch?v=fD27hTXRwk0' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>REFRIGERATION EQUIPMENT </td>
			        							<td>COMPRESSOR </td>                                              <td><a href='https://www.youtube.com/watch?v=KCqPC8V8-uE&list=PLkj0RetP6gumzuW2TiH4NLSsGfZTmv-EJ' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP931UNIT-6PART-1.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>REFRIGERATION EQUIPMENT </td>
			        							<td>CONDENSER</td>                                              <td><a href='https://www.youtube.com/watch?v=Ysp-2ok2P0w&list=PLkj0RetP6gumzuW2TiH4NLSsGfZTmv-EJ&index=2' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP665UNIT-6PART-2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>COMPUTER AIDED DESIGN AND MANUFACTURING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>SURFACE/SOLID MODELLING USING CAD/CAM</td>
			        							<td>PART-3</td>                                              <td><a href='https://www.youtube.com/watch?v=OMUdFQK5ySs&list=PLkj0RetP6gukVKra75TtWymiOJqzkf7se&index=3' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>COMPUTER AIDED DESIGN AND MANUFACTURING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>SURFACE/SOLID MODELLING USING CAD/CAM</td>
			        							<td>PART-4</td>                                              <td><a href='https://www.youtube.com/watch?v=YM7LESEsOn0&list=PLkj0RetP6gukVKra75TtWymiOJqzkf7se&index=4' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>OM PRAKASH MISHRA</td>

			        							<td>ELECTRONIC COMPONENTS AND DEVICES</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>UNIT -3</td>
			        							<td>working of p-n-p transistor</td>                                              <td><a href='https://youtu.be/epp2mAWzvJw' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EL363Workingofp-n-pTransistor.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>OM PRAKASH MISHRA</td>

			        							<td>INDUSTRIAL ELECTRONIC AND TRANSDUCER</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>unit -5</td>
			        							<td>INSTRUMENTATION AMPLIFIER </td>                                              <td><a href='https://youtu.be/qHo8PcuM-rM' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>AMIT KUMAR PANDEY</td>

			        							<td>TRANSMISSION AND DISTRIBUTION OF ELECTRICAL POWER E</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>SUBSTATIONS</td>
			        							<td>Substation Components</td>                                              <td><a href='https://www.youtube.com/watch?v=zkFBVtw49Ds' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS  II</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Chapter 4</td>
			        							<td>Current density</td>                                              <td><a href='https://youtu.be/54v2FSST_ps' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>Chapter 4</td>
			        							<td>Current density</td>                                              <td><a href='https://youtu.be/54v2FSST_ps' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>Chapter 4</td>
			        							<td>Current density</td>                                              <td><a href='https://youtu.be/54v2FSST_ps' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>Chapter 4</td>
			        							<td>Current debsity</td>                                              <td><a href='https://youtu.be/54v2FSST_ps' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>DEEPSHIKHA MISHRA</td>

			        							<td>CIVIL ENGINEERING DRAWING II E</td>
			        							<td>Civil Engineering</td>
			        							<td>6</td>
			        							<td>Steel drawing</td>
			        							<td>Steel fink roof truss </td>                                              <td><a href='https://youtu.be/8FxCS27GmeA' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SHIVANI SHIVHARE</td>

			        							<td>UTILIZATION OF ELECTRICAL ENERGY</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Economics of Power generation</td>
			        							<td>numericals</td>                                              <td><a href='https://youtu.be/QMuAfKasFOo' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EE110numaricalanalysis.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PANKAJ CHAUHAN</td>

			        							<td>CONSTRUCTION AND MATERIAL A</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>Timber </td>
			        							<td>Topic 2</td>                                              <td><a href='https://youtu.be/MsQAbB8K6Rc' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>UDAY PRATAP SINGH</td>

			        							<td>APPLIED PHYSICS-II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>Current electricity</td>
			        							<td>Electric current</td>                                              <td><a href='https://YouTube.be/dkZFVpjE2ew' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>UDAY PRATAP SINGH</td>

			        							<td>APPLIED PHYSICS-II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>Current electricity</td>
			        							<td>Electric current</td>                                              <td><a href='https://youtu.be/dKZFVpjE2ew' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>UDAY PRATAP SINGH</td>

			        							<td>Applied Physics -II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Current electricity</td>
			        							<td>Electric current</td>                                              <td><a href='https://youtu.be/dKZFVpjE2ew' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>UDAY PRATAP SINGH</td>

			        							<td>APPLIED PHYSICS E</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>Current electricity</td>
			        							<td>Electric current</td>                                              <td><a href='https://YouTube.be/dkZFVpjE2ew' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>R R SINGH</td>

			        							<td>IRRIGATION ENGINEERING</td>
			        							<td>Civil Engineering</td>
			        							<td>6</td>
			        							<td>Chapter 3</td>
			        							<td>Water Requirement for Crops</td>                                              <td><a href='https://youtu.be/9E0f0WDFNDo' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=CE206aaaaaaaaaaaaaaaaaa.PNG' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION & DISASTER MANAGEMENT</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>Introduction</td>
			        							<td>Global warming</td>                                              <td><a href='https://youtu.be/aHw30DtFAjg' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS659AS547globalwarmingnotespdf.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT E</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Introduction</td>
			        							<td>Global warming</td>                                              <td><a href='https://youtu.be/aHw30DtFAjg' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS733AS547globalwarmingnotespdf.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AJAY KUMAR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT.</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>Introduction</td>
			        							<td>Global warming</td>                                              <td><a href='https://youtu.be/aHw30DtFAjg' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS454AS547globalwarmingnotespdf.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAHUL MAURYA</td>

			        							<td>PRINCIPAL OF COMMUNICATION ENGG</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>Generation of AM wave</td>
			        							<td>Square Law Modulator</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL242GenerationofAMwave.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAHUL MAURYA</td>

			        							<td>PRINCIPAL OF COMMUNICATION ENGG</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>Generation of AM wave</td>
			        							<td>Square Law Modulator</td>                                              <td><a href='https://youtu.be/sa5F_wt4jp8' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>NAVEEN KUMAR RAO</td>

			        							<td>HYDRAULICS AND PNEUMATICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Introduction to oil power hydraulics and pneumatics</td>
			        							<td>History of pneumatics</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC196CamScanner04-28-2020160719.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>NAVEEN KUMAR RAO</td>

			        							<td>HYDRAULICS AND PNEUMATICS</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Introduction to oil power hydraulics and pneumatics</td>
			        							<td>History of pneumatics</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC318CamScanner04-28-2020160719.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>YASHI TIWARI</td>

			        							<td>INDUSTRIAL ELECTRONICS AND CONTROL</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>SCR</td>
			        							<td>Methods to turn on SCR</td>                                              <td><a href='https://youtu.be/kpIxVDxxh_U' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EL481MethodstoturnonSCR.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DR AVINASH BAHADUR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Environmental</td>
			        							<td>Environmental Legislation</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS40IMG-20200609-WA0001.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DR AVINASH BAHADUR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Environmental</td>
			        							<td>Environmental Legislation</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS104IMG-20200609-WA0001.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DR AVINASH BAHADUR SINGH</td>

			        							<td>ENVIRONMENTAL STUDIES</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Environmental</td>
			        							<td>Environmental Legislation</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS204IMG-20200609-WA0002.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DR AVINASH BAHADUR SINGH</td>

			        							<td>ENVIRONMENTAL STUDIES</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Environmental</td>
			        							<td>Environmental Legislation</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS742IMG-20200609-WA0001.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DR AVINASH BAHADUR SINGH</td>

			        							<td>ENVIRONMENTAL STUDIES</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Environmental</td>
			        							<td>Environmental Legislation</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS273IMG-20200609-WA0002.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DR AVINASH BAHADUR SINGH</td>

			        							<td>ENVIRONMENTAL STUDIES</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Environmental</td>
			        							<td>Environmental Legislation</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS252IMG-20200609-WA0001.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>JOGENDRA KUMAR</td>

			        							<td>APPLIED MATHEMATICS II</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>NUMERICAL INTEGRATION</td>
			        							<td>"3/8" rule</td>                                              <td><a href='https://youtu.be/Qp-vlFf9lN8' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS538NUMERICALintegration1.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>JOGENDRA KUMAR</td>

			        							<td>APPLIED MATHEMATICS II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>NUMERICAL INTEGRATION</td>
			        							<td>"3/8"rule</td>                                              <td><a href='https://youtu.be/Qp-vlFf9lN8' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS658NUMERICALintegration1.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>JOGENDRA KUMAR</td>

			        							<td>Applied  Mathematics - II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>NUMERICAL INTEGRATION</td>
			        							<td>"3/8" rule</td>                                              <td><a href='https://youtu.be/Qp-vlFf9lN8' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS858NUMERICALintegration1.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>JOGENDRA KUMAR</td>

			        							<td>APPLIED MATHEMATICS II E</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>NUMERICAL INTEGRATION</td>
			        							<td>"3/8" rule</td>                                              <td><a href='https://youtu.be/Qp-vlFf9lN8' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS506NUMERICALintegration1.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>NITIN KUMAR TRIPATHI</td>

			        							<td>HIGHWAY ENGINEERING E</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>Road Geometrics</td>
			        							<td>Requisites of a good road</td>                                              <td><a href='https://youtu.be/xlSFfZBlwVw' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>DILIP UPADHYAY</td>

			        							<td>ESTIMATING COSTING AND SPECIFICATION</td>
			        							<td>Architecture Assistantship</td>
			        							<td>4</td>
			        							<td>methods of estimate</td>
			        							<td>center line method</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AA533ONLINETUTORIALASSIGNMENT-5.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DILIP UPADHYAY</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>FRICTION </td>
			        							<td>FRICTION </td>                                              <td><a href='https://youtu.be/zADj0k0waFY' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AA660AA1STYEAR,APPMECHANICSfriction.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>NITIN KUMAR TRIPATHI</td>

			        							<td>CONSTRUCTION MANAGEMENT ACCOUNTS AND ENTREPRENEURSHIP DEVELOPMENT E</td>
			        							<td>Civil Engineering</td>
			        							<td>6</td>
			        							<td>Construction planning and scheduling</td>
			        							<td>Construction planning</td>                                              <td><a href='https://youtu.be/dhgvWBddnYE' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>NITIN KUMAR TRIPATHI</td>

			        							<td>EARTHQUAKE ENGINEERING E</td>
			        							<td>Civil Engineering</td>
			        							<td>6</td>
			        							<td>Earthquakes occurrence ill-effects and hazards</td>
			        							<td>Tectonic Plates</td>                                              <td><a href='https://youtu.be/th6HVgKBa7o' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>NITIN KUMAR TRIPATHI</td>

			        							<td>EARTHQUAKE ENGINEERING E</td>
			        							<td>Civil Engineering</td>
			        							<td>6</td>
			        							<td>Causes of failure of structures during earthquakes</td>
			        							<td>Twisting of buildings during earthquakes</td>                                              <td><a href='https://youtu.be/ymQQUJIep9M' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>POONAM SHARMA</td>

			        							<td>FUNCTIONAL COMMUNICATION</td>
			        							<td>Architecture Assistantship</td>
			        							<td>4</td>
			        							<td>Grammar</td>
			        							<td>Transformation ( Affirmative into negative)</td>                                              <td><a href='https://youtu.be/ahZuLbpL8xU' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS307AAIIndyear(Transformation).pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>LAW OF FORCES</td>
			        							<td>PART-7</td>                                              <td><a href='https://www.youtube.com/watch?v=UNaN04YdyBE&list=PLkj0RetP6gunuFkUIdeaMrCW-SO22lJ7L&index=7' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP355UNIT-2PART-7.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>LAW OF FORCES</td>
			        							<td>PART-8</td>                                              <td><a href='https://www.youtube.com/watch?v=PCa5dulUfpI&list=PLkj0RetP6gunuFkUIdeaMrCW-SO22lJ7L&index=8' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP502UNIT-2PART-8.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PC KAUSHIK</td>

			        							<td>METROLOGY AND MEASURING INSTRUEMENTS</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>MEASUREMENTS OF VIBRATION</td>
			        							<td>PART-2</td>                                              <td><a href='https://www.youtube.com/watch?v=yWlvtYN5YDg&feature=youtu.be' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>satellite communication</td>
			        							<td>GEO STATIONARY SATELLITE AND  LAUNCHING</td>                                              <td><a href='https://www.youtube.com/watch?v=2BHS5EHX324&t=369s' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>DATA COMMUNICATION</td>
			        							<td>modem and wap</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL651modemandwap14-5(2).pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>DATA COMMUNICATION</td>
			        							<td>network security,digital certificate,wan devices</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL725networksecuritytopology14-5(3).pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>YASH RAJ</td>

			        							<td>COMMUNICATION SKILL-II</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>PREPOSITIONS</td>
			        							<td>BASICS OF PREPOSITION(INTRODUCTION)</td>                                              <td><a href='https://youtu.be/nqbYZAYQcpQ' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>YASH RAJ</td>

			        							<td>COMMUNICATION SKILLS II E</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>PREPOSITIONS</td>
			        							<td>BASICS OF PREPOSITION(INTRODUCTION)</td>                                              <td><a href='https://youtu.be/nqbYZAYQcpQ' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>YASH RAJ</td>

			        							<td>COMMUNICATION  SKILL-II.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>PREPOSITIONS</td>
			        							<td>BASICS OF PREPOSITION(INTRODUCTION)</td>                                              <td><a href='https://youtu.be/nqbYZAYQcpQ' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>YASH RAJ</td>

			        							<td>COMMUNICATION SKILL-II</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>PREPOSITIONS</td>
			        							<td>BASICS OF PREPOSITION(INTRODUCTION)</td>                                              <td><a href='https://youtu.be/nqbYZAYQcpQ' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>YASH RAJ</td>

			        							<td>COMMUNICATION SKILLS II E</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>PREPOSITIONS</td>
			        							<td>BASICS OF PREPOSITION(INTRODUCTION)</td>                                              <td><a href='https://youtu.be/nqbYZAYQcpQ' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>YASH RAJ</td>

			        							<td>COMMUNICATION  SKILL-II.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>PREPOSITIONS</td>
			        							<td>BASICS OF PREPOSITION(INTRODUCTION)</td>                                              <td><a href='https://youtu.be/nqbYZAYQcpQ' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATH-II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>Definite Integral</td>
			        							<td>Numerical / Questions</td>                                              <td><a href='https://youtu.be/4_b4cW45jvc' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS251Lecture-106-10-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHEMATICS 1 B</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>Definite Integral </td>
			        							<td>Numerical / Questions  </td>                                              <td><a href='https://youtu.be/4_b4cW45jvc' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS308Lecture-106-10-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHS II</td>
			        							<td>Civil Engineering</td>
			        							<td>2</td>
			        							<td>Definite Integral  </td>
			        							<td>Numerical / Questions  </td>                                              <td><a href='https://youtu.be/4_b4cW45jvc' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS696Lecture-106-10-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHEMATICS II</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Definite Integral   </td>
			        							<td>Numerical / Questions  </td>                                              <td><a href='https://youtu.be/4_b4cW45jvc' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS834Lecture-106-10-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ANKITA SRIVASTAVA</td>

			        							<td>OBJECT ORIENTED PROGRAMMING USING JAVA</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Inheritance </td>
			        							<td>Program on inheritance </td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=CS208Programoninheritance.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ANIL KUMAR YADAV</td>

			        							<td>ELECTRICAL DESIGN DRAWING AND ESTIMATING II E</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Service connection</td>
			        							<td>Material required for service connections</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE559serviceconnection1-3.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ANIL KUMAR YADAV</td>

			        							<td>ELECTRICAL DESIGN DRAWING AND ESTIMATING II E</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Service connections</td>
			        							<td>Diagram of different types of service connections</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE768serviceconnection1-4.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ANIL KUMAR YADAV</td>

			        							<td>ELECTRICAL DESIGN DRAWING AND ESTIMATING II E</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>House wiring</td>
			        							<td>Wiring systems</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE300HW-2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AMIT KUMAR PANDEY</td>

			        							<td>BASIC ELECTRICAL ENGINEERING E</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>BATTERIES</td>
			        							<td>Working principle of Lead Acid Cell</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE159Workingprincipleofleadacidcell.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ANIL KUMAR YADAV</td>

			        							<td>ELECTRICAL DESIGN DRAWING AND ESTIMATING II E</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Electric substation</td>
			        							<td>Types and material requirements</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE243EDDE-2,3EE,by-AKyadav(5).pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DEEPSHIKHA MISHRA</td>

			        							<td>REINFORCED CEMENT CONCRETE STRUCTURES E</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>Introduction to limit state method </td>
			        							<td>Actual neutral axis and types of section</td>                                              <td><a href='https://youtu.be/L0n7FHvMRvo' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>ANIL KUMAR YADAV</td>

			        							<td>ELECTRICAL DESIGN DRAWING AND ESTIMATING II E</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Overhead and underground lines</td>
			        							<td>Stay arrangements</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE930Stayarrangement-2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>VIVEKANAND YADAV</td>

			        							<td>APPLIED MECHANICS.</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Friction</td>
			        							<td>Friction and its classification</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MP472friction1(1).pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAHUL MAURYA</td>

			        							<td>NETWORK FILTERS AND TRANSMISSION LINES</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>Transmission Lines</td>
			        							<td>Part 3</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL396TransmissionLinepart3min.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAHUL MAURYA</td>

			        							<td>NETWORK FILTERS AND TRANSMISSION LINES</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>Transmission Lines</td>
			        							<td>Part 3</td>                                              <td><a href='https://youtu.be/RoxSkN5PODM' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>PANKAJ CHAUHAN</td>

			        							<td>CONSTRUCTION AND MATERIAL C</td>
			        							<td>Architecture Assistantship</td>
			        							<td>6</td>
			        							<td>Roofs</td>
			        							<td>Topic 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AA142ReinforcedCeme-WPSOffice.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td> REFRIGERATION EQUIPMENT </td>
			        							<td>EVAPORATOR</td>                                              <td><a href='https://www.youtube.com/watch?v=gJK1B4p_mjU&list=PLkj0RetP6gukvHEU5URp0tAL03VyIGBRf&index=9' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP87UNIT-6PART-3.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>REFRIGERATION EQUIPMENT </td>
			        							<td>EXPANSION VALVE</td>                                              <td><a href='https://www.youtube.com/watch?v=24d00eL7Sf8&list=PLkj0RetP6gukvHEU5URp0tAL03VyIGBRf&index=10' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP110UNIT-6PART-4.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>COMPUTER AIDED DESIGN AND MANUFACTURING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>SURFACE/SOLID MODELLING USING CAD/CAM</td>
			        							<td>PART-5</td>                                              <td><a href='https://www.youtube.com/watch?v=jT4A0-yfJz8&list=PLkj0RetP6gukVKra75TtWymiOJqzkf7se&index=5' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>COMPUTER AIDED DESIGN AND MANUFACTURING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>SURFACE/SOLID MODELLING USING CAD/CAM</td>
			        							<td>PART-6</td>                                              <td><a href='https://www.youtube.com/watch?v=BUziPv6ZdSU&list=PLkj0RetP6gukVKra75TtWymiOJqzkf7se&index=6' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>DEEP SHIKHA</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>Electrostatic </td>
			        							<td>Electric field </td>                                              <td><a href='https://youtu.be/ONry727j5MQ' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS775IMG20200611082756.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DEEP SHIKHA</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>Electrostatic </td>
			        							<td>Electric field </td>                                              <td><a href='https://youtu.be/ONry727j5MQ' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS913IMG20200611082756.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DEEP SHIKHA</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Electrostatic </td>
			        							<td>Electric field </td>                                              <td><a href='https://youtu.be/ONry727j5MQ' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS992IMG20200611082756.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AMIT KUMAR PANDEY</td>

			        							<td>TRANSMISSION AND DISTRIBUTION OF ELECTRICAL POWER E</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>SUBSTATIONS</td>
			        							<td>Main types of Electrical Substations</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE217MaintypesofElectricalSubstations.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>UDAY PRATAP SINGH</td>

			        							<td>APPLIED PHYSICS-II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>Current electricity</td>
			        							<td>Combination of resistance</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS937CamScanner06-11-2020092747.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>UDAY PRATAP SINGH</td>

			        							<td>Applied Physics -II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Current electricity</td>
			        							<td>Combination of resistance</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS935CamScanner06-11-2020092747.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>UDAY PRATAP SINGH</td>

			        							<td>APPLIED PHYSICS E</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>Current electricity</td>
			        							<td>Combination of resistance</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS715CamScanner06-11-2020092747.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS  II</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Chapter 4</td>
			        							<td>Thermal and drift velocity</td>                                              <td><a href='https://youtu.be/cG5MbGT_I9Q' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>Chapter 4</td>
			        							<td>Thermal and drift velocity</td>                                              <td><a href='https://youtu.be/cG5MbGT_I9Q' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>RAJKISHOR PRAJAPATI</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>Chapter 4</td>
			        							<td>Thermal and drift velocity</td>                                              <td><a href='https://youtu.be/cG5MbGT_I9Q' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SHIVANI SHIVHARE</td>

			        							<td>UTILIZATION OF ELECTRICAL ENERGY</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Electric Cooling</td>
			        							<td>Refrigration Concept</td>                                              <td><a href='https://youtu.be/e0Q4gxvGI2M' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EE291electriccooling.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAHUL MAURYA</td>

			        							<td>PRINCIPAL OF COMMUNICATION ENGG</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>Generation of AM wave</td>
			        							<td>Balanced and Collector Modulator</td>                                              <td><a href='https://youtu.be/-lkoLwtWBRI' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EL507BalancedandCollectorModulator-compressed.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRATIKSHA AGARWAL</td>

			        							<td>GENERAL ENGINEERING.</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Batteries</td>
			        							<td>Combination of cells</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE486MPE1yrGEpratikshaagarwal.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>NAVEEN KUMAR RAO</td>

			        							<td>BASICS OF MECHANICAL AND ELECTRICAL ENGINEERING</td>
			        							<td>Civil Engineering</td>
			        							<td>2</td>
			        							<td>gear </td>
			        							<td>Compound geartrain</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC333NewDoc04-07-2020110933.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>LAW OF FORCES</td>
			        							<td>PART-9</td>                                              <td><a href='https://www.youtube.com/watch?v=DxBBFYJMJHg&list=PLkj0RetP6gunuFkUIdeaMrCW-SO22lJ7L&index=9' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP316UNIT-2PART-9.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>LAW OF FORCES</td>
			        							<td>PART-10</td>                                              <td><a href='https://www.youtube.com/watch?v=6XDcoSVE3ME&list=PLkj0RetP6gunuFkUIdeaMrCW-SO22lJ7L&index=10' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP935UNIT-2PART-10.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PC KAUSHIK</td>

			        							<td>METROLOGY AND MEASURING INSTRUEMENTS</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>INSPECTION OF GEOMETRICAL ERRORS</td>
			        							<td>PART-1</td>                                              <td><a href='https://www.youtube.com/watch?v=cfb7VH-Vdj8&feature=youtu.be' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>PC KAUSHIK</td>

			        							<td>METROLOGY AND MEASURING INSTRUEMENTS</td>
			        							<td>Mechanical CAD</td>
			        							<td>6</td>
			        							<td>INSPECTION OF GEOMETRICAL ERRORS</td>
			        							<td>PART-1</td>                                              <td><a href='https://www.youtube.com/watch?v=cfb7VH-Vdj8&feature=youtu.be' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>JOGENDRA KUMAR</td>

			        							<td>APPLIED MATHEMATICS II</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>The point in space</td>
			        							<td>Coordinates related</td>                                              <td><a href='https://youtu.be/z8MtqyeqcqA' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS298Thepointinspace1.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>JOGENDRA KUMAR</td>

			        							<td>APPLIED MATHEMATICS II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>The point in space</td>
			        							<td>Coordinates related</td>                                              <td><a href='https://youtu.be/z8MtqyeqcqA' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS728Thepointinspace1.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>JOGENDRA KUMAR</td>

			        							<td>Applied  Mathematics - II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>The point in space</td>
			        							<td>Coordinates related</td>                                              <td><a href='https://youtu.be/z8MtqyeqcqA' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS744Thepointinspace1.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>JOGENDRA KUMAR</td>

			        							<td>APPLIED MATHEMATICS II E</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>The point in space</td>
			        							<td>Coordinates related</td>                                              <td><a href='https://youtu.be/z8MtqyeqcqA' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS324Thepointinspace1.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATH-II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>Definite Integral    </td>
			        							<td>Properties and Numerical</td>                                              <td><a href='https://youtu.be/nssO5oPu6NI' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS446Lecture-206-12-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHEMATICS 1 B</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>Definite Integral     </td>
			        							<td>Properties and Numerical </td>                                              <td><a href='https://youtu.be/nssO5oPu6NI' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS94Lecture-206-12-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHS II</td>
			        							<td>Civil Engineering</td>
			        							<td>2</td>
			        							<td>Definite Integral      </td>
			        							<td>Properties and Numerical  </td>                                              <td><a href='https://youtu.be/nssO5oPu6NI' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS180Lecture-206-12-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHEMATICS II</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Definite Integral      </td>
			        							<td>Properties and Numerical   </td>                                              <td><a href='https://youtu.be/nssO5oPu6NI' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS682Lecture-206-12-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>VIVEKANAND YADAV</td>

			        							<td>APPLIED MECHANICS.</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Friction</td>
			        							<td>Law of friction and conditions of equilibrium on different positions of block</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MP443Frictionpart-2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAHUL MAURYA</td>

			        							<td>NETWORK FILTERS AND TRANSMISSION LINES</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>Transmission Lines</td>
			        							<td>Part 4, Distortions</td>                                              <td><a href='https://youtu.be/WdrHy13zJLo' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EL707TransmissionLinepart4.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>GAURAV KUMAR KASHYAP</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>General Conditions of Equilibrium</td>
			        							<td>General Conditions of EquilibriumG Part -1</td>                                              <td><a href='https://youtu.be/Xi1u2RhrR24' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>GAURAV KUMAR KASHYAP</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>General Conditions of Equilibrium</td>
			        							<td>General Conditions of EquilibriumG Part -1</td>                                              <td><a href='https://youtu.be/Xi1u2RhrR24' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>NAVEEN KUMAR RAO</td>

			        							<td>HYDRAULICS AND PNEUMATICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Introduction to oil power hydraulics and pneumatics</td>
			        							<td>Difference between hydraulic and pneumatic system</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC696CamScanner05-01-2020114002.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>NAVEEN KUMAR RAO</td>

			        							<td>HYDRAULICS AND PNEUMATICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Introduction to oil power hydraulics and pneumatics</td>
			        							<td>Difference between hydraulic and pneumatic system</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC908CamScanner05-01-2020114002.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>NAVEEN KUMAR RAO</td>

			        							<td>HYDRAULICS AND PNEUMATICS</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Introduction to oil power hydraulics and pneumatics</td>
			        							<td>Difference between hydraulic and pneumatic system</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC224CamScanner05-01-2020114002.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>DIGITAL COMMUNICATION</td>
			        							<td>Basic,advantage, disadvantage and definition of information </td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL730digitalcommbasic.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>DIGITAL COMMUNICATION</td>
			        							<td>Basic and definition of information </td>                                              <td><a href='outube.com/watch?v=dBUavS2DeKM' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>DIGITAL COMMUNICATION</td>
			        							<td>basic</td>                                              <td><a href='https://www.youtube.com/watch?v=dBUavS2DeKM' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>NAINIKA RAI</td>

			        							<td>HISTORY OF ARCHITECTURE B</td>
			        							<td>Architecture Assistantship</td>
			        							<td>4</td>
			        							<td>MODERN ARCHITECTURE</td>
			        							<td>LE-CORBUSIER</td>                                              <td><a href='https://youtu.be/x7uVg3UxWwA' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>NAINIKA RAI</td>

			        							<td>TOWN PLANNING</td>
			        							<td>Architecture Assistantship</td>
			        							<td>4</td>
			        							<td>ORIGIN OF TOWN PLANNING</td>
			        							<td>INDUS VALLEY CIVILIZATION </td>                                              <td><a href='https://youtu.be/3TobrQQS-aA' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>DR AVINASH BAHADUR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Environmental</td>
			        							<td>Environmental Legislation 2</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS601IMG-20200612-WA0002.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DR AVINASH BAHADUR SINGH</td>

			        							<td>ENVIRONMENTAL EDUCATION AND DISASTER MANAGEMENT</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Environmental</td>
			        							<td>Environmental Legislation 2</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS998IMG-20200612-WA0001.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DR AVINASH BAHADUR SINGH</td>

			        							<td>ENVIRONMENTAL STUDIES</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Environmental</td>
			        							<td>Environmental Legislation 2</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS723IMG-20200612-WA0002.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DR AVINASH BAHADUR SINGH</td>

			        							<td>ENVIRONMENTAL STUDIES</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Environmental</td>
			        							<td>Environmental Legislation 2</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS803IMG-20200612-WA0001.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DR AVINASH BAHADUR SINGH</td>

			        							<td>ENVIRONMENTAL STUDIES</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Environmental</td>
			        							<td>Environmental Legislation 2</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS644IMG-20200612-WA0002.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DR AVINASH BAHADUR SINGH</td>

			        							<td>ENVIRONMENTAL STUDIES</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Environmental</td>
			        							<td>Environmental Legislation 2</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS496IMG-20200612-WA0001.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DR AVINASH BAHADUR SINGH</td>

			        							<td>ENVIRONMENTAL STUDIES</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Environmental</td>
			        							<td>Environmental Legislation 2</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS296IMG-20200612-WA0002.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DILIP UPADHYAY</td>

			        							<td>ESTIMATING COSTING AND SPECIFICATION</td>
			        							<td>Architecture Assistantship</td>
			        							<td>4</td>
			        							<td>APPLIED MECHANICS </td>
			        							<td>CENTER OF GRAVITY </td>                                              <td><a href='https://youtu.be/R8wKV0UQtlo?t=29' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AA866centerofgravity-2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DR AVINASH BAHADUR SINGH</td>

			        							<td>ENVIRONMENTAL STUDIES</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Environmental</td>
			        							<td>Environmental Legislation 2</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS199IMG-20200612-WA0001.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DILIP UPADHYAY</td>

			        							<td>ESTIMATING COSTING AND SPECIFICATION</td>
			        							<td>Architecture Assistantship</td>
			        							<td>4</td>
			        							<td>SPECIFICATION </td>
			        							<td>SPECIFICATION </td>                                              <td><a href='https://youtu.be/4DrQeSFKSPQ?t=21' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AA861AA2NDYEARSPECIFICATION.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DILIP UPADHYAY</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>APPLIED MECHANICS </td>
			        							<td>CENTER OF GRAVITY </td>                                              <td><a href='https://youtu.be/R8wKV0UQtlo?t=5' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AA523centerofgravity-2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHIVENDRA PRATAP SINGH</td>

			        							<td>INDUSTRIAL ENGG.& SAFETY.</td>
			        							<td>Mechanical Production</td>
			        							<td>6</td>
			        							<td>work study</td>
			        							<td>definition of work study </td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC875MPE3RDYEAR,SUBJECT-IES,CHAPTER-2PART-1,BY-SHIVENDRA.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHIVENDRA PRATAP SINGH</td>

			        							<td>ENERGY  CONSERVATION.</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>General Energy Saving Tips </td>
			        							<td>General Energy Saving Tips for equipment</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=MC582MEP2NDYEAR,ENERGYCONSERVATION,CHAPTER-9,By-SHIVENDRA.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>REFRIGERATION EQUIPMENT </td>
			        							<td>SAFETY DEVICES</td>                                              <td><a href='https://www.youtube.com/watch?v=vPtK7wWOO_k&list=PLkj0RetP6gukvHEU5URp0tAL03VyIGBRf&index=11' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP981UNIT-6PART-5.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Report writing </td>
			        							<td>Report writing 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS15Screenshot20200613-094501CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Report writing </td>
			        							<td>Report writing 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS319Screenshot20200613-094530CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Report writing </td>
			        							<td>Report writing 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS800Screenshot20200613-094611CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Report writing </td>
			        							<td>Report writing 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS460Screenshot20200613-094501CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Report writing </td>
			        							<td>Report writing 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS749Screenshot20200613-094530CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Report writing </td>
			        							<td>Report writing 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS450Screenshot20200613-094611CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Report writing </td>
			        							<td>Report writing 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS335Screenshot20200613-094501CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Report writing </td>
			        							<td>Report writing 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS247Screenshot20200613-094501CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Report writing </td>
			        							<td>Report writing 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS61Screenshot20200613-094530CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Report writing </td>
			        							<td>Report writing 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS477Screenshot20200613-094611CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>Report writing </td>
			        							<td>Report writing 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS220Screenshot20200613-094501CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>Report writing </td>
			        							<td>Report writing 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS125Screenshot20200613-094530CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>Report writing </td>
			        							<td>Report writing 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS580Screenshot20200613-094611CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>UDAY PRATAP SINGH</td>

			        							<td>APPLIED PHYSICS-II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>Current electricity</td>
			        							<td>Limitations of ohm law</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS743CamScanner06-13-2020095932.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>UDAY PRATAP SINGH</td>

			        							<td>Applied Physics -II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Current electricity</td>
			        							<td>Limitations of ohm law</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS362CamScanner06-13-2020095932.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>UDAY PRATAP SINGH</td>

			        							<td>APPLIED PHYSICS E</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>Current electricity</td>
			        							<td>Limitations of ohm law</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS566CamScanner06-13-2020095932.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS</td>
			        							<td>Mechanical CAD</td>
			        							<td>4</td>
			        							<td>Practical </td>
			        							<td>Practical 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS234Screenshot20200613-100330CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Practical </td>
			        							<td>Practical 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS609Screenshot20200613-100330CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>Practical </td>
			        							<td>Practical 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS50Screenshot20200613-100330CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Practical </td>
			        							<td>Practical 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS475Screenshot20200613-100330CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>UDAY PRATAP SINGH</td>

			        							<td>APPLIED PHYSICS-II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>Current electricity</td>
			        							<td>Temperature dependence on resistivity</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS269CamScanner06-13-2020100347.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SANTOSH KUMAR SINGH</td>

			        							<td>COMMUNICATION SKILLS II</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>Practical </td>
			        							<td>Practical 1</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS574Screenshot20200613-100330CamScanner.jpg' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>UDAY PRATAP SINGH</td>

			        							<td>Applied Physics -II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Current electricity</td>
			        							<td>Temperature dependence on resistivity</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS953CamScanner06-13-2020100347.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>UDAY PRATAP SINGH</td>

			        							<td>APPLIED PHYSICS E</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>Current electricity</td>
			        							<td>Temperature dependence on resistivity</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS252CamScanner06-13-2020100347.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AMIT KUMAR PANDEY</td>

			        							<td>TRANSMISSION AND DISTRIBUTION OF ELECTRICAL POWER E</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>SUBSTATIONS</td>
			        							<td>Layout of Electrical Substations</td>                                              <td><a href='https://www.youtube.com/watch?v=Bx-mqxf4R9I' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>UDAY PRATAP SINGH</td>

			        							<td>APPLIED PHYSICS-II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>Current electricity</td>
			        							<td>Superconductivity</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS728CamScanner06-13-2020100455.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DEEP SHIKHA</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Electrostatic </td>
			        							<td>Electric field and intensity of electric field </td>                                              <td><a href='https://youtu.be/f8ZUlHBiiDc' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>UDAY PRATAP SINGH</td>

			        							<td>Applied Physics -II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Current electricity</td>
			        							<td>Superconductivity</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS143CamScanner06-13-2020100455.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DEEP SHIKHA</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>Electrostatic </td>
			        							<td>Electric field and intensity of electric field </td>                                              <td><a href='https://youtu.be/f8ZUlHBiiDc' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>UDAY PRATAP SINGH</td>

			        							<td>APPLIED PHYSICS E</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>Current electricity</td>
			        							<td>Superconductivity</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS132CamScanner06-13-2020100455.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAHUL MAURYA</td>

			        							<td>PRINCIPAL OF COMMUNICATION ENGG</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>Generation of AM wave</td>
			        							<td>Base Modulator</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL846BaseModulator.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>SHIVANI SHIVHARE</td>

			        							<td>UTILIZATION OF ELECTRICAL ENERGY</td>
			        							<td>Electrical Engineering</td>
			        							<td>6</td>
			        							<td>Electric Cooling</td>
			        							<td>vapour compression cycle</td>                                              <td><a href='https://youtu.be/gYy6ZkxM8hU' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EE683electriccooling.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ABHAI PRATAP MALL</td>

			        							<td>INDUSTRIAL ENGINEERING AND SAFETY</td>
			        							<td>Mechanical CAD</td>
			        							<td>6</td>
			        							<td>VALUE ENGINEERING</td>
			        							<td>DEFINITION,TYPES,AIMS&TECHNIQUES</td>                                              <td><a href='https://youtu.be/Hmg5vx1Zg_0' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SAURABH KUMAR SONI</td>

			        							<td>BASICS OF MECHANICAL AND CIVIL ENGINEERING</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>CEMENT COCRETE</td>
			        							<td>CEMENT COCRETE</td>                                              <td><a href='https://youtu.be/5y2vBBM8V9E' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SAURABH KUMAR SONI</td>

			        							<td>BASICS OF MECHANICAL AND CIVIL ENGINEERING</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>FOUNDATION</td>
			        							<td>FOUNDATION</td>                                              <td><a href='https://youtu.be/3AjXFcRmFSk' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>SAURABH KUMAR SONI</td>

			        							<td>BASICS OF MECHANICAL AND CIVIL ENGINEERING</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>GENERAL ENG.</td>
			        							<td>GENERAL ENG.</td>                                              <td><a href='https://youtu.be/7NBkM3D1FP' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>RUPESH GOKHLANI</td>

			        							<td>ANALOG ELECTRONICS E</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>Chapter 3</td>
			        							<td>Single Stage Transistor Amplifier </td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL141SingleStageamplifierFullChaptercompressed.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RUPESH GOKHLANI</td>

			        							<td>ANALOG ELECTRONICS E</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>Chapter 4</td>
			        							<td>Single Stage Transistor Amplifier </td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL0SingleStageamplifierFullChaptercompressed.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RUPESH GOKHLANI</td>

			        							<td>ANALOG ELECTRONICS E</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>Chapter 5</td>
			        							<td>Multi Stage Transistor Amplifier </td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL250MultistageAmplifiercompressed(1).pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RUPESH GOKHLANI</td>

			        							<td>ANALOG ELECTRONICS E</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>Chapter 5</td>
			        							<td>Multi Stage Transistor Amplifier </td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL22MultistageAmplifiercompressed.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>JOGENDRA KUMAR</td>

			        							<td>APPLIED MATHEMATICS II</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>The point in space</td>
			        							<td>Coordinates related</td>                                              <td><a href='https://youtu.be/Ej0WFzxzT8U' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>JOGENDRA KUMAR</td>

			        							<td>APPLIED MATHEMATICS II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>The point in space</td>
			        							<td>Coordinates related</td>                                              <td><a href='https://youtu.be/Ej0WFzxzT8U' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>JOGENDRA KUMAR</td>

			        							<td>Applied  Mathematics - II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>The point in space</td>
			        							<td>Coordinates related</td>                                              <td><a href='https://youtu.be/Ej0WFzxzT8U' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>JOGENDRA KUMAR</td>

			        							<td>APPLIED MATHEMATICS II E</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>The point in space</td>
			        							<td>Coordinates related</td>                                              <td><a href='https://youtu.be/Ej0WFzxzT8U' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>POONAM SHARMA</td>

			        							<td>FUNCTIONAL COMMUNICATION</td>
			        							<td>Architecture Assistantship</td>
			        							<td>4</td>
			        							<td>Chapter 6</td>
			        							<td>Leadership and supervision</td>                                              <td><a href='https://youtu.be/PNPKY66c6Qs' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS523AAIIndyear(FC).pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>POONAM SHARMA</td>

			        							<td>COMMUNICATION SKILLS II E</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>Chapter 1</td>
			        							<td>Preposition part 3</td>                                              <td><a href='https://youtu.be/FnWogwtkNPY' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS756prepositionspart-3.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>POONAM SHARMA</td>

			        							<td>COMMUNICATIONS SKILLS II</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Chapter 1</td>
			        							<td>Preposition part 3</td>                                              <td><a href='https://youtu.be/FnWogwtkNPY' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS644prepositionspart-3.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>POONAM SHARMA</td>

			        							<td>COMMUNICATION SKILLS II E</td>
			        							<td>Civil Engineering</td>
			        							<td>4</td>
			        							<td>Chapter 2</td>
			        							<td>Framing questions</td>                                              <td><a href='https://youtu.be/TjGT6PAW87Q' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>POONAM SHARMA</td>

			        							<td>COMMUNICATIONS SKILLS II</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>4</td>
			        							<td>Chapter 2</td>
			        							<td>Framing questions</td>                                              <td><a href='https://youtu.be/TjGT6PAW87Q' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>AMIT KUMAR PANDEY</td>

			        							<td>BASIC ELECTRICAL ENGINEERING E</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>BATTERIES</td>
			        							<td>Nickel Cadmium Battery</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE857Ni-CdBattery.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATH-II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>Definite Integral     </td>
			        							<td>Numerical / Questions   </td>                                              <td><a href='https://youtu.be/Q_iXvlbHIOM' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS112Lecture-306-15-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHEMATICS 1 B</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>Definite Integral    </td>
			        							<td>Numerical / Questions  </td>                                              <td><a href='https://youtu.be/Q_iXvlbHIOM' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS36Lecture-306-15-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHS II</td>
			        							<td>Civil Engineering</td>
			        							<td>2</td>
			        							<td>Definite Integral   </td>
			        							<td>Numerical / Questions  </td>                                              <td><a href='https://youtu.be/Q_iXvlbHIOM' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS487Lecture-306-15-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>KRIPA NARAIN SINGH</td>

			        							<td>APPLIED MATHEMATICS II</td>
			        							<td>Computer Science and Engineering</td>
			        							<td>2</td>
			        							<td>Definite Integral  </td>
			        							<td>Numerical / Questions  </td>                                              <td><a href='https://youtu.be/Q_iXvlbHIOM' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=AS226Lecture-306-15-2020.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAHUL MAURYA</td>

			        							<td>NETWORK FILTERS AND TRANSMISSION LINES</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>Transmission Lines</td>
			        							<td>Attenuation</td>                                              <td><a href='https://youtu.be/4j02cgefYyw' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EL518Attenuation.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>MOMENT AND COUPLE</td>
			        							<td>PART-1</td>                                              <td><a href='https://www.youtube.com/watch?v=Dy26FRvOJEI&list=PLkj0RetP6gunuFkUIdeaMrCW-SO22lJ7L&index=11' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP822UNIT-3PART-1.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>MOMENT AND COUPLE</td>
			        							<td>PART-2</td>                                              <td><a href='https://www.youtube.com/watch?v=FJU5QDiNP7E&list=PLkj0RetP6gunuFkUIdeaMrCW-SO22lJ7L&index=12' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP194UNIT-3PART-2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>PSYCHROMETRY</td>
			        							<td>PART-1</td>                                              <td><a href='https://www.youtube.com/watch?v=dxeUDz5DA34&list=PLkj0RetP6gukvHEU5URp0tAL03VyIGBRf&index=10' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>PSYCHROMETRY</td>
			        							<td>PART-2</td>                                              <td><a href='https://www.youtube.com/watch?v=bQMv0ieWTuQ&list=PLkj0RetP6gukvHEU5URp0tAL03VyIGBRf&index=11' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>PSYCHROMETRY</td>
			        							<td>PART-3</td>                                              <td><a href='https://www.youtube.com/watch?v=Y1oqvYY2_bQ&list=PLkj0RetP6gukvHEU5URp0tAL03VyIGBRf&index=12' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>COMPUTER AIDED DESIGN AND MANUFACTURING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>SURFACE/SOLID MODELLING USING CAD/CAM</td>
			        							<td>PART-7</td>                                              <td><a href='https://www.youtube.com/watch?v=W40fyre85F8&list=PLkj0RetP6gukVKra75TtWymiOJqzkf7se&index=7' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>UDAY PRATAP SINGH</td>

			        							<td>APPLIED PHYSICS-II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>Current electricity</td>
			        							<td>Heating effect of current , electric power etc</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS823CamScanner06-16-2020100216.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>UDAY PRATAP SINGH</td>

			        							<td>Applied Physics -II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Current electricity</td>
			        							<td>Heating effect of current , electric power etc</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS461CamScanner06-16-2020100216.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>UDAY PRATAP SINGH</td>

			        							<td>APPLIED PHYSICS E</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>Current electricity</td>
			        							<td>Heating effect of current , electric power etc</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS505CamScanner06-16-2020100216.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAHUL MAURYA</td>

			        							<td>PRINCIPAL OF COMMUNICATION ENGG</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>Generation of FM wave</td>
			        							<td>Reactance Modulator</td>                                              <td><a href='https://youtu.be/vGU58UNSzic' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EL108GenerationofFMwave.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DEEP SHIKHA</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Electrostatic </td>
			        							<td>Electric flux</td>                                              <td><a href='https://youtu.be/vWVBa3y__nE' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>DEEP SHIKHA</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>Electrostatic </td>
			        							<td>Electric flux</td>                                              <td><a href='https://youtu.be/vWVBa3y__nE' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>PRAGYAN MISHRA</td>

			        							<td>MODERN COMMUNICATION SYSTEM</td>
			        							<td>Electronics Engineering</td>
			        							<td>6</td>
			        							<td>DIGITAL COMMUNICATION</td>
			        							<td>INFORMATION EXAMPLE, ENTROPY ,SHANNON  CODE</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EL692entropy.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>ANIL KUMAR YADAV</td>

			        							<td>UNIVERSAL HUMAN VALUES E</td>
			        							<td>Electrical Engineering</td>
			        							<td>4</td>
			        							<td>Unit 2</td>
			        							<td>Prosperity and wealth</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE702UHV,2EEE-Akyadav1.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>MOMENT AND COUPLE</td>
			        							<td>PART-3</td>                                              <td><a href='https://www.youtube.com/watch?v=GZ4Vdvr0pP8&list=PLkj0RetP6gunuFkUIdeaMrCW-SO22lJ7L&index=13' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP149UNIT-3PART-3.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>MOMENT AND COUPLE</td>
			        							<td>PART-4</td>                                              <td><a href='https://www.youtube.com/watch?v=_iRDlZQV1zM&list=PLkj0RetP6gunuFkUIdeaMrCW-SO22lJ7L&index=14' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP616UNIT-3PART-4.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>MOMENT AND COUPLE</td>
			        							<td>PART-5</td>                                              <td><a href='https://www.youtube.com/watch?v=HVz87m9U_Q0&list=PLkj0RetP6gunuFkUIdeaMrCW-SO22lJ7L&index=15' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP588UNIT-3PART-5.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>RAHUL MAURYA</td>

			        							<td>NETWORK FILTERS AND TRANSMISSION LINES</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>Transmission Lines</td>
			        							<td>Equations</td>                                              <td><a href='https://youtu.be/gscaKidsmww' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=EL783TransmissionLineequations.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>OM PRAKASH MISHRA</td>

			        							<td>ELECTRONIC COMPONENTS AND DEVICES</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>Unit -3</td>
			        							<td>Transistor Configuration.</td>                                              <td><a href='https://youtu.be/jtI6CYF5MAQ' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>OM PRAKASH MISHRA</td>

			        							<td>INDUSTRIAL ELECTRONIC AND TRANSDUCER</td>
			        							<td>Electronics Engineering</td>
			        							<td>4</td>
			        							<td>Unit-4</td>
			        							<td>Transducer.</td>                                              <td><a href='https://youtu.be/ePO0vN5fjzU' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>APPLIED PSYCHROMETRY</td>
			        							<td>PART-1</td>                                              <td><a href='https://www.youtube.com/watch?v=0X1rftjKNHs&list=PLkj0RetP6gukvHEU5URp0tAL03VyIGBRf&index=13' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>APPLIED PSYCHROMETRY</td>
			        							<td>PART-2</td>                                              <td><a href='https://www.youtube.com/watch?v=DyZF7Nfqcts&list=PLkj0RetP6gukvHEU5URp0tAL03VyIGBRf&index=14' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>APPLIED PSYCHROMETRY</td>
			        							<td>PART-3</td>                                              <td><a href='https://www.youtube.com/watch?v=5Tndw-MxIGk&list=PLkj0RetP6gukvHEU5URp0tAL03VyIGBRf&index=15' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>COMPUTER AIDED DESIGN AND MANUFACTURING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>VIEWING OBJECTS IN 3D SPACE</td>
			        							<td>PART-1</td>                                              <td><a href='https://www.youtube.com/watch?v=nPrpxp1t1AU&list=PLkj0RetP6gukVKra75TtWymiOJqzkf7se&index=8' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>COMPUTER AIDED DESIGN AND MANUFACTURING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>VIEWING OBJECTS IN 3D SPACE</td>
			        							<td>PART-2</td>                                              <td><a href='https://www.youtube.com/watch?v=kM5Bf2fQEEs&list=PLkj0RetP6gukVKra75TtWymiOJqzkf7se&index=9' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>MOMENT AND COUPLE</td>
			        							<td>PART-6</td>                                              <td><a href='https://www.youtube.com/watch?v=bckXLjxsMb0&list=PLkj0RetP6gunuFkUIdeaMrCW-SO22lJ7L&index=16' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP987UNIT-3PART-6.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>MOMENT AND COUPLE</td>
			        							<td>PART-7</td>                                              <td><a href='https://www.youtube.com/watch?v=A5NUMWFkiRw&list=PLkj0RetP6gunuFkUIdeaMrCW-SO22lJ7L&index=17' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP503UNIT-3PART-7.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>MOMENT AND COUPLE</td>
			        							<td>PART-8</td>                                              <td><a href='https://www.youtube.com/watch?v=NogbjtMvCjE&list=PLkj0RetP6gunuFkUIdeaMrCW-SO22lJ7L&index=18' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP0UNIT-3PART-8.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>UDAY PRATAP SINGH</td>

			        							<td>APPLIED PHYSICS-II</td>
			        							<td>Electronics Engineering</td>
			        							<td>2</td>
			        							<td>Current electricity</td>
			        							<td>Kirchhoff law</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS653CamScanner06-18-2020095656.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>UDAY PRATAP SINGH</td>

			        							<td>Applied Physics -II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Current electricity</td>
			        							<td>Kirchhoff law</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS522CamScanner06-18-2020095656.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>UDAY PRATAP SINGH</td>

			        							<td>APPLIED PHYSICS E</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>Current electricity</td>
			        							<td>Kirchhoff law</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=AS26CamScanner06-18-2020095656.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DEEP SHIKHA</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Electrostatic </td>
			        							<td>Gauss law</td>                                              <td><a href='https://youtu.be/zaOqQq0whHY' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>DEEP SHIKHA</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>Electrostatic </td>
			        							<td>Gauss law</td>                                              <td><a href='https://youtu.be/zaOqQq0whHY' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>AMIT KUMAR PANDEY</td>

			        							<td>BASIC ELECTRICAL ENGINEERING E</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>BATTERIES</td>
			        							<td>Silver oxide Batteries</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE749Silveroxidebatteries.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>AMIT KUMAR PANDEY</td>

			        							<td>BASIC ELECTRICAL ENGINEERING</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>BATTERIES</td>
			        							<td>Battery Charging</td>                                              <td><span style=color:green; font-size:5px;>NO VIDEO LINK </span></td><td><a href='../view-study-material.php?SERIAL=EE601BatteryCharging.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>MOMENT AND COUPLE</td>
			        							<td>PART-9</td>                                              <td><a href='https://www.youtube.com/watch?v=FLEpKYc84Z4&list=PLkj0RetP6gunuFkUIdeaMrCW-SO22lJ7L&index=19' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP87UNIT-3PART-9.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>MOMENT AND COUPLE</td>
			        							<td>PART-10</td>                                              <td><a href='https://www.youtube.com/watch?v=O1x6cQCKStw&list=PLkj0RetP6gunuFkUIdeaMrCW-SO22lJ7L&index=20' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP131UNIT-3PART-10.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>MOMENT AND COUPLE</td>
			        							<td>PART-11</td>                                              <td><a href='https://www.youtube.com/watch?v=ut9JV2nApm4&list=PLkj0RetP6gunuFkUIdeaMrCW-SO22lJ7L&index=21' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP162UNIT-3PART-11.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>APPLIED PSYCHROMETRY</td>
			        							<td>PART-4</td>                                              <td><a href='https://www.youtube.com/watch?v=bs323_bexGs&list=PLkj0RetP6gukvHEU5URp0tAL03VyIGBRf&index=16' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>APPLIED PSYCHROMETRY</td>
			        							<td>PART-5</td>                                              <td><a href='https://www.youtube.com/watch?v=TC8bVJf-55M&list=PLkj0RetP6gukvHEU5URp0tAL03VyIGBRf&index=17' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>APPLIED PSYCHROMETRY</td>
			        							<td>PART-6</td>                                              <td><a href='youtube.com/watch?v=2NI_IbSlzhI&list=PLkj0RetP6gukvHEU5URp0tAL03VyIGBRf&index=18' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>COMPUTER AIDED DESIGN AND MANUFACTURING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>COMPUTER AIDED MANUFACTURING</td>
			        							<td>PART-1</td>                                              <td><a href='https://www.youtube.com/watch?v=xB7eBJJq46U&list=PLkj0RetP6gukVKra75TtWymiOJqzkf7se&index=10' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>COMPUTER AIDED DESIGN AND MANUFACTURING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>COMPUTER AIDED MANUFACTURING</td>
			        							<td>PART-2</td>                                              <td><a href='https://www.youtube.com/watch?v=UrlV4zmuPi4&list=PLkj0RetP6gukVKra75TtWymiOJqzkf7se&index=11' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>DEEP SHIKHA</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Electrostatic </td>
			        							<td>Charge distribution </td>                                              <td><a href='https://youtu.be/ZUlgOxl3IJU' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>JOGENDRA KUMAR</td>

			        							<td>APPLIED MATHEMATICS II</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>Straight line</td>
			        							<td>About line</td>                                              <td><a href='https://youtu.be/6PGMCT3HbnM' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>JOGENDRA KUMAR</td>

			        							<td>APPLIED MATHEMATICS II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Straight line</td>
			        							<td>About line</td>                                              <td><a href='https://youtu.be/6PGMCT3HbnM' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>JOGENDRA KUMAR</td>

			        							<td>Applied  Mathematics - II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Straight line</td>
			        							<td>About line</td>                                              <td><a href='https://youtu.be/6PGMCT3HbnM' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>JOGENDRA KUMAR</td>

			        							<td>APPLIED MATHEMATICS II</td>
			        							<td>Electrical Engineering</td>
			        							<td>2</td>
			        							<td>Straight line</td>
			        							<td>About line</td>                                              <td><a href='https://youtu.be/6PGMCT3HbnM' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>APPLIED PSYCHROMETRY</td>
			        							<td>PART-7</td>                                              <td><a href='https://www.youtube.com/watch?v=fo22dgojVDQ&list=PLkj0RetP6gukvHEU5URp0tAL03VyIGBRf&index=19' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>APPLIED PSYCHROMETRY</td>
			        							<td>PART-8</td>                                              <td><a href='https://www.youtube.com/watch?v=mw3LAMpH5Bc&list=PLkj0RetP6gukvHEU5URp0tAL03VyIGBRf&index=20' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>COMPUTER AIDED DESIGN AND MANUFACTURING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>COMPUTER AIDED MANUFACTURING</td>
			        							<td>PART-3</td>                                              <td><a href='https://www.youtube.com/watch?v=rJTA4eYN6Qs&list=PLkj0RetP6gukVKra75TtWymiOJqzkf7se&index=12' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>COMPUTER AIDED DESIGN AND MANUFACTURING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>COMPUTER AIDED MANUFACTURING</td>
			        							<td>PART-4</td>                                              <td><a href='https://www.youtube.com/watch?v=hnZBun63O-8&list=PLkj0RetP6gukVKra75TtWymiOJqzkf7se&index=13' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>MACHINES</td>
			        							<td>PART-1</td>                                              <td><a href='https://www.youtube.com/watch?v=hxktdnbJlnA&list=PLkj0RetP6gunuFkUIdeaMrCW-SO22lJ7L&index=22' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP943UNIT-5PART-1.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>MACHINES</td>
			        							<td>PART-2</td>                                              <td><a href='https://www.youtube.com/watch?v=EPM5F_cWy1c&list=PLkj0RetP6gunuFkUIdeaMrCW-SO22lJ7L&index=23' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP846UNIT-5PART-2.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>DEEP SHIKHA</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Mechanical Production</td>
			        							<td>2</td>
			        							<td>Electrostatic </td>
			        							<td>Application of Gauss law </td>                                              <td><a href='https://youtu.be/W7XbHuuosd0' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>DEEP SHIKHA</td>

			        							<td>APPLIED PHYSICS II</td>
			        							<td>Architecture Assistantship</td>
			        							<td>2</td>
			        							<td>Electrostatic </td>
			        							<td>Application of Gauss law </td>                                              <td><a href='https://youtu.be/W7XbHuuosd0' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>MACHINES</td>
			        							<td>PART-3</td>                                              <td><a href='https://www.youtube.com/watch?v=fUULwYmI9r4&list=PLkj0RetP6gunuFkUIdeaMrCW-SO22lJ7L&index=24' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP838UNIT-5PART-3.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>MACHINES</td>
			        							<td>PART-4</td>                                              <td><a href='https://www.youtube.com/watch?v=H7kUkXY-pYw&list=PLkj0RetP6gunuFkUIdeaMrCW-SO22lJ7L&index=25' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP505UNIT-5PART-4.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>APPLIED PSYCHROMETRY</td>
			        							<td>PART-9</td>                                              <td><a href='https://www.youtube.com/watch?v=gcO0kXb5YfQ&list=PLkj0RetP6gukvHEU5URp0tAL03VyIGBRf&index=21' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>APPLIED PSYCHROMETRY</td>
			        							<td>PART-10</td>                                              <td><a href='https://www.youtube.com/watch?v=08MMiwY-MIo&list=PLkj0RetP6gukvHEU5URp0tAL03VyIGBRf&index=22' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>COMPUTER AIDED DESIGN AND MANUFACTURING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>FLEXIBLE MANUFACTURING SYSTEM</td>
			        							<td>PART-1</td>                                              <td><a href='https://www.youtube.com/watch?v=5JnZThW7_lQ&list=PLkj0RetP6gukVKra75TtWymiOJqzkf7se&index=14' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>COMPUTER AIDED DESIGN AND MANUFACTURING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>FLEXIBLE MANUFACTURING SYSTEM</td>
			        							<td>PART-2</td>                                              <td><a href='https://www.youtube.com/watch?v=9MqN4uRsx-o&list=PLkj0RetP6gukVKra75TtWymiOJqzkf7se&index=15' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>COMPUTER AIDED DESIGN AND MANUFACTURING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>FLEXIBLE MANUFACTURING SYSTEM</td>
			        							<td>PART-3</td>                                              <td><a href='https://www.youtube.com/watch?v=OsONdwHORwQ&list=PLkj0RetP6gukVKra75TtWymiOJqzkf7se&index=16' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>LATEST DEVELOPMENT IN RAC</td>
			        							<td>PART-1</td>                                              <td><a href='https://www.youtube.com/watch?v=EhUjZF8UhcM&list=PLkj0RetP6gukvHEU5URp0tAL03VyIGBRf&index=23' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>COMPUTER AIDED DESIGN AND MANUFACTURING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>RAPID PROTOTYPING </td>
			        							<td>PART-1</td>                                              <td><a href='https://www.youtube.com/watch?v=hf9HxCNtIEI&list=PLkj0RetP6gukVKra75TtWymiOJqzkf7se&index=17' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>MACHINES</td>
			        							<td>PART-5</td>                                              <td><a href='https://www.youtube.com/watch?v=uzuos_6PGMs&list=PLkj0RetP6gunuFkUIdeaMrCW-SO22lJ7L&index=26' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP541UNIT-5PART-5.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>MACHINES</td>
			        							<td>PART-6</td>                                              <td><a href='https://www.youtube.com/watch?v=3wPJJFn5ujQ&list=PLkj0RetP6gunuFkUIdeaMrCW-SO22lJ7L&index=27' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP300UNIT-5PART-6.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>LATEST DEVELOPMENT IN RAC</td>
			        							<td>PART-2</td>                                              <td><a href='https://www.youtube.com/watch?v=8NNBhd8l0G8&list=PLkj0RetP6gukvHEU5URp0tAL03VyIGBRf&index=24' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>REFRIGERATION AND AIR CONDITIONING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>LATEST DEVELOPMENT IN RAC</td>
			        							<td>PART-3</td>                                              <td><a href='https://www.youtube.com/watch?v=7VYRVyjkp2Y&list=PLkj0RetP6gukvHEU5URp0tAL03VyIGBRf&index=25' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>COMPUTER AIDED DESIGN AND MANUFACTURING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>RAPID PROTOTYPING </td>
			        							<td>PART-2</td>                                              <td><a href='https://www.youtube.com/watch?v=3hhxcfMyVtQ&list=PLkj0RetP6gukVKra75TtWymiOJqzkf7se&index=18' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>COMPUTER AIDED DESIGN AND MANUFACTURING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>ROBOTICS</td>
			        							<td>PART-1</td>                                              <td><a href='https://www.youtube.com/watch?v=0Ly30y-7tFo&list=PLkj0RetP6gukVKra75TtWymiOJqzkf7se&index=19' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>COMPUTER AIDED DESIGN AND MANUFACTURING</td>
			        							<td>Mechanical Production</td>
			        							<td>4</td>
			        							<td>ROBOTICS</td>
			        							<td>PART-2</td>                                              <td><a href='https://www.youtube.com/watch?v=5zr3a4fz1Ow&list=PLkj0RetP6gukVKra75TtWymiOJqzkf7se&index=20' target=_blank>Watch</a></td><td><span style=color:green;>NO DOCUMENT UPLOADED</span></td>
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>MACHINES</td>
			        							<td>PART-7</td>                                              <td><a href='https://www.youtube.com/watch?v=51gBnCHQMRY&list=PLkj0RetP6gunuFkUIdeaMrCW-SO22lJ7L&index=28' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP985UNIT-5PART-7.pdf' target=_blank>View Notes</a></td> 
			        						<tr>
			        						    <td>BHANU PRATAP SINGH</td>

			        							<td>APPLIED MECHANICS</td>
			        							<td>Mechanical CAD</td>
			        							<td>2</td>
			        							<td>MACHINES</td>
			        							<td>PART-8</td>                                              <td><a href='https://www.youtube.com/watch?v=0aknoKHrAno&list=PLkj0RetP6gunuFkUIdeaMrCW-SO22lJ7L&index=29' target=_blank>Watch</a></td><td><a href='../view-study-material.php?SERIAL=MP301UNIT-5PART-8.pdf' target=_blank>View Notes</a></td>               
    
           
                  
               
               
              </tbody>
            </table>
         
        </div><!------------>
     </div>
</div>  
</div>
</div>
</div>
</div>

 <!----------------------------------->
<div class="wrapper" style="color:#ffffff;background-color:#010101; border-bottom: 3px solid #FFFFFF;" class=" animate-box fadeInUp animated">
  <footer id="footer" class="hoc clear" > 
    <!-- ################################################################################################ -->
    <div class="one_third first">
      <h6 class="title"  style="color:#FFFFFF">CONTACT US</h6>
      <ul class="nospace linklist contact">
        <li><i class="fa fa-map-marker"></i>
          <address>
          Sonauli Road, Gorakhnath,Gorakhpur, U.P - 273015
          </address>
        </li>
        <li><i class="fa fa-phone"></i> 0551 225 5551<br>
        
        <li><i class="fa fa-envelope-o"></i> mppolygorakhpur@rediffmail.com</li>
      </ul>
    </div>
    
    <div class="one_third">
      <h6 class="title"  style="color:#FFFFFF">CURRICULAR ACTIVITIES</h6>
       <ul class="nospace linklist contact">
       <li><img src="images/new_red.gif">  <a href="ncc-gallery.php"  style="color:#FFFFFF;" >NCC</a></li>
         <li> <img src="images/new_red.gif">  <a href="Cultural-Programme.php"  style="color:#FFFFFF;" >Cultural Programme</a></li>
       <li> <img src="images/new_red.gif">  <a href="Sports-Games.php"  style="color:#FFFFFF;" >Sports & Games</a></li>
       <li> <img src="images/new_red.gif">  <a href="News-Events.php"  style="color:#FFFFFF;" >News & Events</a></li>

       </ul>
    </div>
    
    <div class="one_third">
    <h6 class="title"  style="color:#FFFFFF">REACH OUT HERE</h6>
     <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3561.8977588410266!2d83.35591823938272!3d26.77952881370108!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x399144352e291fd5%3A0x325bdd828ebafd4d!2sMaharana+Pratap+Polytechnic!5e0!3m2!1sen!2sin!4v1554976095101!5m2!1sen!2sin" width="400" height="300" frameborder="0" style="border:0" allowfullscreen></iframe>
    </div>
    <!-- ################################################################################################ -->
  </footer>
</div>

<!-- ################################################################################################ -->
<div class="wrapper" style="background-color:#1a1a1a; color:#FFFFFF;">
  <div id="copyright" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <p class="fl_left">Copyright &copy; 2020 - All Rights Reserved - <a href="https://mppolytechnic.ac.in"  style="color:#FFFFFF;">MP Polytechnic - Gorakhpur(U.P).</a></p>
    <!--<p class="fl_right">Designed by <a target="_blank" href="https://www.techsrijan.com/"  style="color:#FFFFFF;"style="color:#FFFFFF;" title="Techsrijan Consultancy Services Pvt Ltd">Techsrijan Consultacy Services Pvt Ltd.</a></p>-->
    <!-- ################################################################################################ -->
  </div>
</div>
<!-- ################################################################################################ -->

<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS-->

<!-- <script src="js/validate.js"> </script>

<script src="layout/scripts/jquery.backtotop.js"></script>
<script src="layout/scripts/jquery.mobilemenu.js"></script>
<script src="layout/scripts/jquery.flexslider-min.js"></script> -->
<script src="js/bootstrap.min.js"> </script>
</body>
</html>