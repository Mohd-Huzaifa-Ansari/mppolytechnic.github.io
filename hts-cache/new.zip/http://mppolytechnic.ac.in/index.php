<!DOCTYPE html>
<html lang="en">
<head>
<title>MAHARANA PRATAP POLYTECHNIC - GORAKHPUR U.P. INDIA</title>
<link rel="shortcut icon" href="images/favicon.ico">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="author" content="www.mppolytechnic.ac.in">

<meta name="description" content=" Maharana Pratap Polytechnic Gorakhpur (UP) India is Aided Polytechnic Affiliated to Board of Technical education Uttar Pradesh and approved By AICTE which provides Diploma in Engineering in Mechanical,Civil,Electrical,Computer Science, Electronics and Architectural Assitantship  established in 1956." data-react-helmet="true" />

<meta name="keywords" content="mppolytechnic,mppolytechnic gorakhpur,Maharana Pratap Polytechnic Gorakhpur (UP),Aided Polytechnic in Uttar Pradesh, Diploma in computer Science|Electronics Engineering | Electrical enginnering | Mechanical engineering | Civil engineering, Board of Technical Education, Polytechnic in Gorakhpur,List of Polytechnic in Uttar Pradesh " data-react-helmet="true" />

<meta name="geo.region" content="IN-UP" />
<meta name="geo.placename" content="MP Polytechnic GORAKHPUR" />
<meta name="geo.position" content="22.351115;78.667743" />
<meta name="ICBM" content="22.351115, 78.667743" />



<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" media="all">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
<link href="css/animate.min.css" rel="stylesheet" type="text/css" media="all">
<link href="https://fonts.googleapis.com/css?family=Work+Sans" rel="stylesheet">

<!--<script src="js/sb-admin-datatables.min.js"></script>-->
<style>
#mainav a{
text-decoration:none;
}
*{
font-family: 'Work Sans', sans-serif;
margin:0px;
padding:0px;
}
#phone{
font-size:16px;
}
@media (max-width: 991px){
#gov {
display:none;
 
	}
	}
</style>
<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.HORIZONTAL}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>


<script type="text/javascript">
    $(window).on('load',function(){
        $('#myModal').modal('show');
    });
</script>
</head>
<body id="top">

<div class="wrapper row0">
  <div id="topbar" class="hoc clear"> 
   
    <div class="fl_left">
      <ul class="nospace inline pushright">
   <li><i class="fa fa-envelope-o" style="color:#FFFF33;font-size:20px;"></i> <span style="font-size:20px;">mppolygorakhpur@rediffmail.com</span></li>
       <!--<li><i class="fa fa-phone" style="color:#3a9fe5;font-size:20px;"></i> <span style="font-size:20px;">+91 888 766 7635</span></li>
       <li><strong>A GOVERNMENT POLYTECHNIC (U.P) INDIA</strong></li>-->
               <li> <div id="google_translate_element"></div></li>

         
      </ul>
    </div>
    <div class="fl_right">
      <ul class="faico clear">
        <li><i class="fa fa-phone" style="color:#FFFF33;font-size:20px;"></i> <span style="font-size:20px;">0551 2255551</span></li>
         <li><a href="https://www.facebook.com/mppolygkp" target="_blank" style="color:#3b5998;font-size:25px;"><i class="fa fa-facebook"></i></a></li>
    </ul>
    </div>
    
  </div>
</div>
<!-- ################################################################################################ -->

<div class="wrapper row1">
  <header id="header"> 
 
    <div  class="row" id="logo" >
    <div class="col-lg-8 col-12">
      <a href="index.php"><img src="images/new-mpp.png" class="img-fluid"></a>
    </div>
    
    <div class="col-lg-4 col-12" id="gov">
    
      <a href="#" target="_blank"><img src="images/logo/mahant-circle.png" class="img-fluid"></a>


         </div>
         
    <!--<div class="col-lg-2 col-6" >
          <a href="https://swachhbharatmission.gov.in" target="_blank" ><img src="images/logo/swach-bharat-logo.png" class="img-fluid"></a>    </div>-->
   
 </div>
 
   
  </header>
</div>
<!-- ################################################################################################ -->


<!--<div class="wrapper row2" style="font-size:12px;">-->
<nav class="navbar  navbar-expand-lg  sticky-top row2" >
   <a class="navbar-brand" href="index.php" style="color:#FFFFFF;"><i class="fa fa-institution"></i> </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"><i class="fa fa-navicon"></i></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav" style="color:#FFFFFF;"> 
    <ul class="navbar-nav">
    <li class="nav-item active">
      <a class="nav-item nav-link active" href="index.php" style="color:#FFFFFF;">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="about-us.php" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          About Us
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="about-us.php">About Institute</a>
          <a class="dropdown-item" href="mission-vision.php">Mission &#038; Vision</a>
          <a class="dropdown-item" href="principal-msg.php">Principal’s Message</a>
          <a class="dropdown-item" href="#">Rules and Regulations</a>
          <a class="dropdown-item" href="#">Infrastructure</a>
          
        </div>
      </li>
            <li class="nav-item dropdown">
                  <!--     <a class="nav-item nav-link active" href="commitee.php" style="color:#FFFFFF;">Governance</span></a>-->
  <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Governance
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="chairman.php">List of Chairman</a>
          <a class="dropdown-item" href="List-of-principal.php">List of Principal</a>
          <a class="dropdown-item" href="commitee.php">List of Committee</a>
       </div>
   <!--  <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Governance
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="principal-msg.php">Principal</a>
          <a class="dropdown-item" href="commitee.php">Academic Committee</a>
          <a class="dropdown-item" href="finance-commitee.php">Finance Committee</a>
          <a class="dropdown-item" href="aicte-commitee.php">AICTE Committee</a>
          <a class="dropdown-item" href="scholarship-commitee.php">Scholarship Committee</a>
          <a class="dropdown-item" href="sport-commitee.php">Sports Committee</a>
          <a class="dropdown-item" href="proctorial-commitee.php">Proctorial Committee</a>
          <a class="dropdown-item" href="security-commitee.php">Security &amp; Gardening Committee</a>
          <a class="dropdown-item" href="tnp-commitee.php">Training &#038; Placement Committee</a>
       </div>-->
      </li>
        <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          AICTE
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            


     <a href="attachment/EOA_AICTE/EOA_Report_2019-20.PDF" target="_blank" class="dropdown-item">EOA Letter</a>

           <a class="dropdown-item" href="#"></a>
       </div>
      </li>
      <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Academics
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="academic-programmes.php">Academic Programmes</a>
          
          <a class="dropdown-item" href="syllabus.php">Syllabus</a>
           <a class="dropdown-item" href="online-study-material.php">Study Material</a>
          <a class="dropdown-item" href="admission.php">Admissions</a>
          <a class="dropdown-item" href="fee-structure.php">Fees Structure</a>
           


        </div>
      </li>
     

      <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Departments
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
        <a class="dropdown-item" href="civil-department.php">Civil Engineering</a>
         <a class="dropdown-item" href="electrical-department.php">Electrical Engineering</a>
          <a class="dropdown-item" href="mechanical-department.php">Mechanical (Production)</a>
           <a class="dropdown-item" href="mechanical-cad-department.php">Mechanical (CAD)</a>
         <a class="dropdown-item" href="computer-science-department.php">Computer Science &amp; Engineering</a>
           <a class="dropdown-item" href="electronics-department.php">Electronics Engineering</a>
             <a class="dropdown-item" href="architecture-department.php">Architectural Assistantship</a>
          
                    <a class="dropdown-item" href="marketing-sales-management.php">Marketing &amp; Sales Management</a>

      
          
        </div>
      </li>
    
      <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Training &#038; Placement
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
        <a class="dropdown-item" href="#">Training Statistics</a>
          <a class="dropdown-item" href="#">Placement Statistics</a>
          <a class="dropdown-item" href="single-student-placement.php">Placed Students Details</a>
          <a class="dropdown-item" href="#">Recruiting Partners</a>
         
        </div>
      </li>
     
      <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Facilities &#038; Resources
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="hostel.php">Hostels</a>
          <a class="dropdown-item" href="library.php">Central Library</a>
          <a class="dropdown-item" href="sport.php">Sport &#038; Atheletics</a>
          <a class="dropdown-item" href="seminar.php">Auditorium &#038; Seminar Halls</a>
           <a class="dropdown-item" href="power.php">24*7 Power Supply</a>
          
        </div>
      </li>
    
     <!-- <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Alumni
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="alumni.php">Alumni Registration</a>
       </div>
      </li>
      <li class="nav-item active">
      <a class="nav-item nav-link" href="alumni.php" style="color:#FFFFFF;">Alumni</span></a>
      </li>-->
      
      <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="contact-us.php" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Contact us
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="contact-us.php">Address</a>
          <a class="dropdown-item" href="map-location.php">Maps &#038; Location</a>
          <a class="dropdown-item" href="phone-directory.php">Phone Directory</a>
          <a class="dropdown-item" href="feedback.php" role="tab" aria-controls="settings">Feedback / Query</a>
       </div>
      </li>
   </ul>
    </div>
  </div>
</nav>
<!--</div>-->
    <!-- ################################################################################################ -->
    <div>
    
    


    
    </div>
    <!-- ################################################################################################ -->

<style>
.btn{
padding:2px;
}

div.polaroid {
  width: 100%;
  background-color: white;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  margin-bottom: 25px;
  margin-top: 25px;
}

div.container {
  text-align: center;
  padding: 10px 20px;
}

	
	* {
  box-sizing: border-box;
}

body {
  font-family: Arial, Helvetica, sans-serif;
}

/* Float four columns side by side */
.column {
  float: left;
  width: 25%;
  padding: 0 10px;
}

/* Remove extra left and right margins, due to padding in columns */
.row {margin: 0 -5px;}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Style the counter cards */
.card {
padding: 6px;
  text-align: center;
  border-radius: 40px;
box-shadow: 3px 3px 3px 2px rgba(0,0,0,0.25), -3px -3px 3px 3px rgba(0,0,0,0.22);
  cursor: pointer;
  transition: 0.4s;
}
#small-card .card:hover {
  transform: scale(0.9, 0.9);
  box-shadow: 3px 3px 3px 2px rgba(0,0,0,0.25), 
    -3px -3px 3px 3px rgba(0,0,0,0.22);
}
.card a{
text-decoration:none;
}
/* Responsive columns - one column layout (vertical) on small screens */
@media screen and (max-width: 600px) {
  .card {
   padding: 2px;
   margin-bottom:10px;
}
}


</style>




    <!-- ################################################################################################ -->

    <div class="flexslider basicslider">

      <ul class="slides">

       

         <li>

          <article >

          

            <a href="#"><img src="images/slider/slide1.jpg" alt=""></a>

          </article>

        </li>

        <li>

          <article >

          

            <a href="#"><img src="images/slider/slide2.jpg" alt=""></a>

          </article>

        </li>
<li>

          <article >

          

            <a href="#"><img src="images/slider/slide3.jpg" alt=""></a>

          </article>

        </li>
<li>

          <article >

          

            <a href="#"><img src="images/slider/slide4.jpg" alt=""></a>

          </article>

        </li>
<li>

          <article >

          

            <a href="#"><img src="images/slider/slide5.jpg" alt=""></a>

          </article>

        </li>
<li>

          <article >

          

            <a href="#"><img src="images/slider/slide6.jpg" alt=""></a>

          </article>

        </li>

       
          

      </ul>

    </div>

    <!-- ################################################################################################ -->


<!-- ################################################################################################ -->

<!-- ################################################################################################ -->

<!-- ################################################################################################ --><!---MENUS----------->
<div class="container-fluid" style="background-color:#FFFFFF; margin-top:50px" >
<div class="row" id="small-card">
  <div class="col-lg-2 col-md-3  col-sm-4 col-xs-4 col-6">
    <div class="card">
    


 <a href="online-study-material.php" class="#"><i class="fa fa-book" style="font-size:24px;"></i><br>Study <br>Material</a>
  
    
    
    </div>
  </div>
 

 
 

  <div class="col-lg-2 col-md-3  col-sm-4 col-xs-4 col-6">
    <div class="card"> <a href="fee-structure.php" class="#"><i class="fa fa-rupee" style="font-size:24px;"></i><br>FEE <br>STRUCTURE</a></div>
  </div>
 

  <div class="col-lg-2 col-md-3  col-sm-4 col-xs-4 col-6">
    <div class="card">
    <a href="grievance-submission.php" class="#"><i class="fa fa-gavel" style="font-size:24px;"></i> <br>GRIEVANCE <br>SUBMISSION </a>
    </div>
  </div>
 
 <div class="col-lg-2 col-md-3  col-sm-4 col-xs-4 col-6">
    <div class="card"> <a href="#" class="#"><i class="fa fa-ban" style="font-size:24px;"></i><br>ANTI RAGGING <br>MESSURES</a></div>
  </div>
  
  
  <div class="col-lg-2 col-md-3  col-sm-4 col-xs-4 col-6">
    <div class="card"> <a href="mp-student/login.php" class="#" target="_blank"><i class="fa fa-child" style="font-size:24px;"></i><br>STUDENT <br>LOGIN</a></div>
  </div>
 

 
  <div class="col-lg-2 col-md-3  col-sm-4 col-xs-4 col-6">
    <div class="card"> <a href="faculties.php" class="#"><i class="fa fa-users" style="font-size:24px;"></i><br>STAFF <br>LOGIN</a></div>
  </div>
 
 
 
 
</div>
</div>


<!------------------------------------------>
<div class="container-fluid" style="background-color:#FFFFFF; margin-top:50px" >
<div class="row">
<div class="col-lg-8 col-md-12  col-sm-12 col-xs-12 col-12">
<div class="card">
  <h5 class="card-header" style="color:#af0202;"><strong><center>WELCOME TO MAHARANA PRATAP POLYTECHNIC, GORAKHPUR</center></strong></h5>
  <div class="card-body">
<p>After independence many schemes were started for the development of the country. In which the requirement of technicians was paramount, whose fulfillment was possible only through technical institutions. But at that time, there was acute shortage of technical institutions in the country. In such a situation, the establishment of some new technical institution was under the consideration of government. Keeping in view these requirements, the ultimate visionary, Purvanchal vikas parish Brahmalin Mahant Digvijay Nath Ji Maharaj established Maharana Pratap Shiksha Prishad, whose purpose was to remove the backwardness of the eastern region and to educate the people. On 15-07-1956, the proposal was passed to start overseer classes in Maharana Pratap Engineering Institute. The contribution of late Dr. Hari Prasad shahi in shaping of this auspicious idea of Mahant Ji has been unforgottable. The Dr. Shahi completed the admission procedure of first year of Maharana Pratap Engineering Institute in 1956-57 and gave admission to 230 students in civil Engineering. At that time, the school was at initial stage and it had not its own bulding Due to this school was started in Prachary Bhavan of Maharana Pratap Degree College.Immediately after the establishment of the school, Pujya Mahant Ji was worried about the building for which land was required. With the strong efforts of Mahant Ji, a widow named late Smt. Bansraji Kunwari from a prominent Kayasth family of the town donated her 1.44 Acre Nazul land the civil lines for the construction of building. 
<br>
<center> <a href="about-us.php" class="btn">Read More</a> </center></p>
  </div>
</div>
</div>
<div class="col-lg-4 col-md-12  col-sm-12 col-xs-12 col-12" >
<div class="card"  style="min-height:455px;max-height:455px;" >
  <h5 class="card-header" style="color:#af0202"><strong><center> <i class="fa fa-bullhorn" style="font-size:36px;color:red"></i> NOTICE BOARD</center></strong></h5>
  <div class="card-body" style="overflow:hidden;">
 <!-- <marquee  onMouseOver="this.scrollAmount=0" onMouseOut="this.scrollAmount=2" scrollamount="2" direction="up" loop="true" width="100%">
 <marquee  behavior="scroll" direction="up" onmouseover="this.stop();" onmouseout="this.start();"  scrollamount="4"loop="true">-->
     
      <marquee  behavior="scroll" direction="down" onmouseover="this.stop();" onmouseout="this.start();"  scrollamount="2">
<center>

 

<p><img src="images/new_red.gif">
Very important notice for updating student semester details by students.<br><a href="attachment/NOTICE BOARD/CamScanner 09-02-2020 16.02.40.pdf" class="btn btn-sm" target="_blank">View More</a>
 </p>  
 <p><img src="images/new_red.gif">
Updated online sessional exam schedule<br><a href="attachment/NOTICE BOARD/CamScanner 09-03-2020 18.21.30.pdf" class="btn btn-sm" target="_blank">View More</a>
 </p>  
 <p><img src="images/new_red.gif">
Important instructions during online examination.<br><a href="attachment/NOTICE BOARD/IMG_20200903_214802.jpg" class="btn btn-sm" target="_blank">View More</a>
 </p>  
 <p><img src="images/new_red.gif">
App. Physics Test of M.CAD 1st yr. will be conducted on 05 Sept. 2020. Time 5.20pm-5.40pm.<br><p><img src="images/new_red.gif">
Sub-Constitution & Materials-A Branch-1stAA Time-05 Dept 2020. 5.20pm to 5.40pm.<br>


</center>
</marquee>
  </div>
</div>
</div>





</div>
</div>




<div class="container-fluid" style="background-color:#FFFFFF; margin-top:50px;" >
<h1><center><strong>OUR DEPARTMENT</strong></center></h1>
<div class="row" id="small-card">

<div class="col-lg-3">

<div class="card"> <a href="mechanical-department.php"><i class="fa fa-wrench" style="font-size:24px;"></i><br>MECHANICAL PRODUCTION</a></div>
</div>
<div class="col-lg-3">

<div class="card"> <a href="mechanical-cad-department.php"><i class="fa fa-gear" style="font-size:24px;"></i><br>MECHANICAL CAD</a></div>
</div>

<div class="col-lg-3">
<div class="card"> <a href="electrical-department.php" ><i class="fa fa-bolt" style="font-size:24px;"></i><br>ELECTRICAL ENGINEERING</a></div>

</div>
  
<div class="col-lg-3">
<div class="card"> <a href="civil-department.php" ><i class="fa fa-map" style="font-size:24px;"></i><br>CIVIL ENGINEERING</a></div>

</div>
</div>
<div class="row" id="small-card" style="margin-top:20px;">

<div class="col-lg-3">

<div class="card"> <a href="architecture-department.php" ><i class="fa fa-building" style="font-size:24px;"></i><br>ARCHITECTURAL ASSISTANTSHIP</a></div>

</div>
<div class="col-lg-3">
<div class="card"> <a href="electronics-department.php" ><i class="fa fa-tv" style="font-size:24px;"></i><br>ELECTRONICS ENGINEERING</a></div>

</div>
  
<div class="col-lg-3">
<div class="card"> <a href="computer-science-department.php" ><i class="fa fa-desktop" style="font-size:24px;"></i><br>COMPUTER SCIENCE AND ENGINEERING</a></div>

</div>
<div class="col-lg-3">
<div class="card"> <a href="marketing-sales-management.php" ><i class="fa fa-signal" style="font-size:24px;"></i><br>MARKETING AND SALES MANAGEMENT</a></div>

</div>


</div>
</div>





<!-------------------------------------->
<div class="container-fluid" style="background-color:#FFFFFF; margin-top:50px;" >
<h1><center><strong>OUR GALLERY</strong></center></h1>
<div class="row" >

<div class="col-lg-3">
 

 
	
	
<div class="polaroid" id="pic-show">					<a href="Cultural-Programme.php"><img class="img-fluid"  src="gallery/CULTURAL CONVOCATION/DSC_3626.JPG"  alt="Post" /></a>
							
						<div class="container">
  <p><strong>Deekshant Samaroh MP Polytechnic Gorakhpur-2018</strong></p>
  <a href="Cultural-Programme.php" class="btn">View more</a>
  </div>
				
			</div>		
                </div>

<!---------------------2nd cat--------------------->
<div class="col-lg-3">
 

 
	
	
<div class="polaroid" id="pic-show">					<a href="Sports-Games.php"><img class="img-fluid"  src="gallery/SPORTS/IMG_9154.jpg"  alt="Post" /></a>
							
						<div class="container">
  <p><strong>Zonal Game Maharana Pratap Polytechnic, Gorakhpur - 2019</strong></p>
   <a href="Sports-Games.php" class="btn">View more</a>
  </div>
				
			</div>		
                </div>

<!------------------------------------------------------->

<div class="col-lg-3">
 

 
	
	
<div class="polaroid" id="pic-show">					<a href="News-Events.php"><img class="img-fluid"  src="gallery/NEWS & EVENTS/11.jpeg"  alt="Post" /></a>
							
						<div class="container">
  <p><strong>Orientation Program for Newly Admitted Students 2019</strong></p>
     <a href="News-Events.php" class="btn">View more</a>

  </div>
				
			</div>		
                </div>

<!---------------------------->
<div class="col-lg-3">
 

 
	
	
<div class="polaroid" id="pic-show">					<a href="ncc-gallery.php" ><img class="img-fluid"  src="gallery/NCC/2.jpeg"  alt="Post" /></a>
							
						<div class="container">
  <p><strong>Maharana Pratap Siksha Parishad Sansthapak Samaroh 2018</strong></p>
       <a href="ncc-gallery.php"class="btn">View more</a>

  </div>
				
			</div>		
                </div>
<!--------------------------------->
</div>

</div>

<!---MENUS----------->
<div class="container-fluid" style="background-color:#FFFFFF; margin-top:50px;margin-bottom:50px;" >
<div class="row" id="small-card" >
  <div class="col-lg-2 col-md-3  col-sm-4 col-xs-4 col-6">
    <div class="card" >
     <a href="mp-library/"  target="_blank"><i class="fa fa-language" style="font-size:24px;"></i><br> LIBRARY</a>
    
    
    </div>
  </div>
  <div class="col-lg-2 col-md-3  col-sm-4 col-xs-4 col-6">
    <div class="card"> <a href="https://mppolytechnic.ac.in/webmail" target="_blank"><i class="fa fa-globe" style="font-size:24px;"></i><br>WEBMAIL</a></div>
  </div>
 

  <div class="col-lg-2 col-md-3  col-sm-4 col-xs-4 col-6">
    <div class="card">
    <a href="attachment/rti-act/rti-act.pdf" target="_blank" class="#"><i class="fa fa-street-view" style="font-size:24px;"></i> <br>RIGHT TO INFO </a>
    </div>
  </div>
 

  <div class="col-lg-2 col-md-3  col-sm-4 col-xs-4 col-6">
    <div class="card"> <a href="https://swayam.gov.in/about" target="_blank" class="#"><i class="fa fa-book" style="font-size:24px;"></i><br>SWAYAM</a></div>
  </div>
 
 
  <div class="col-lg-2 col-md-3  col-sm-4 col-xs-4 col-6">
    <div class="card"> <a href="syllabus.php" class="#"><i class="fa fa-graduation-cap" style="font-size:24px;"></i><br>SYLLABUS</a></div>
  </div>
 
 
  <div class="col-lg-2 col-md-3  col-sm-4 col-xs-4 col-6">
    <div class="card"> <a href="useful-links.php" class="#"><i class="fa fa-external-link" style="font-size:24px;"></i><br>USEFUL LINKS</a></div>
  </div>
 
 
 
 
</div>
</div>


<!------------------------------------------>

<!--  -->

<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        
        <center><h3 class="modal-title" > <span style="color:red; text-align:center; "> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Covid-19 Prevention And Control</span></h3></center>
      </div>
      <div class="modal-body">
       <p style="font-size:20px;">We wish everyone health, patience, and strength during this difficult time (covid-19). Keep social distancing and wash your hand regularly.</p>
      </div>
      <div class="modal-footer">
      <a href="http://mppolytechnic.ac.in/whoguideline.pdf" target="_blank" class="btn btn-suceess" >Read The Instruction of Unicef and WHO </a>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>



<!--  -->

<div class="wrapper" style="color:#ffffff;background-color:#010101; border-bottom: 3px solid #FFFFFF;" class=" animate-box fadeInUp animated">
  <footer id="footer" class="hoc clear" > 
    <!-- ################################################################################################ -->
    <div class="one_third first">
      <h6 class="title"  style="color:#FFFFFF">CONTACT US</h6>
      <ul class="nospace linklist contact">
        <li><i class="fa fa-map-marker"></i>
          <address>
          Sonauli Road, Gorakhnath,Gorakhpur, U.P - 273015
          </address>
        </li>
        <li><i class="fa fa-phone"></i> 0551 225 5551<br>
        
        <li><i class="fa fa-envelope-o"></i> mppolygorakhpur@rediffmail.com</li>
      </ul>
    </div>
    
    <div class="one_third">
      <h6 class="title"  style="color:#FFFFFF">CURRICULAR ACTIVITIES</h6>
       <ul class="nospace linklist contact">
       <li><img src="images/new_red.gif">  <a href="ncc-gallery.php"  style="color:#FFFFFF;" >NCC</a></li>
         <li> <img src="images/new_red.gif">  <a href="Cultural-Programme.php"  style="color:#FFFFFF;" >Cultural Programme</a></li>
       <li> <img src="images/new_red.gif">  <a href="Sports-Games.php"  style="color:#FFFFFF;" >Sports & Games</a></li>
       <li> <img src="images/new_red.gif">  <a href="News-Events.php"  style="color:#FFFFFF;" >News & Events</a></li>

       </ul>
    </div>
    
    <div class="one_third">
    <h6 class="title"  style="color:#FFFFFF">REACH OUT HERE</h6>
     <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3561.8977588410266!2d83.35591823938272!3d26.77952881370108!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x399144352e291fd5%3A0x325bdd828ebafd4d!2sMaharana+Pratap+Polytechnic!5e0!3m2!1sen!2sin!4v1554976095101!5m2!1sen!2sin" width="400" height="300" frameborder="0" style="border:0" allowfullscreen></iframe>
    </div>
    <!-- ################################################################################################ -->
  </footer>
</div>

<!-- ################################################################################################ -->
<div class="wrapper" style="background-color:#1a1a1a; color:#FFFFFF;">
  <div id="copyright" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <p class="fl_left">Copyright &copy; 2020 - All Rights Reserved - <a href="https://mppolytechnic.ac.in"  style="color:#FFFFFF;">MP Polytechnic - Gorakhpur(U.P).</a> </p>
  
    <p class="fl_right">Designed by <a target="_blank" href="https://www.techsrijan.com/"  style="color:#FFFFFF;"style="color:#FFFFFF;" title="Techsrijan Consultancy Services Pvt Ltd">Techsrijan Consultancy Services Pvt Ltd.</a></p>
    <!-- ################################################################################################ -->
  </div>
  
   <center>
<p> Visitor Counter
  

<img src=digits/4/2.gif><img src=digits/4/6.gif><img src=digits/4/7.gif><img src=digits/4/0.gif><img src=digits/4/0.gif><img src=digits/4/0.gif>
  </center>
  
  
  
  
  
  
  

</div>
<!-- ################################################################################################ -->

<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS-->

<script src="js/validate.js"> </script>
<script src="layout/scripts/jquery.min.js"></script> 
<script src="layout/scripts/jquery.backtotop.js"></script>
<script src="layout/scripts/jquery.mobilemenu.js"></script>
<script src="layout/scripts/jquery.flexslider-min.js"></script>
<script src="js/bootstrap.min.js"> </script>
</body>
</html>