  


<!DOCTYPE html>
<html lang="en">

<head>
<title>MP POLYTECHNIC - GORAKHPUR| STUDENT MANAGEMENT SYSTEM | STUDENT LOGIN</title>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link href="css/login.css" rel="stylesheet">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
</head>
<div class="wrapper fadeInDown">
  <div id="formContent">
    <!-- Tabs Titles -->

    <!-- Icon -->
    <div class="fadeIn first">
      <img src="logo/logo_colour.png" id="icon" alt="User Icon" />
      <h1 style="font-size:28px;">MP - STUDENT LOGIN</h1>
       <label class="text-danger"></label>    </div>

    <!-- Login Form -->
    <form method="post">
      <input type="text"  class="fadeIn second" name="username" placeholder="username">
      <input type="password" class="fadeIn third" name="password" placeholder="password">
      <!-- <div id="demos.css">
<input type="text" name="password" id="dob"class="fadeIn third "placeholder="Enter Your DOB" required/>
</div>-->
      <input type="submit" name="login" class="fadeIn fourth" value="Log In">
          
    </form>

    <!-- Remind Passowrd -->
    <div id="formFooter">
    
      <a class="underlineHover" href="forget-password.php">Forget Password</a><br>
      <a class="underlineHover" href="https://mppolytechnic.ac.in">Go to the Site</a>
    </div>

  </div>
</div>
   <!-------------------datepicker js-------->

  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 <!-- <link rel="stylesheet" href="/resources/demos/style.css">-->

  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
 <script>
 
 $(function() 
		{
		$( "#dob" ).datepicker({changeMonth: true,
			changeYear: true,dateFormat: 'yy-mm-dd' , minDate:-12764, maxDate: "-168M +0D"});
	
	});
</script>
<!--------------------------------------------------------------------------->
</body>
</html>