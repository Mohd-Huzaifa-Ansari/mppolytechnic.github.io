
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

   <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>
        <script src="js/sb-admin-datatables.min.js"></script>
        <!-------------------datepicker js-------->

  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 <!-- <link rel="stylesheet" href="/resources/demos/style.css">-->

  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<!--------------------------------------------------------------------------->

<title>MP POLYTECHNIC - GORAKHPUR - STUDENT PORTAL</title>
 <style>

.card:hover {
  box-shadow: 0 20px 20px rgba(0, 0, 0, 0.19), 0 6px 6px rgba(0, 0, 0, 0.23);
  
}
.card{
background:#feeeb7a8;
}

</style>
</head>

<body>

<nav class="navbar  navbar-expand-lg  navbar-dark bg-primary sticky-top">
<a href="index.php" class="navbar-brand" >MP POLYTECHNIC</a>

<button type="button"  class="navbar-toggler" data-toggle="collapse" data-target="#menubar"><span class="navbar-toggler-icon"></span></button>



<div id="menubar" class="collapse navbar-collapse">
<ul class="navbar-nav">
<li class="nav-item"><a href="index.php" class="nav-link active">Dashboard</a></li>

<li class="nav-item dropdown active"><a href="#" class="nav-link dropdown-toggle " data-toggle="dropdown">View/Update Details</a>
<div class="dropdown-menu">
     <a class="dropdown-item"  href="personal-detail.php" >View/Update Personal Details</a>
  <a class="dropdown-item"  href="educational-detail.php" >View/Update Educational Details</a>
    <a class="dropdown-item"  href="training-detail.php" >View/Update Training Details</a>

</div>
</li>
<li class="nav-item dropdown active"><a href="#" class="nav-link dropdown-toggle " data-toggle="dropdown"> Library Book Details</a>
<div class="dropdown-menu">
     <a class="dropdown-item"  href="library-search-books.php" > Search Library Book Details</a>
  <a class="dropdown-item"  href="library-books-transactions.php" >View  Library Book Transactions</a>
</div>
</li>
<!--<li class="nav-item"><a href="generate-icard.php" class="nav-link  active">Generate ID Card</a></li>-->
<li class="nav-item"><a href="change-password.php" class="nav-link  active">Change Password</a></li>
<li class="nav-item"><a href="library-pin.php" class="nav-link  active">Generate Library Pin</a></li>
<li class="nav-item"><a href="view-fee.php" class="nav-link  active">View Fee Transaction</a></li>

<br />
<b>Notice</b>:  Undefined variable: id in <b>/home/pa23o3obst4v/public_html/mp-student/header.php</b> on line <b>105</b><br />
<li class="nav-item"><a href="online-fee-payment.php" class="nav-link  active" style="border:solid 2px;">Pay Online Fee</a></li>    
</ul>

<ul  class="navbar-nav ml-auto " >

<li class="nav-item">
<a class="nav-link  active" href="logout.php">Logout</a>
</li>

</ul>
</div>
</nav>


<div>
    
    
    
    </div>


<style>
/* Style the counter cards */
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2); /* this adds the "card" effect */
  padding: 6px;
  text-align: center;
}
.card a{
text-decoration:none;
}
/* Responsive columns - one column layout (vertical) on small screens */
@media screen and (max-width: 600px) {
  .card {
   padding: 2px;
   margin-bottom:10px;
}
}

</style>

<!------------------------------------------>
<div class="container-fluid" style="background-color:#FFFFFF; margin-top:50px" >
<div class="row">

<div class="col-lg-3 col-md-12  col-sm-12 col-xs-12 col-12">
<div class="card"  style="min-height:388px;max-height:388px;" >
  <h5 class="card-header" style="color:#af0202"><strong><center> <i class="fa fa-bullhorn" style="font-size:36px;color:red"></i> NOTICE BOARD</center></strong></h5>
  <div class="card-body" style="overflow:hidden;">
 <!-- <marquee  onMouseOver="this.scrollAmount=0" onMouseOut="this.scrollAmount=2" scrollamount="2" direction="up" loop="true" width="100%">-->
 <marquee  behavior="scroll" direction="down" onmouseover="this.stop();" onmouseout="this.start();"  scrollamount="2">
<center>

 <p><img src="images/new_red.gif">
Very important notice for updating student semester details by students.<br><a href="../attachment/NOTICE BOARD/CamScanner 09-02-2020 16.02.40.pdf" class="btn" target="_blank" >View More</a>
 </p>  
 <p><img src="images/new_red.gif">
Updated online sessional exam schedule<br><a href="../attachment/NOTICE BOARD/CamScanner 09-03-2020 18.21.30.pdf" class="btn" target="_blank" >View More</a>
 </p>  
 <p><img src="images/new_red.gif">
Important instructions during online examination.<br><a href="../attachment/NOTICE BOARD/IMG_20200903_214802.jpg" class="btn" target="_blank" >View More</a>
 </p>  
 <p><img src="images/new_red.gif">
App. Physics Test of M.CAD 1st yr. will be conducted on 05 Sept. 2020. Time 5.20pm-5.40pm.<br><a href="../attachment/NOTICE BOARD/IMG_20200903_214802.jpg" class="btn" target="_blank" >View More</a>
 </p>  
 <p><img src="images/new_red.gif">
Sub-Constitution & Materials-A Branch-1stAA Time-05 Dept 2020. 5.20pm to 5.40pm.<br><a href="../attachment/NOTICE BOARD/IMG_20200903_214802.jpg" class="btn" target="_blank" >View More</a>
 </p>  
 


</center>
</marquee>
  </div>
</div>
</div>

<div class="col-lg-6 col-md-12  col-sm-12 col-xs-12 col-12">
<!---MENUS----------->
<div class="row" style="margin-top:50px">
<div class="col-lg-12 col-md-12  col-sm-12 col-xs-12 col-12" style="font-size:36px;color:#e26228;">

<br />
<b>Notice</b>:  Undefined variable: id in <b>/home/pa23o3obst4v/public_html/mp-student/index.php</b> on line <b>93</b><br />
<center><h1><strong>WELCOME : </strong></h1></center>
</div>
</div>
 <!---MENUS----------->
<div class="row" style="margin-top:50px">
 

  <div class="col-lg-4 col-md-4  col-sm-4 col-xs-4 col-12">
    <div class="card"> <a href="personal-detail.php" class="#"><i class="fa fa-user" style="font-size:24px;"></i><br/>PERSONAL DETAILS</a></div>
  </div>
 

  <div class="col-lg-4 col-md-4  col-sm-4 col-xs-4 col-12">
    <div class="card">
    <a href="educational-detail.php" class="#"><i class="fa fa-graduation-cap" style="font-size:24px;"></i> <br>EDUCATIONAL DETAILS </a>
    </div>
  </div>
  <div class="col-lg-4 col-md-4  col-sm-4 col-xs-4 col-12">
    <div class="card"> <a href="personal-educational-detail-print.php" class="#"><i class="fa fa-print" style="font-size:24px;"></i><br>PRINT DETAILS</a></div>
  </div>

 
 </div>
 <div class="row" style="margin-top:10px">
 

  <div class="col-lg-4 col-md-4  col-sm-4 col-xs-4 col-12">
    <div class="card"> <a href="library-search-books.php" class="#"><i class="fa fa-bookmark" style="font-size:24px;"></i><br>SEARCH BOOK</a></div>
  </div>
 
 

  <div class="col-lg-4 col-md-4  col-sm-4 col-xs-4 col-12">
    <div class="card">
    <a href="../grievance-submission.php" class="#" target="_blank"><i class="fa fa-gavel" style="font-size:24px;"></i> <br>GRIEVANCE </a>
    </div>
  </div>
 

  <div class="col-lg-4 col-md-4  col-sm-4 col-xs-4 col-12">
     <div class="card"> <a href="https://swayam.gov.in/about" target="_blank" class="#"><i class="fa fa-book" style="font-size:24px;"></i><br>SWAYAM</a></div>
  </div>
 </div>
 
 <div class="row" style="margin-top:10px">
 

  <div class="col-lg-6 col-md-6  col-sm-6 col-xs-6 col-12">
   <div class="card"> <a href="notes-search2.php" class="#" style="color:red;"><i class="fa fa-tv" style="font-size:24px; color:red;"></i><br>View Study Material </a></div>
  <!--  <div class="card"> <a href="#" class="#" style="color:red;"><i class="fa fa-tv" style="font-size:24px; color:red;"></i><br>PLAY QUIZ </a></div>-->
  
  </div>
  


  <div class="col-lg-6 col-md-6  col-sm-6 col-xs-6 col-12">
<div class="card"> <a href="/mp-online/SubList.php" class="#" style="color:red;"><i class="fa fa-tv" style="font-size:24px; color:red;"></i><br>PLAY QUIZ </a></div>
<!-- <div class="card"> <a href="#" class="#" style="color:red;"><i class="fa fa-tv" style="font-size:24px; color:red;"></i><br>PLAY QUIZ </a></div>-->
  
  </div>
  

 </div>



 
 
 
 
 
 
 </div>
  
<!------------------------------------------>
<div class="col-lg-3 col-md-12  col-sm-12 col-xs-12 col-12">
<div class="card"  style="min-height:388px;" >
  <h5 class="card-header" style="color:#af0202"><strong><center> <i class=" fa fa-camera" style="font-size:30px;color:red"></i>  PHOTO</center></strong></h5>
  <div class="card-body">
<center>
<br />
<b>Notice</b>:  Undefined index: usernamestd in <b>/home/pa23o3obst4v/public_html/mp-student/index.php</b> on line <b>181</b><br />
<img src="photo/" class="img-fluid img-thumbnail" height="200px" width="200px;" /><br /><br />
<strong>Student ID </strong>: <br />
<b>Notice</b>:  Undefined index: usernamestd in <b>/home/pa23o3obst4v/public_html/mp-student/index.php</b> on line <b>188</b><br />
 <br /><br />
<a href="upload-photo.php" class="btn  btn-outline-primary">Upload Photo</a>


</center>
  </div>
</div>
</div>

<!------------------------------------------>
</div>
</div>




<!------------------------------------------>
<div class="container" >
<div class="row">
 <marquee align="baseline" onmouseover="this.stop();" onmouseout="this.start();"  scrollamount="5">
  <strong>
 <img src="images/33.gif" /><a href="https://techsrijan.com"> Powered By - <span style="color:#e26228;">TechSrijan Consultancy Services Private Limited</span> </a><img src="images/33.gif" />
   </strong>
   </marquee>
</div>
</div>

</body>
</html>