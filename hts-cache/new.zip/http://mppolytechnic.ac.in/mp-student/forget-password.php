<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

   <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>
        <script src="js/sb-admin-datatables.min.js"></script>
        <!-------------------datepicker js-------->

  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 <!-- <link rel="stylesheet" href="/resources/demos/style.css">-->

  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<!--------------------------------------------------------------------------->

<title>MP POLYTECHNIC - GORAKHPUR - STUDENT PORTAL</title>
 <style>

.card:hover {
  box-shadow: 0 20px 20px rgba(0, 0, 0, 0.19), 0 6px 6px rgba(0, 0, 0, 0.23);
  
}
.card{
background:#feeeb7a8;
}

</style>
</head>

<body>

<nav class="navbar  navbar-expand-lg  navbar-dark bg-primary sticky-top">
 <a href="index.php" class="navbar-brand" >MP POLYTECHNIC</a>

<button type="button"  class="navbar-toggler" data-toggle="collapse" data-target="#menubar"><span class="navbar-toggler-icon"></span></button>

<div id="menubar" class="collapse navbar-collapse">
<ul class="navbar-nav">
<li class="nav-item"><a href="index.php" class="nav-link active">Student Login</a></li>
</div>
</ul>
</div>
</nav>







<script language="javascript">
function check()
{

   if(document.reg.newpass.value != document.reg.repass.value)
  {
    alert("New Password and Confirm Password does not match");
	
	document.reg.repass.focus();
	return false;
  }
  else{
  submitForm();
  }
   return true;
 }
  </script>
<script>
function _(id)
{ 
return document.getElementById(id);
 }
function submitForm(){
	_("mybtn").disabled = true;

	var formdata = new FormData();
	formdata.append( "stid", _("stid").value );
	formdata.append( "eid", _("eid").value );
    formdata.append( "bank", _("bank").value );
	var ajax = new XMLHttpRequest();
	ajax.open( "POST", "forget-password-db.php" );
	ajax.onreadystatechange = function() {
		if(ajax.readyState == 4 && ajax.status == 200) {
			if(ajax.responseText == "success"){
				_("statuss").innerHTML = ajax.responseText;

			} else {
				_("statuss").innerHTML = ajax.responseText;
					_("mybtn").disabled = false;
					_("my_form").reset();
			  


			}

		}
	}
	ajax.send( formdata );
}
</script>


<div class="container " style="margin-top:50px;">
<div class="col-sm-12">
<div class="card  alert alert-danger">
<div class="card-header alert alert-primary">
<center><h6>Reset Password</h6></center>
</div>
<div class="card-body">
<form name="reg"  id="my_form"  method="post" onSubmit="submitForm(); return false;" > 
 <div class="form-group row">
    <label for="name" class="col-sm-3 col-form-label">Student Id</label>
    <div class="col-sm-9">
      <input type="text" class="form-control" name="sname" id="stid"  placeholder="Student Id" required>
    </div>
  </div>
  
  <div class="form-group row">
    <label for="eid" class="col-sm-3 col-form-label">Registered Email ID</label>
    <div class="col-sm-9">
      <input type="email" class="form-control" name="email" id="eid" placeholder="Enter Registered Email Id" required>
    </div>
  </div>
  <div class="form-group row">
    <label for="bank" class="col-sm-3 col-form-label">Adhar Card Number</label>
    <div class="col-sm-9">
      <input type="text" class="form-control" name="bank" id="bank" placeholder="Enter Adhar Card Number" required >
    </div>
  </div>
  
  
  

 

   <center>
      <button type="submit" name="submit" id="mybtn" class="btn btn-outline-primary">Send Me Link to My Email</button>
      </center>
    <span id="statuss" style="color:#009900;"></span>

</form>
</div><!--second card body-->
</div><!--second card-->
</div><!--first row second card col-sm-6-->
</div><!--first row-->
</div>
</body>
</html>