<!DOCTYPE html>
<html lang="en">
<head>
<title>MAHARANA PRATAP POLYTECHNIC - GORAKHPUR U.P. INDIA</title>
<link rel="shortcut icon" href="images/favicon.ico">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="author" content="www.mppolytechnic.ac.in">

<meta name="description" content=" Maharana Pratap Polytechnic Gorakhpur (UP) India is Aided Polytechnic Affiliated to Board of Technical education Uttar Pradesh and approved By AICTE which provides Diploma in Engineering in Mechanical,Civil,Electrical,Computer Science, Electronics and Architectural Assitantship  established in 1956." data-react-helmet="true" />

<meta name="keywords" content="mppolytechnic,mppolytechnic gorakhpur,Maharana Pratap Polytechnic Gorakhpur (UP),Aided Polytechnic in Uttar Pradesh, Diploma in computer Science|Electronics Engineering | Electrical enginnering | Mechanical engineering | Civil engineering, Board of Technical Education, Polytechnic in Gorakhpur,List of Polytechnic in Uttar Pradesh " data-react-helmet="true" />

<meta name="geo.region" content="IN-UP" />
<meta name="geo.placename" content="MP Polytechnic GORAKHPUR" />
<meta name="geo.position" content="22.351115;78.667743" />
<meta name="ICBM" content="22.351115, 78.667743" />



<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" media="all">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
<link href="css/animate.min.css" rel="stylesheet" type="text/css" media="all">
<link href="https://fonts.googleapis.com/css?family=Work+Sans" rel="stylesheet">

<!--<script src="js/sb-admin-datatables.min.js"></script>-->
<style>
#mainav a{
text-decoration:none;
}
*{
font-family: 'Work Sans', sans-serif;
margin:0px;
padding:0px;
}
#phone{
font-size:16px;
}
@media (max-width: 991px){
#gov {
display:none;
 
	}
	}
</style>
<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.HORIZONTAL}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>


<script type="text/javascript">
    $(window).on('load',function(){
        $('#myModal').modal('show');
    });
</script>
</head>
<body id="top">

<div class="wrapper row0">
  <div id="topbar" class="hoc clear"> 
   
    <div class="fl_left">
      <ul class="nospace inline pushright">
   <li><i class="fa fa-envelope-o" style="color:#FFFF33;font-size:20px;"></i> <span style="font-size:20px;">mppolygorakhpur@rediffmail.com</span></li>
       <!--<li><i class="fa fa-phone" style="color:#3a9fe5;font-size:20px;"></i> <span style="font-size:20px;">+91 888 766 7635</span></li>
       <li><strong>A GOVERNMENT POLYTECHNIC (U.P) INDIA</strong></li>-->
               <li> <div id="google_translate_element"></div></li>

         
      </ul>
    </div>
    <div class="fl_right">
      <ul class="faico clear">
        <li><i class="fa fa-phone" style="color:#FFFF33;font-size:20px;"></i> <span style="font-size:20px;">0551 2255551</span></li>
         <li><a href="https://www.facebook.com/mppolygkp" target="_blank" style="color:#3b5998;font-size:25px;"><i class="fa fa-facebook"></i></a></li>
    </ul>
    </div>
    
  </div>
</div>
<!-- ################################################################################################ -->

<div class="wrapper row1">
  <header id="header"> 
 
    <div  class="row" id="logo" >
    <div class="col-lg-8 col-12">
      <a href="index.php"><img src="images/new-mpp.png" class="img-fluid"></a>
    </div>
    
    <div class="col-lg-4 col-12" id="gov">
    
      <a href="#" target="_blank"><img src="images/logo/mahant-circle.png" class="img-fluid"></a>


         </div>
         
    <!--<div class="col-lg-2 col-6" >
          <a href="https://swachhbharatmission.gov.in" target="_blank" ><img src="images/logo/swach-bharat-logo.png" class="img-fluid"></a>    </div>-->
   
 </div>
 
   
  </header>
</div>
<!-- ################################################################################################ -->


<!--<div class="wrapper row2" style="font-size:12px;">-->
<nav class="navbar  navbar-expand-lg  sticky-top row2" >
   <a class="navbar-brand" href="index.php" style="color:#FFFFFF;"><i class="fa fa-institution"></i> </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"><i class="fa fa-navicon"></i></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav" style="color:#FFFFFF;"> 
    <ul class="navbar-nav">
    <li class="nav-item active">
      <a class="nav-item nav-link active" href="index.php" style="color:#FFFFFF;">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="about-us.php" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          About Us
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="about-us.php">About Institute</a>
          <a class="dropdown-item" href="mission-vision.php">Mission &#038; Vision</a>
          <a class="dropdown-item" href="principal-msg.php">Principal’s Message</a>
          <a class="dropdown-item" href="#">Rules and Regulations</a>
          <a class="dropdown-item" href="#">Infrastructure</a>
          
        </div>
      </li>
            <li class="nav-item dropdown">
                  <!--     <a class="nav-item nav-link active" href="commitee.php" style="color:#FFFFFF;">Governance</span></a>-->
  <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Governance
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="chairman.php">List of Chairman</a>
          <a class="dropdown-item" href="List-of-principal.php">List of Principal</a>
          <a class="dropdown-item" href="commitee.php">List of Committee</a>
       </div>
   <!--  <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Governance
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="principal-msg.php">Principal</a>
          <a class="dropdown-item" href="commitee.php">Academic Committee</a>
          <a class="dropdown-item" href="finance-commitee.php">Finance Committee</a>
          <a class="dropdown-item" href="aicte-commitee.php">AICTE Committee</a>
          <a class="dropdown-item" href="scholarship-commitee.php">Scholarship Committee</a>
          <a class="dropdown-item" href="sport-commitee.php">Sports Committee</a>
          <a class="dropdown-item" href="proctorial-commitee.php">Proctorial Committee</a>
          <a class="dropdown-item" href="security-commitee.php">Security &amp; Gardening Committee</a>
          <a class="dropdown-item" href="tnp-commitee.php">Training &#038; Placement Committee</a>
       </div>-->
      </li>
        <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          AICTE
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            


     <a href="attachment/EOA_AICTE/EOA_Report_2019-20.PDF" target="_blank" class="dropdown-item">EOA Letter</a>

           <a class="dropdown-item" href="#"></a>
       </div>
      </li>
      <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Academics
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="academic-programmes.php">Academic Programmes</a>
          
          <a class="dropdown-item" href="syllabus.php">Syllabus</a>
           <a class="dropdown-item" href="online-study-material.php">Study Material</a>
          <a class="dropdown-item" href="admission.php">Admissions</a>
          <a class="dropdown-item" href="fee-structure.php">Fees Structure</a>
           


        </div>
      </li>
     

      <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Departments
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
        <a class="dropdown-item" href="civil-department.php">Civil Engineering</a>
         <a class="dropdown-item" href="electrical-department.php">Electrical Engineering</a>
          <a class="dropdown-item" href="mechanical-department.php">Mechanical (Production)</a>
           <a class="dropdown-item" href="mechanical-cad-department.php">Mechanical (CAD)</a>
         <a class="dropdown-item" href="computer-science-department.php">Computer Science &amp; Engineering</a>
           <a class="dropdown-item" href="electronics-department.php">Electronics Engineering</a>
             <a class="dropdown-item" href="architecture-department.php">Architectural Assistantship</a>
          
                    <a class="dropdown-item" href="marketing-sales-management.php">Marketing &amp; Sales Management</a>

      
          
        </div>
      </li>
    
      <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Training &#038; Placement
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
        <a class="dropdown-item" href="#">Training Statistics</a>
          <a class="dropdown-item" href="#">Placement Statistics</a>
          <a class="dropdown-item" href="single-student-placement.php">Placed Students Details</a>
          <a class="dropdown-item" href="#">Recruiting Partners</a>
         
        </div>
      </li>
     
      <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Facilities &#038; Resources
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="hostel.php">Hostels</a>
          <a class="dropdown-item" href="library.php">Central Library</a>
          <a class="dropdown-item" href="sport.php">Sport &#038; Atheletics</a>
          <a class="dropdown-item" href="seminar.php">Auditorium &#038; Seminar Halls</a>
           <a class="dropdown-item" href="power.php">24*7 Power Supply</a>
          
        </div>
      </li>
    
     <!-- <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Alumni
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="alumni.php">Alumni Registration</a>
       </div>
      </li>
      <li class="nav-item active">
      <a class="nav-item nav-link" href="alumni.php" style="color:#FFFFFF;">Alumni</span></a>
      </li>-->
      
      <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="contact-us.php" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Contact us
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="contact-us.php">Address</a>
          <a class="dropdown-item" href="map-location.php">Maps &#038; Location</a>
          <a class="dropdown-item" href="phone-directory.php">Phone Directory</a>
          <a class="dropdown-item" href="feedback.php" role="tab" aria-controls="settings">Feedback / Query</a>
       </div>
      </li>
   </ul>
    </div>
  </div>
</nav>
<!--</div>-->
    <!-- ################################################################################################ -->
    <div>
    
    


    
    </div>
    <!-- ################################################################################################ -->

<div class=" container-fluid row3" style="padding:20px;">
<div class="row">
  <div class="col-lg-3">
    <div class="list-group" id="list-tab" role="tablist">
      <a class="list-group-item list-group-item-action " id="list-home-list" data-toggle="list" href="#list-home" role="tab" aria-controls="home">About Institute</a>
      <a class="list-group-item list-group-item-action" id="list-profile-list" data-toggle="list" href="#list-profile" role="tab" aria-controls="profile">Mission &#038; Vision</a>
      <a class="list-group-item list-group-item-action active" id="list-messages-list" data-toggle="list" href="#list-messages" role="tab" aria-controls="messages">Principal&rsquo;s Message</a>
      <a class="list-group-item list-group-item-action" id="list-settings-list" data-toggle="list" href="#list-settings" role="tab" aria-controls="settings">Rules and Regulations</a>
      <a class="list-group-item list-group-item-action" id="list-1" data-toggle="list" href="#list-11" role="tab" aria-controls="settings">Institute Brochure</a>
       <a class="list-group-item list-group-item-action" id="list-2" data-toggle="list" href="#list-22" role="tab" aria-controls="settings">Infrastructure</a>
    </div>
  </div>
  <div class="col-lg-9">
  
    <div class="tab-content" id="nav-tabContent">
      <div class="tab-pane fade" id="list-home" role="tabpanel" aria-labelledby="list-home-list">
            <h1><center><strong>About-us</strong></center></h1><hr>

     <p>After independence many schemes were started for the development of the country. In which the requirement of technicians was paramount&sbquo; whose fulfillment was possible only through technical institutions. But at that time&sbquo; there was acute shortage of technical institutions in the country. In such a situation&sbquo; the establishment of some new technical institution was under the consideration of government. Keeping in view these requirements&sbquo; the ultimate visionary&sbquo; Purvanchal vikas parish Brahmalin Mahant Digvijay Nath Ji Maharaj established Maharana Pratap Shiksha Prishad&sbquo; whose purpose was to remove the backwardness of the eastern region and to educate the people. On 15-07-1956&sbquo; the proposal was passed to start overseer classes in Maharana Pratap Engineering Institute. The contribution of late Dr. Hari Prasad shahi in shaping of this auspicious idea of Mahant Ji has been unforgottable. The Dr. Shahi completed the admission procedure of first year of Maharana Pratap Engineering Institute in 1956-57 and gave admission to 230 students in civil Engineering. At that time&sbquo; the school was at initial stage and it had not its own bulding Due to this school was started in Prachary Bhavan of Maharana Pratap Degree College.
<br>
Immediately after the establishment of the school&sbquo; Pujya Mahant Ji was worried about the building for which land was required. With the strong efforts of Mahant Ji&sbquo; a widow named late Smt. Bansraji Kunwari from a prominent Kayasth family of the town donated her 1.44 Acre Nazul land the civil lines for the construction of building. Surely it was a pious contribution in development of school. The construction of school building was completed on the said land measuring 12&sbquo;000 Square feet.
<br>
First of all&sbquo; the principal was required to run the school smoothly because Dr. Shahi was the principal of Maharana Pratap Degree college and he contributed at the time of admission to cooperate mahant Ji. The search of Principal ended very soon because chief Engineer&rsquo;s Civil Personal Assistant P.A. Late Thakur Ramadhar Singh had retired after completing his service Mahant Ji invited him to work on the post of Principal of his newly constructed institute. He gladcy accepeted it. At the initial stage of institute building&sbquo; Thakur Ramadhar Singh completed decoration and infrastructure work quickly and efficiently. In the same year the school was transferred to its newly built building.
<br>		
By that time&sbquo; the government had not decided any clear policy in the field of technology. In order to make curriculum ( Syllabus) and for conducting examination of various technical institution&sbquo; a council adhoc board was established under the supervision of Roorkie University.
<br>
In the year 1956&sbquo; at the time of first admission the duration of course was only 2 years. Thus&sbquo; first batch appeared in the exam in 1958.
<br>
But shortly after the beginning of the session of 1958&sbquo; in the month of october&sbquo; the dynamic personality Principal Thakur Ramadhar Singh died and Mr. vishan swaroop working lecturer of civil Engineering was promoted Princial. But in the month of June 1959 Shri Swaroop resigned from service of the school ans went else where. There after&sbquo; Pujya Mahant ji&sbquo; invited sri Mohan lalji&sbquo; an honest and active overseer of Irrigation Department to work as principal which was gladly accepted by him since 1959&sbquo; thus Shri Mohan Lalji became the principal of institute.
<br>
During the year 1958-59 the govt formed an institute named &ldquo; State board of technical Education&rdquo; and its headquarter was established in Lucknow. The duration of course was increased from 2 to 3 years.
<br>
Meanwhile the central govt directed state govts. that all the private technical institution should be developed in terms of building&sbquo; infrastructure and staff according to the norms of Indian standard. &ldquo;All India Technical Council&rdquo; of northern region Kanpur farmed a committee&sbquo; the committee was directed for inspection of all private institutes and submit their reports to state govt. The committee recommended that there is no justification of establishing second polytechnic in Gorakhpur as one govt. Polytechnic was already working. But state govt rejected aforesaid recommendation of committee and included this institute in the development programme.
<br>
Thus&sbquo; the institute continued to develop with the inspiration of Mahant Digvijaynath Ji under efficient leadership of Late Sri Mohan lal ji. Meanwhile &ldquo; All India Technical Council&rdquo; proposed that if Maharana Pratap Siksha Parishad wants to run this institute then it should develop institute according to norms.
<br>
Otherwise if parishad is not able to bear the expenses then institute should be handed over to state Government. In this case state Government will run the institute according to fixed norms and give representation to three members its chairman will be director of technical education and name of institute will remain unchanged.
<br>
Maharana Pratap siksha Praishad considered the aforesaid proposal of the government and keeping in view the interest of the institute and employees decided to hand over management of the institute to the government. Thus. the institute came under development programme in 1962.
<br>
Under development Programme the government allocated funds for building&sbquo; laboratory&sbquo; workshop&sbquo;apparatus&sbquo; library&sbquo; furniture land development and hostel.
<br>
The name of institute was change to Maharana Pratap Polytechnic since July 1962. A Society named  &ldquo; Maharana Pratap Polytechnic Society &rdquo; was got registered for management of this polytechnic.
<br>
With inspiration of Mahant Digvijaynath Ji&sbquo; then principal Sri Mohan Lal ji passed A.M.I.E Course as the principal of institute falling under development programme was required to be degree holder. Mahant ji was not ready to give the responsibility of institute to somebody else.
<br>
Under Development Programme this institute was accorded approval for Civil&sbquo; Mechanical and Electrical Engineering courses. But during 1962-63 due to lack of infrastructure admission procedure was completed only for Civil Engineering. In 1963-64 after developing infrastructure the admission procedure was completed in all trades.
<br>
After availability of sufficient funds froms government&sbquo; 25 acre land was to be acquisition for polytechnic according to norms Sardar Surendra Singh Majithiya offered 45 acre land near engineering college @ 3200/- Per acre to Mahant ji. But sardar sahib did not register the land in favour of institute despite Mahant ji&rsquo;s request as delayed sanctioned from government.
<br>
Despite this failure efforts were made for acquisition of land else where. For this purpose&sbquo; Sri Hridya Narayan Mishra&sbquo; instructor of Institute made his important contribution and it was with his efforts that deal for acquisition of 10 acres Guava garden of sri Jageshwar Pasi was finalised. Thus land was registered in 1970 and ground floor of main building and 2/3 part of workshop was built in the year 1972. During session 1972-73 the institution was transferred from civil lines to its present place.
<br>
Here it is worth while to mention that before 1962&sbquo; Sardar Sir Surendra Singh majithiya and Mahant Avaidy nath ji Maharaj Ji gracefully worked as president and secretary of the society. Since 1962Director&sbquo; Technical Education and Principal have been working as president and secretary respectively.
<br>
With relentless efforts of then Principal Late sri Mohan Lalji part time 4 years diploma course started during 1974-75 but it was stop as government did not give permission&sbquo; Again&sbquo; during 1981-82 parttime courses permission was granted for running courses in Electrical and Mechanical course only which continued till 1986-87.
<br>
In this continuity permission for running two years course for commercial practice was granted by government during 1978-79 in addition to engineering department. Minimum education qualification required for admission in this course was intermediate. During 1981-82&sbquo; Silver jublee of institute was celebrated under leadership of Sri G.D. Srivastav&sbquo; senior lecturer&sbquo; Mechanical which continued for two days. All teachers&sbquo; employees and students participated with great enthusiasm and dedication and made this celebration successful.
<br>
Thus&sbquo; the insttute continued to develop day by day under efficient leadership of Late Sri Mohan Lal ji. Although &sbquo; lawless elements created hindrance in the way of development and tried to involve sri Mohan lal ji by unfair means but no harm was done due to his fearless nature and co- operation of his intellectual colleagues.
<br>
In the year 1985&sbquo; the cruel hands of death snatched our well determind principal at the end of his tenure. There after&sbquo; sri P.C. Agrawal&sbquo; Senior lecturer Electrical Engineering was made officiating Prinicipal Sri G.D. Srivastav was first principal of this institute who was holding post graduation degree in Engineering as also Dip. ( Pad) from western Germany. After taking over charge of principal&sbquo; he established community Development unit financed by Government of India within a month&sbquo; keeping in view the developmental work done during his tenure&sbquo; he was known as &ldquo; Vikas Purush&rdquo;. Sri srivastav finished incomplete work left by Late Mohan lal ji and with his relentless efforts he brought this developing institute in to the category of developed institute. It was the result of his efforts that the first floor of main building and remaining part of workshop was constructed with the funds&sbquo; received under district scheme. During his tenure&sbquo; the statue of Maharana Pratap was founded in premises of institute.
<br>
Since 1990&sbquo; golden era of technical Educational Institute started. From this year funds were allocated for uplifment of technical Educational institute by world Bank Project. As Sri G.D.Srivastav usd to work keeping in view cleamliness and interest of the institute&sbquo; so the &ldquo; detail project report&rdquo; of this institute was considered exemplary in the directorate. As a results of which maximum fund Rs. 2.5 crore was allocated to this institute under world bank project&sbquo; with this fund hostel having 120 beds&sbquo; laboratory&sbquo; two story building and 12 residential buildings and over head tank were constructed modernization of workshop and laboratory was also done.
<br>
A new	course &ldquo; Diploma in Mechanical computer aided Design&rdquo; was started in the year 1995 due to the relentless efforts of Sri Srivastav. Also one year &ldquo;Post Gratuate Diploma in Marketing and Sales Management&rdquo;was started according to the policy of government.
<br>
In the year 2009 three new course computer science&sbquo; Architecture Assistantship and Electronics Engineering were started in the institute under self financed scheme with inspiration of then Peethadhishwar param Pujya Mahant avaidy nath ji Maharaj and efforts of Param Pujya Yogi Aditya Nath Ji Maharaj. Apart from this&sbquo; course Mechanical&sbquo; Electrical and Civil Engineering were also started in second shift in the year 2010.
<br>
At present time an efficient administrator and teacher Major Pateshwari Singh has been working as officiating Principal and institute is progressing day by day under his leadership.

</p>
      </div>
      <div class="tab-pane fade " id="list-profile" role="tabpanel" aria-labelledby="list-profile-list">

      <h1><center><strong>Our Mission</strong></center></h1><hr>

      <p align="justify">Our mission is to create technocrats from all over India, including those from the local and rural areas, so they become enlightened individuals, improving the living standards of their families, industry and society .We will provide individual attention, quality technical education and take care of character building.  </p>
      <h1><center><strong>Our Vision</strong></center></h1><hr>
      <p>Maharana Pratap Polytechnic  wants to be a world class Engineering Institution which is committed to  impart quality education in a disciplined environment .We want to transform every student into Industry ready and by ensuring high quality technical education through dissemination of knowledge, insights and intellectual contributions.</p>
      </div>
      <div class="tab-pane fade  show active" id="list-messages" role="tabpanel" aria-labelledby="list-messages-list">
      <h1><center><strong>Principal's Message</strong></center></h1><hr>
                 <img src="images/pi.jpeg" class="img-fluid img-thumbnail float-right" style="margin-left:20px;"/>

       <p style="text-align:justify";>
    We live in 21st century which is technical era and technology has been embraced and incorporated into our daily lives. Within the constructs of civilized society, the vast rewards of technological innovations have far outweighed the negatives. <br>
We believe that students of  Maharana Pratap Polytechnic would not only excel across several dimensions, like knowledge domain, skills, communication and basic human values, but they would also combine these with priceless qualities of mind and heart. It is for this important reason that we have succeeded in maintaining our position among leading Diploma in Engineering in the country.<br>
It gives me immense pleasure to welcome you to this institute which is the one of the oldest polytechnic after Independence in  UP established  in  1956. This institute have well equipped labs, Computer Centre and library to help students in attaining highest standards in academics,  and professional skills.
       
 </p>
<br><br><p align="right"
><strong>- Major Pateshwari Singh Principal(Acting)<br>
(MAHARANA PRATAP POLYTECHNIC,GORAKHPUR)</strong>
</p>
      </div>
      <div class="tab-pane fade" id="list-settings" role="tabpanel" aria-labelledby="list-settings-list"></div>
          <div class="tab-pane fade" id="list-11" role="tabpanel" aria-labelledby="list-1"></div>
      <div class="tab-pane fade" id="list-22" role="tabpanel" aria-labelledby="list-2"></div>
    </div>
  </div>
</div>

</div>




<div class="wrapper" style="color:#ffffff;background-color:#010101; border-bottom: 3px solid #FFFFFF;" class=" animate-box fadeInUp animated">
  <footer id="footer" class="hoc clear" > 
    <!-- ################################################################################################ -->
    <div class="one_third first">
      <h6 class="title"  style="color:#FFFFFF">CONTACT US</h6>
      <ul class="nospace linklist contact">
        <li><i class="fa fa-map-marker"></i>
          <address>
          Sonauli Road, Gorakhnath,Gorakhpur, U.P - 273015
          </address>
        </li>
        <li><i class="fa fa-phone"></i> 0551 225 5551<br>
        
        <li><i class="fa fa-envelope-o"></i> mppolygorakhpur@rediffmail.com</li>
      </ul>
    </div>
    
    <div class="one_third">
      <h6 class="title"  style="color:#FFFFFF">CURRICULAR ACTIVITIES</h6>
       <ul class="nospace linklist contact">
       <li><img src="images/new_red.gif">  <a href="ncc-gallery.php"  style="color:#FFFFFF;" >NCC</a></li>
         <li> <img src="images/new_red.gif">  <a href="Cultural-Programme.php"  style="color:#FFFFFF;" >Cultural Programme</a></li>
       <li> <img src="images/new_red.gif">  <a href="Sports-Games.php"  style="color:#FFFFFF;" >Sports & Games</a></li>
       <li> <img src="images/new_red.gif">  <a href="News-Events.php"  style="color:#FFFFFF;" >News & Events</a></li>

       </ul>
    </div>
    
    <div class="one_third">
    <h6 class="title"  style="color:#FFFFFF">REACH OUT HERE</h6>
     <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3561.8977588410266!2d83.35591823938272!3d26.77952881370108!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x399144352e291fd5%3A0x325bdd828ebafd4d!2sMaharana+Pratap+Polytechnic!5e0!3m2!1sen!2sin!4v1554976095101!5m2!1sen!2sin" width="400" height="300" frameborder="0" style="border:0" allowfullscreen></iframe>
    </div>
    <!-- ################################################################################################ -->
  </footer>
</div>

<!-- ################################################################################################ -->
<div class="wrapper" style="background-color:#1a1a1a; color:#FFFFFF;">
  <div id="copyright" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <p class="fl_left">Copyright &copy; 2020 - All Rights Reserved - <a href="https://mppolytechnic.ac.in"  style="color:#FFFFFF;">MP Polytechnic - Gorakhpur(U.P).</a> </p>
  
    <p class="fl_right">Designed by <a target="_blank" href="https://www.techsrijan.com/"  style="color:#FFFFFF;"style="color:#FFFFFF;" title="Techsrijan Consultancy Services Pvt Ltd">Techsrijan Consultancy Services Pvt Ltd.</a></p>
    <!-- ################################################################################################ -->
  </div>
  
   <center>
<p> Visitor Counter
  

<img src=digits/4/2.gif><img src=digits/4/6.gif><img src=digits/4/7.gif><img src=digits/4/0.gif><img src=digits/4/0.gif><img src=digits/4/3.gif>
  </center>
  
  
  
  
  
  
  

</div>
<!-- ################################################################################################ -->

<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS-->

<script src="js/validate.js"> </script>
<script src="layout/scripts/jquery.min.js"></script> 
<script src="layout/scripts/jquery.backtotop.js"></script>
<script src="layout/scripts/jquery.mobilemenu.js"></script>
<script src="layout/scripts/jquery.flexslider-min.js"></script>
<script src="js/bootstrap.min.js"> </script>
</body>
</html>