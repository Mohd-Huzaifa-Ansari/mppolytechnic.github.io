<!DOCTYPE html>
<html lang="en">
<head>
<title>MAHARANA PRATAP POLYTECHNIC - GORAKHPUR U.P. INDIA</title>
<link rel="shortcut icon" href="images/favicon.ico">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="author" content="www.mppolytechnic.ac.in">

<meta name="description" content=" Maharana Pratap Polytechnic Gorakhpur (UP) India is Aided Polytechnic Affiliated to Board of Technical education Uttar Pradesh and approved By AICTE which provides Diploma in Engineering in Mechanical,Civil,Electrical,Computer Science, Electronics and Architectural Assitantship  established in 1956." data-react-helmet="true" />

<meta name="keywords" content="mppolytechnic,mppolytechnic gorakhpur,Maharana Pratap Polytechnic Gorakhpur (UP),Aided Polytechnic in Uttar Pradesh, Diploma in computer Science|Electronics Engineering | Electrical enginnering | Mechanical engineering | Civil engineering, Board of Technical Education, Polytechnic in Gorakhpur,List of Polytechnic in Uttar Pradesh " data-react-helmet="true" />

<meta name="geo.region" content="IN-UP" />
<meta name="geo.placename" content="MP Polytechnic GORAKHPUR" />
<meta name="geo.position" content="22.351115;78.667743" />
<meta name="ICBM" content="22.351115, 78.667743" />



<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" media="all">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
<link href="css/animate.min.css" rel="stylesheet" type="text/css" media="all">
<link href="https://fonts.googleapis.com/css?family=Work+Sans" rel="stylesheet">

<!--<script src="js/sb-admin-datatables.min.js"></script>-->
<style>
#mainav a{
text-decoration:none;
}
*{
font-family: 'Work Sans', sans-serif;
margin:0px;
padding:0px;
}
#phone{
font-size:16px;
}
@media (max-width: 991px){
#gov {
display:none;
 
	}
	}
</style>
<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.HORIZONTAL}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>


<script type="text/javascript">
    $(window).on('load',function(){
        $('#myModal').modal('show');
    });
</script>
</head>
<body id="top">

<div class="wrapper row0">
  <div id="topbar" class="hoc clear"> 
   
    <div class="fl_left">
      <ul class="nospace inline pushright">
   <li><i class="fa fa-envelope-o" style="color:#FFFF33;font-size:20px;"></i> <span style="font-size:20px;">mppolygorakhpur@rediffmail.com</span></li>
       <!--<li><i class="fa fa-phone" style="color:#3a9fe5;font-size:20px;"></i> <span style="font-size:20px;">+91 888 766 7635</span></li>
       <li><strong>A GOVERNMENT POLYTECHNIC (U.P) INDIA</strong></li>-->
               <li> <div id="google_translate_element"></div></li>

         
      </ul>
    </div>
    <div class="fl_right">
      <ul class="faico clear">
        <li><i class="fa fa-phone" style="color:#FFFF33;font-size:20px;"></i> <span style="font-size:20px;">0551 2255551</span></li>
         <li><a href="https://www.facebook.com/mppolygkp" target="_blank" style="color:#3b5998;font-size:25px;"><i class="fa fa-facebook"></i></a></li>
    </ul>
    </div>
    
  </div>
</div>
<!-- ################################################################################################ -->

<div class="wrapper row1">
  <header id="header"> 
 
    <div  class="row" id="logo" >
    <div class="col-lg-8 col-12">
      <a href="index.php"><img src="images/new-mpp.png" class="img-fluid"></a>
    </div>
    
    <div class="col-lg-4 col-12" id="gov">
    
      <a href="#" target="_blank"><img src="images/logo/mahant-circle.png" class="img-fluid"></a>


         </div>
         
    <!--<div class="col-lg-2 col-6" >
          <a href="https://swachhbharatmission.gov.in" target="_blank" ><img src="images/logo/swach-bharat-logo.png" class="img-fluid"></a>    </div>-->
   
 </div>
 
   
  </header>
</div>
<!-- ################################################################################################ -->


<!--<div class="wrapper row2" style="font-size:12px;">-->
<nav class="navbar  navbar-expand-lg  sticky-top row2" >
   <a class="navbar-brand" href="index.php" style="color:#FFFFFF;"><i class="fa fa-institution"></i> </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"><i class="fa fa-navicon"></i></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav" style="color:#FFFFFF;"> 
    <ul class="navbar-nav">
    <li class="nav-item active">
      <a class="nav-item nav-link active" href="index.php" style="color:#FFFFFF;">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="about-us.php" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          About Us
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="about-us.php">About Institute</a>
          <a class="dropdown-item" href="mission-vision.php">Mission &#038; Vision</a>
          <a class="dropdown-item" href="principal-msg.php">Principal’s Message</a>
          <a class="dropdown-item" href="#">Rules and Regulations</a>
          <a class="dropdown-item" href="#">Infrastructure</a>
          
        </div>
      </li>
            <li class="nav-item dropdown">
                  <!--     <a class="nav-item nav-link active" href="commitee.php" style="color:#FFFFFF;">Governance</span></a>-->
  <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Governance
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="chairman.php">List of Chairman</a>
          <a class="dropdown-item" href="List-of-principal.php">List of Principal</a>
          <a class="dropdown-item" href="commitee.php">List of Committee</a>
       </div>
   <!--  <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Governance
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="principal-msg.php">Principal</a>
          <a class="dropdown-item" href="commitee.php">Academic Committee</a>
          <a class="dropdown-item" href="finance-commitee.php">Finance Committee</a>
          <a class="dropdown-item" href="aicte-commitee.php">AICTE Committee</a>
          <a class="dropdown-item" href="scholarship-commitee.php">Scholarship Committee</a>
          <a class="dropdown-item" href="sport-commitee.php">Sports Committee</a>
          <a class="dropdown-item" href="proctorial-commitee.php">Proctorial Committee</a>
          <a class="dropdown-item" href="security-commitee.php">Security &amp; Gardening Committee</a>
          <a class="dropdown-item" href="tnp-commitee.php">Training &#038; Placement Committee</a>
       </div>-->
      </li>
        <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          AICTE
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            


     <a href="attachment/EOA_AICTE/EOA_Report_2019-20.PDF" target="_blank" class="dropdown-item">EOA Letter</a>

           <a class="dropdown-item" href="#"></a>
       </div>
      </li>
      <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Academics
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="academic-programmes.php">Academic Programmes</a>
          
          <a class="dropdown-item" href="syllabus.php">Syllabus</a>
           <a class="dropdown-item" href="online-study-material.php">Study Material</a>
          <a class="dropdown-item" href="admission.php">Admissions</a>
          <a class="dropdown-item" href="fee-structure.php">Fees Structure</a>
           


        </div>
      </li>
     

      <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Departments
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
        <a class="dropdown-item" href="civil-department.php">Civil Engineering</a>
         <a class="dropdown-item" href="electrical-department.php">Electrical Engineering</a>
          <a class="dropdown-item" href="mechanical-department.php">Mechanical (Production)</a>
           <a class="dropdown-item" href="mechanical-cad-department.php">Mechanical (CAD)</a>
         <a class="dropdown-item" href="computer-science-department.php">Computer Science &amp; Engineering</a>
           <a class="dropdown-item" href="electronics-department.php">Electronics Engineering</a>
             <a class="dropdown-item" href="architecture-department.php">Architectural Assistantship</a>
          
                    <a class="dropdown-item" href="marketing-sales-management.php">Marketing &amp; Sales Management</a>

      
          
        </div>
      </li>
    
      <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Training &#038; Placement
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
        <a class="dropdown-item" href="#">Training Statistics</a>
          <a class="dropdown-item" href="#">Placement Statistics</a>
          <a class="dropdown-item" href="single-student-placement.php">Placed Students Details</a>
          <a class="dropdown-item" href="#">Recruiting Partners</a>
         
        </div>
      </li>
     
      <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Facilities &#038; Resources
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="hostel.php">Hostels</a>
          <a class="dropdown-item" href="library.php">Central Library</a>
          <a class="dropdown-item" href="sport.php">Sport &#038; Atheletics</a>
          <a class="dropdown-item" href="seminar.php">Auditorium &#038; Seminar Halls</a>
           <a class="dropdown-item" href="power.php">24*7 Power Supply</a>
          
        </div>
      </li>
    
     <!-- <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Alumni
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="alumni.php">Alumni Registration</a>
       </div>
      </li>
      <li class="nav-item active">
      <a class="nav-item nav-link" href="alumni.php" style="color:#FFFFFF;">Alumni</span></a>
      </li>-->
      
      <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="contact-us.php" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Contact us
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="contact-us.php">Address</a>
          <a class="dropdown-item" href="map-location.php">Maps &#038; Location</a>
          <a class="dropdown-item" href="phone-directory.php">Phone Directory</a>
          <a class="dropdown-item" href="feedback.php" role="tab" aria-controls="settings">Feedback / Query</a>
       </div>
      </li>
   </ul>
    </div>
  </div>
</nav>
<!--</div>-->
    <!-- ################################################################################################ -->
    <div>
    
    


    
    </div>
    <!-- ################################################################################################ -->


<style>
.btn{
padding:5px;
}

div.polaroid {
  width: 100%;
  background-color: white;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  margin-bottom: 25px;
  margin-top: 25px;
}

div.container {
  text-align: center;
  padding: 10px 20px;
}
#pic-show img{
height:150px;
width:131px;
display:block;
margin-left:auto;
margin-right:auto;
}

</style>

<div class=" container-fluid row3" style="padding:20px;">
<div class="row">
  <div class="col-lg-3">
    <div class="list-group" id="list-tab" role="tablist">
      <a class="list-group-item list-group-item-action " id="list-ce-list" data-toggle="list" href="#list-ce" role="tab" aria-controls="home">Civil Engineering</a>
      <a class="list-group-item list-group-item-action" id="list-el-list" data-toggle="list" href="#list-el" role="tab" aria-controls="messages">Electrical Engineering</a>
      <a class="list-group-item list-group-item-action active" id="list-mp-list" data-toggle="list" href="#list-mp" role="tab" aria-controls="profile">Mechanical Production</a>
      <a class="list-group-item list-group-item-action" id="list-mc-list" data-toggle="list" href="#list-mc" role="tab" aria-controls="messages">Mechanical CAD</a>
      <a class="list-group-item list-group-item-action " id="list-cs-list" data-toggle="list" href="#list-cs" role="tab" aria-controls="home">Computer Science & Engineering</a>
      <a class="list-group-item list-group-item-action" id="list-ec-list" data-toggle="list" href="#list-ec" role="tab" aria-controls="profile">Electronics Engineering</a>
      <a class="list-group-item list-group-item-action " id="list-aa-list" data-toggle="list" href="#list-aa" role="tab" aria-controls="home">Architecture Assistantship</a>
      <a class="list-group-item list-group-item-action" id="list-msm-list" data-toggle="list" href="#list-msm" role="tab" aria-controls="profile">Marketing and Sales Management</a>
     
    </div>
  </div>
  <div class="col-lg-9">
  
    <div class="tab-content" id="nav-tabContent">
      <div class="tab-pane fade " id="list-ce" role="tabcard" aria-labelledby="list-ce-list">
      <div class="row">
   <div class="col-lg-12">
      <div class="card">
          <div class="card-heading" style="background-color:#af0202;color:#FFFFFF;">
       <center> <i class="fa fa-graduation-cap" style="font-size:36px; color:#ffffff;"></i><font style="font-size:30px;">  <strong>Civil Engineering</strong></font></center>
           </div><!---card heading-->
              <div class="card-body ">
                  <div class="row">
   

 
	
	<div class="col-lg-4">
<div class="polaroid" id="pic-show">					<a href="attachment/teacher-img/profile.jpg" target="_blank"><img class="img-fluid"  src="attachment/teacher-img/profile.jpg" height="100px" width="100px" alt="Post" /></a>
							
						<div class="container" style="color:#000000;">
  <p  align="justify"><strong >NAME:- R R SINGH</strong></p><hr>
    <p  align="justify"><strong>POST:- Head of Department</strong></p><hr>

  <p  align="justify"> <strong><i class="fa fa-university"></i>  Civil Engineering</strong></p><hr>

  <p  align="justify"><strong><i class="fa fa-envelope"></i>  rr.singh1163@gmail.com</strong></p><hr>
    <p  align="justify"><strong><i class="fa fa-phone"></i>  9935374423</strong></p><hr>
<!--    <a href="#" class="btn btn-primary">See Profile <i class="fa fa-external-link" ></i></a>
--><button type="button" data-toggle="modal" data-target="#delete" id="1" onclick="showdetails2(this);" class="btn btn-primary">See Profile <i class="fa fa-external-link" ></i></button>

  </div><!---container--->
	</div>		<!---polaroid-->		
			</div>		<!---col-lg-4-->	
                 
	
	<div class="col-lg-4">
<div class="polaroid" id="pic-show">					<a href="attachment/teacher-img/IMG_20180920_141047140_HDR_2.jpg" target="_blank"><img class="img-fluid"  src="attachment/teacher-img/IMG_20180920_141047140_HDR_2.jpg" height="100px" width="100px" alt="Post" /></a>
							
						<div class="container" style="color:#000000;">
  <p  align="justify"><strong >NAME:- ARJUN KUMAR AGRAWAL</strong></p><hr>
    <p  align="justify"><strong>POST:- Lecturer</strong></p><hr>

  <p  align="justify"> <strong><i class="fa fa-university"></i>  Civil Engineering</strong></p><hr>

  <p  align="justify"><strong><i class="fa fa-envelope"></i>  arjun.agarwal1964@gmail.com</strong></p><hr>
    <p  align="justify"><strong><i class="fa fa-phone"></i>  9935436083</strong></p><hr>
<!--    <a href="#" class="btn btn-primary">See Profile <i class="fa fa-external-link" ></i></a>
--><button type="button" data-toggle="modal" data-target="#delete" id="2" onclick="showdetails2(this);" class="btn btn-primary">See Profile <i class="fa fa-external-link" ></i></button>

  </div><!---container--->
	</div>		<!---polaroid-->		
			</div>		<!---col-lg-4-->	
                 
	
	<div class="col-lg-4">
<div class="polaroid" id="pic-show">					<a href="attachment/teacher-img/D.jpg" target="_blank"><img class="img-fluid"  src="attachment/teacher-img/D.jpg" height="100px" width="100px" alt="Post" /></a>
							
						<div class="container" style="color:#000000;">
  <p  align="justify"><strong >NAME:- DINESH PRATAP SINGH</strong></p><hr>
    <p  align="justify"><strong>POST:- Lecturer</strong></p><hr>

  <p  align="justify"> <strong><i class="fa fa-university"></i>  Civil Engineering</strong></p><hr>

  <p  align="justify"><strong><i class="fa fa-envelope"></i>  ddddsurendra69@gmail.com</strong></p><hr>
    <p  align="justify"><strong><i class="fa fa-phone"></i>  9415259670</strong></p><hr>
<!--    <a href="#" class="btn btn-primary">See Profile <i class="fa fa-external-link" ></i></a>
--><button type="button" data-toggle="modal" data-target="#delete" id="3" onclick="showdetails2(this);" class="btn btn-primary">See Profile <i class="fa fa-external-link" ></i></button>

  </div><!---container--->
	</div>		<!---polaroid-->		
			</div>		<!---col-lg-4-->	
                          
    </div><!---row-->
              </div><!--card-body--->
      
      </div><!---card--->
   </div><!---lg-12-->
</div><!---row--->
      </div><!---Firrst aab closed here-->
      <div class="tab-pane fade " id="list-el" role="tabcard" aria-labelledby="list-el-list">
            <div class="row">
   <div class="col-lg-12">
      <div class="card">
          <div class="card-heading" style="background-color:#af0202;color:#FFFFFF;">
       <center> <i class="fa fa-graduation-cap" style="font-size:36px; color:#ffffff;"></i><font style="font-size:30px;">  <strong>  Electrical Engineering</strong></font></center>
           </div>
              <div class="card-body ">
                 
                       <div class="row">
   

 
	
	<div class="col-lg-4">
<div class="polaroid" id="pic-show">					<a href="attachment/teacher-img/aaaaaaaa.png" target="_blank"><img class="img-fluid"  src="attachment/teacher-img/aaaaaaaa.png" height="100px" width="100px" alt="Post" /></a>
							
						<div class="container" style="color:#000000;">
  <p  align="justify"><strong >NAME:- AMIT KUMAR PANDEY</strong></p><hr>
    <p  align="justify"><strong>POST:- Lecturer(On Contract)</strong></p><hr>

  <p  align="justify"> <strong><i class="fa fa-university"></i>  Electrical Engineering</strong></p><hr>

  <p  align="justify"><strong><i class="fa fa-envelope"></i>  amitpandey14793@gmail.com</strong></p><hr>
    <p  align="justify"><strong><i class="fa fa-phone"></i>  9296125096</strong></p><hr>
<button type="button" data-toggle="modal" data-target="#delete" id="61" onclick="showdetails2(this);" class="btn btn-primary">See Profile <i class="fa fa-external-link" ></i></button>

  </div>
	</div>					
			</div>		
                          
    </div>
              </div>
      
      </div>
   </div>
</div>
      
      
      
    </div><!---second aab closed here-->
      <div class="tab-pane fade show active" id="list-mp" role="tabcard" aria-labelledby="list-mp-list">
      
      <div class="row">
   <div class="col-lg-12">
      <div class="card">
          <div class="card-heading" style="background-color:#af0202;color:#FFFFFF;">
       <center> <i class="fa fa-graduation-cap" style="font-size:36px; color:#ffffff;"></i><font style="font-size:30px;">  <strong> 	Mechanical Production</strong></font></center>
           </div>
              <div class="card-body ">
                <div class="row">
   

 
	
	<div class="col-lg-4">
<div class="polaroid" id="pic-show">					<a href="attachment/teacher-img/IMG-20200515-WA0291.jpg" target="_blank"><img class="img-fluid"  src="attachment/teacher-img/IMG-20200515-WA0291.jpg" height="100px" width="100px" alt="Post" /></a>
							
						<div class="container" style="color:#000000;">
  <p  align="justify"><strong >NAME:- BAIJ NATH VERMA</strong></p><hr>
    <p  align="justify"><strong>POST:- Head of Department</strong></p><hr>

  <p  align="justify"> <strong><i class="fa fa-university"></i>  Mechanical Production</strong></p><hr>

  <p  align="justify"><strong><i class="fa fa-envelope"></i>  vermabn10@gmail.com</strong></p><hr>
    <p  align="justify"><strong><i class="fa fa-phone"></i>  9415858624</strong></p><hr>
<button type="button" data-toggle="modal" data-target="#delete" id="77" onclick="showdetails2(this);" class="btn btn-primary">See Profile <i class="fa fa-external-link" ></i></button>

  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-4">
<div class="polaroid" id="pic-show">					<a href="attachment/teacher-img/IMG-20200321-WA0027.jpg" target="_blank"><img class="img-fluid"  src="attachment/teacher-img/IMG-20200321-WA0027.jpg" height="100px" width="100px" alt="Post" /></a>
							
						<div class="container" style="color:#000000;">
  <p  align="justify"><strong >NAME:- ABHAI PRATAP MALL</strong></p><hr>
    <p  align="justify"><strong>POST:- Lecturer</strong></p><hr>

  <p  align="justify"> <strong><i class="fa fa-university"></i>  Mechanical Production</strong></p><hr>

  <p  align="justify"><strong><i class="fa fa-envelope"></i>  abhaymall64@gmail.com</strong></p><hr>
    <p  align="justify"><strong><i class="fa fa-phone"></i>  9451187722</strong></p><hr>
<button type="button" data-toggle="modal" data-target="#delete" id="78" onclick="showdetails2(this);" class="btn btn-primary">See Profile <i class="fa fa-external-link" ></i></button>

  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-4">
<div class="polaroid" id="pic-show">					<a href="attachment/teacher-img/IMG-20190621-WA0028-217x319.jpg" target="_blank"><img class="img-fluid"  src="attachment/teacher-img/IMG-20190621-WA0028-217x319.jpg" height="100px" width="100px" alt="Post" /></a>
							
						<div class="container" style="color:#000000;">
  <p  align="justify"><strong >NAME:- VIVEKANAND YADAV</strong></p><hr>
    <p  align="justify"><strong>POST:- Lecturer(On Contract)</strong></p><hr>

  <p  align="justify"> <strong><i class="fa fa-university"></i>  Mechanical Production</strong></p><hr>

  <p  align="justify"><strong><i class="fa fa-envelope"></i>  vivekanandyadav02@gmail.com</strong></p><hr>
    <p  align="justify"><strong><i class="fa fa-phone"></i>  9616480608</strong></p><hr>
<button type="button" data-toggle="modal" data-target="#delete" id="81" onclick="showdetails2(this);" class="btn btn-primary">See Profile <i class="fa fa-external-link" ></i></button>

  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-4">
<div class="polaroid" id="pic-show">					<a href="attachment/teacher-img/DSC_0001.JPG" target="_blank"><img class="img-fluid"  src="attachment/teacher-img/DSC_0001.JPG" height="100px" width="100px" alt="Post" /></a>
							
						<div class="container" style="color:#000000;">
  <p  align="justify"><strong >NAME:- SHIVENDRA PRATAP SINGH</strong></p><hr>
    <p  align="justify"><strong>POST:- Lecturer(On Contract)</strong></p><hr>

  <p  align="justify"> <strong><i class="fa fa-university"></i>  Mechanical Production</strong></p><hr>

  <p  align="justify"><strong><i class="fa fa-envelope"></i>  29shiv88@gmail.com</strong></p><hr>
    <p  align="justify"><strong><i class="fa fa-phone"></i>  0000000000</strong></p><hr>
<button type="button" data-toggle="modal" data-target="#delete" id="99" onclick="showdetails2(this);" class="btn btn-primary">See Profile <i class="fa fa-external-link" ></i></button>

  </div>
	</div>					
			</div>		
                          
    </div>
              </div>
      
      </div>
   </div>
      </div>
      
      
      </div><!---thiirrds aab closed here-->
      
        <div class="tab-pane fade" id="list-mc" role="tabcard" aria-labelledby="list-mc-list">
      
      <div class="row">
   <div class="col-lg-12">
      <div class="card">
          <div class="card-heading" style="background-color:#af0202;color:#FFFFFF;">
       <center> <i class="fa fa-graduation-cap" style="font-size:36px; color:#ffffff;"></i><font style="font-size:30px;">  <strong> Mechanical CAD</strong></font></center>
           </div>
              <div class="card-body ">
                <div class="row">
   

 
	
	<div class="col-lg-4">
<div class="polaroid" id="pic-show">					<a href="attachment/teacher-img/mypicappy - 50kb.jpg" target="_blank"><img class="img-fluid"  src="attachment/teacher-img/mypicappy - 50kb.jpg" height="100px" width="100px" alt="Post" /></a>
							
						<div class="container" style="color:#000000;">
  <p  align="justify"><strong >NAME:- ANURAG KUMAR</strong></p><hr>
    <p  align="justify"><strong>POST:- Head of Department</strong></p><hr>

  <p  align="justify"> <strong><i class="fa fa-university"></i>  Mechanical CAD</strong></p><hr>

  <p  align="justify"><strong><i class="fa fa-envelope"></i>  kumar.accc@gmail.com</strong></p><hr>
    <p  align="justify"><strong><i class="fa fa-phone"></i>  9453813038</strong></p><hr>
<button type="button" data-toggle="modal" data-target="#delete" id="96" onclick="showdetails2(this);" class="btn btn-primary">See Profile <i class="fa fa-external-link" ></i></button>

  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-4">
<div class="polaroid" id="pic-show">					<a href="attachment/teacher-img/1588957131217_1588957274245.jpg" target="_blank"><img class="img-fluid"  src="attachment/teacher-img/1588957131217_1588957274245.jpg" height="100px" width="100px" alt="Post" /></a>
							
						<div class="container" style="color:#000000;">
  <p  align="justify"><strong >NAME:- GAURAV KUMAR KASHYAP</strong></p><hr>
    <p  align="justify"><strong>POST:- Lecturer(On Contract)</strong></p><hr>

  <p  align="justify"> <strong><i class="fa fa-university"></i>  Mechanical CAD</strong></p><hr>

  <p  align="justify"><strong><i class="fa fa-envelope"></i>  er.gkkashyap@gmail.com</strong></p><hr>
    <p  align="justify"><strong><i class="fa fa-phone"></i>  7905928854</strong></p><hr>
<button type="button" data-toggle="modal" data-target="#delete" id="97" onclick="showdetails2(this);" class="btn btn-primary">See Profile <i class="fa fa-external-link" ></i></button>

  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-4">
<div class="polaroid" id="pic-show">					<a href="attachment/teacher-img/naveen.jpg" target="_blank"><img class="img-fluid"  src="attachment/teacher-img/naveen.jpg" height="100px" width="100px" alt="Post" /></a>
							
						<div class="container" style="color:#000000;">
  <p  align="justify"><strong >NAME:- NAVEEN KUMAR RAO</strong></p><hr>
    <p  align="justify"><strong>POST:- Lecturer(On Contract)</strong></p><hr>

  <p  align="justify"> <strong><i class="fa fa-university"></i>  Mechanical CAD</strong></p><hr>

  <p  align="justify"><strong><i class="fa fa-envelope"></i>  2255naveenkr@gmail.com</strong></p><hr>
    <p  align="justify"><strong><i class="fa fa-phone"></i>  9169754113</strong></p><hr>
<button type="button" data-toggle="modal" data-target="#delete" id="98" onclick="showdetails2(this);" class="btn btn-primary">See Profile <i class="fa fa-external-link" ></i></button>

  </div>
	</div>					
			</div>		
                          
    </div>
              </div>
      
      </div>
   </div>
      </div>
      
      
      </div><!---4s aab closed here-->
        
      <div class="tab-pane fade" id="list-cs" role="tabcard" aria-labelledby="list-cs-list">
      
      <div class="row">
   <div class="col-lg-12">
      <div class="card">
          <div class="card-heading" style="background-color:#af0202;color:#FFFFFF;">
       <center> <i class="fa fa-graduation-cap" style="font-size:36px; color:#ffffff;"></i><font style="font-size:30px;">  <strong> Computer Science and Engineering</strong></font></center>
           </div>
              <div class="card-body ">
                <div class="row">
   

 
	
	<div class="col-lg-4">
<div class="polaroid" id="pic-show">					<a href="attachment/teacher-img/photo 1.jpg" target="_blank"><img class="img-fluid"  src="attachment/teacher-img/photo 1.jpg" height="100px" width="100px" alt="Post" /></a>
							
						<div class="container" style="color:#000000;">
  <p  align="justify"><strong >NAME:- RAJEEV KUMAR CHAURASIA</strong></p><hr>
    <p  align="justify"><strong>POST:- Head of Department</strong></p><hr>

  <p  align="justify"> <strong><i class="fa fa-university"></i>  Computer Science and Engineering</strong></p><hr>

  <p  align="justify"><strong><i class="fa fa-envelope"></i>  rajeev.mpp@gmail.com</strong></p><hr>
    <p  align="justify"><strong><i class="fa fa-phone"></i>  9628763000</strong></p><hr>
<button type="button" data-toggle="modal" data-target="#delete" id="20" onclick="showdetails2(this);" class="btn btn-primary">See Profile <i class="fa fa-external-link" ></i></button>

  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-4">
<div class="polaroid" id="pic-show">					<a href="attachment/teacher-img/Pravesh.JPG" target="_blank"><img class="img-fluid"  src="attachment/teacher-img/Pravesh.JPG" height="100px" width="100px" alt="Post" /></a>
							
						<div class="container" style="color:#000000;">
  <p  align="justify"><strong >NAME:- PRAVESH KUMAR CHAUHAN</strong></p><hr>
    <p  align="justify"><strong>POST:- Lecturer(On Contract)</strong></p><hr>

  <p  align="justify"> <strong><i class="fa fa-university"></i>  Computer Science and Engineering</strong></p><hr>

  <p  align="justify"><strong><i class="fa fa-envelope"></i>  pravesh.cs@gmail.com</strong></p><hr>
    <p  align="justify"><strong><i class="fa fa-phone"></i>  9889828994</strong></p><hr>
<button type="button" data-toggle="modal" data-target="#delete" id="21" onclick="showdetails2(this);" class="btn btn-primary">See Profile <i class="fa fa-external-link" ></i></button>

  </div>
	</div>					
			</div>		
                          
    </div>
              </div>
      
      </div>
   </div>
      </div>
      
      
      </div><!---5s aab closed here-->
      <div class="tab-pane fade" id="list-ec" role="tabcard" aria-labelledby="list-ec-list">
      
      <div class="row">
   <div class="col-lg-12">
      <div class="card">
          <div class="card-heading" style="background-color:#af0202;color:#FFFFFF;">
       <center> <i class="fa fa-graduation-cap" style="font-size:36px; color:#ffffff;"></i><font style="font-size:30px;">  <strong> Electronics Engineering</strong></font></center>
           </div>
              <div class="card-body ">
                <div class="row">
   

 
	
	<div class="col-lg-4">
<div class="polaroid" id="pic-show">					<a href="attachment/teacher-img/IMG-20190430-WA0006.jpg" target="_blank"><img class="img-fluid"  src="attachment/teacher-img/IMG-20190430-WA0006.jpg" height="100px" width="100px" alt="Post" /></a>
							
						<div class="container" style="color:#000000;">
  <p  align="justify"><strong >NAME:- YASHI TIWARI</strong></p><hr>
    <p  align="justify"><strong>POST:- Lecturer(On Contract)</strong></p><hr>

  <p  align="justify"> <strong><i class="fa fa-university"></i>  Electronics Engineering</strong></p><hr>

  <p  align="justify"><strong><i class="fa fa-envelope"></i>  yashi_tiwari8@yahoo.co.in</strong></p><hr>
    <p  align="justify"><strong><i class="fa fa-phone"></i>  9456908314</strong></p><hr>
<button type="button" data-toggle="modal" data-target="#delete" id="45" onclick="showdetails2(this);" class="btn btn-primary">See Profile <i class="fa fa-external-link" ></i></button>

  </div>
	</div>					
			</div>		
                          
    </div>
              </div>
      
      </div>
   </div>
      </div>
      
      
      </div><!---6s aab closed here-->
      <div class="tab-pane fade" id="list-aa" role="tabcard" aria-labelledby="list-aa-list">
      
      <div class="row">
   <div class="col-lg-12">
      <div class="card">
          <div class="card-heading" style="background-color:#af0202;color:#FFFFFF;">
       <center> <i class="fa fa-graduation-cap" style="font-size:36px; color:#ffffff;"></i><font style="font-size:30px;">  <strong> Architecture Assistantship</strong></font></center>
           </div>
              <div class="card-body ">
                <div class="row">
   

 
	
	<div class="col-lg-4">
<div class="polaroid" id="pic-show">					<a href="attachment/teacher-img/pk.jpg" target="_blank"><img class="img-fluid"  src="attachment/teacher-img/pk.jpg" height="100px" width="100px" alt="Post" /></a>
							
						<div class="container" style="color:#000000;">
  <p  align="justify"><strong >NAME:- PANKAJ CHAUHAN</strong></p><hr>
    <p  align="justify"><strong>POST:- Drawing Instructor(On Contract)</strong></p><hr>

  <p  align="justify"> <strong><i class="fa fa-university"></i>  Architecture Assistantship</strong></p><hr>

  <p  align="justify"><strong><i class="fa fa-envelope"></i>  pkchauhan668@gmail.com</strong></p><hr>
    <p  align="justify"><strong><i class="fa fa-phone"></i>  9450252134</strong></p><hr>
<button type="button" data-toggle="modal" data-target="#delete" id="118" onclick="showdetails2(this);" class="btn btn-primary">See Profile <i class="fa fa-external-link" ></i></button>

  </div>
	</div>					
			</div>		
                          
    </div>
              </div>
      
      </div>
   </div>
      </div>
      
      
      </div><!---7s aab closed here-->
      <div class="tab-pane fade" id="list-msm" role="tabcard" aria-labelledby="list-msm-list">
      
      <div class="row">
   <div class="col-lg-12">
      <div class="card">
          <div class="card-heading" style="background-color:#af0202;color:#FFFFFF;">
       <center> <i class="fa fa-graduation-cap" style="font-size:36px; color:#ffffff;"></i><font style="font-size:30px;">  <strong> Marketing and Sales Management.</strong></font></center>
           </div>
              <div class="card-body ">
                <div class="row">
   

          
    </div>
              </div>
      
      </div>
   </div>
      </div>
      
      
      </div><!---8s aab closed here-->
  </div>
</div>

</div>
</div>

             <!--- DELETE MODAL--->
  
    <div class="modal fade" id="delete" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel"><center> <i class="fa fa-graduation-cap" style="font-size:36px;"></i><font style="font-size:30px;">  <strong> Teacher's detail</strong></font></center></h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div  class="modal-body">
          <!---->
          <div class="polaroid" >
          <div class="container" style="color:#000000;">        
 <h1><strong > NAME:- <span  align="justify" id="name"> </span></strong><hr>
   <strong> POST:- <span  align="justify" id="post"> </span></strong><hr>

 <strong>DEPARTMENT:- <span  align="justify" id="dept">   </span></strong><hr>

<strong>QUALIFICATION:- <span  align="justify" id="qualification"></span> </strong><hr>
  <strong>TEACHING/WORKING EXPERIENCE:-  <span  align="justify" id="expe"></span> YEARS </strong><hr>
   
 <strong><i class="fa fa-envelope"></i> <span  align="justify" id="email"> </span></strong><hr>
  <strong><i class="fa fa-phone"></i>  <span  align="justify" id="mobile"></span> </strong></h1><hr>

  </div>
          </div>
          
          <div class="modal-footer">
         <button class="btn btn-secondary" type="button" data-dismiss="modal">Close</button>
          </div>
          
          
          <!------>
          </div>
        </div>
      </div>
    </div>
    <!------------------------->
  <script>
function showdetails2(button)    {
  var id = button.id;
$.ajax({
  url:"faculties-detail.php",
  method:"GET",
  data:{"id":id},
  success: function(response){
 //console.log(response);
   

 var ob = JSON.parse(response);

 $("#serial").text(ob.id);
 $("#pic").text(ob.pic);
 $("#name").text(ob.name);
 $("#dept").text(ob.dept);
 $("#post").text(ob.post);
 $("#qualification").text(ob.qualification);
 $("#expe").text(ob.exp);
 $("#email").text(ob.email);
 $("#mobile").text(ob.mobile);
  
  }
  });

 }
</script>
 <!----------------------------------->

<div class="wrapper" style="color:#ffffff;background-color:#010101; border-bottom: 3px solid #FFFFFF;" class=" animate-box fadeInUp animated">
  <footer id="footer" class="hoc clear" > 
    <!-- ################################################################################################ -->
    <div class="one_third first">
      <h6 class="title"  style="color:#FFFFFF">CONTACT US</h6>
      <ul class="nospace linklist contact">
        <li><i class="fa fa-map-marker"></i>
          <address>
          Sonauli Road, Gorakhnath,Gorakhpur, U.P - 273015
          </address>
        </li>
        <li><i class="fa fa-phone"></i> 0551 225 5551<br>
        
        <li><i class="fa fa-envelope-o"></i> mppolygorakhpur@rediffmail.com</li>
      </ul>
    </div>
    
    <div class="one_third">
      <h6 class="title"  style="color:#FFFFFF">CURRICULAR ACTIVITIES</h6>
       <ul class="nospace linklist contact">
       <li><img src="images/new_red.gif">  <a href="ncc-gallery.php"  style="color:#FFFFFF;" >NCC</a></li>
         <li> <img src="images/new_red.gif">  <a href="Cultural-Programme.php"  style="color:#FFFFFF;" >Cultural Programme</a></li>
       <li> <img src="images/new_red.gif">  <a href="Sports-Games.php"  style="color:#FFFFFF;" >Sports & Games</a></li>
       <li> <img src="images/new_red.gif">  <a href="News-Events.php"  style="color:#FFFFFF;" >News & Events</a></li>

       </ul>
    </div>
    
    <div class="one_third">
    <h6 class="title"  style="color:#FFFFFF">REACH OUT HERE</h6>
     <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3561.8977588410266!2d83.35591823938272!3d26.77952881370108!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x399144352e291fd5%3A0x325bdd828ebafd4d!2sMaharana+Pratap+Polytechnic!5e0!3m2!1sen!2sin!4v1554976095101!5m2!1sen!2sin" width="400" height="300" frameborder="0" style="border:0" allowfullscreen></iframe>
    </div>
    <!-- ################################################################################################ -->
  </footer>
</div>

<!-- ################################################################################################ -->
<div class="wrapper" style="background-color:#1a1a1a; color:#FFFFFF;">
  <div id="copyright" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <p class="fl_left">Copyright &copy; 2020 - All Rights Reserved - <a href="https://mppolytechnic.ac.in"  style="color:#FFFFFF;">MP Polytechnic - Gorakhpur(U.P).</a> </p>
  
    <p class="fl_right">Designed by <a target="_blank" href="https://www.techsrijan.com/"  style="color:#FFFFFF;"style="color:#FFFFFF;" title="Techsrijan Consultancy Services Pvt Ltd">Techsrijan Consultancy Services Pvt Ltd.</a></p>
    <!-- ################################################################################################ -->
  </div>
  
   <center>
<p> Visitor Counter
  

<img src=digits/4/2.gif><img src=digits/4/6.gif><img src=digits/4/7.gif><img src=digits/4/0.gif><img src=digits/4/1.gif><img src=digits/4/3.gif>
  </center>
  
  
  
  
  
  
  

</div>
<!-- ################################################################################################ -->

<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS-->

<script src="js/validate.js"> </script>
<script src="layout/scripts/jquery.min.js"></script> 
<script src="layout/scripts/jquery.backtotop.js"></script>
<script src="layout/scripts/jquery.mobilemenu.js"></script>
<script src="layout/scripts/jquery.flexslider-min.js"></script>
<script src="js/bootstrap.min.js"> </script>
</body>
</html>