<!DOCTYPE html>
<html lang="en">
<head>
<title>MAHARANA PRATAP POLYTECHNIC - GORAKHPUR U.P. INDIA</title>
<link rel="shortcut icon" href="images/favicon.ico">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="author" content="www.mppolytechnic.ac.in">

<meta name="description" content=" Maharana Pratap Polytechnic Gorakhpur (UP) India is Aided Polytechnic Affiliated to Board of Technical education Uttar Pradesh and approved By AICTE which provides Diploma in Engineering in Mechanical,Civil,Electrical,Computer Science, Electronics and Architectural Assitantship  established in 1956." data-react-helmet="true" />

<meta name="keywords" content="mppolytechnic,mppolytechnic gorakhpur,Maharana Pratap Polytechnic Gorakhpur (UP),Aided Polytechnic in Uttar Pradesh, Diploma in computer Science|Electronics Engineering | Electrical enginnering | Mechanical engineering | Civil engineering, Board of Technical Education, Polytechnic in Gorakhpur,List of Polytechnic in Uttar Pradesh " data-react-helmet="true" />

<meta name="geo.region" content="IN-UP" />
<meta name="geo.placename" content="MP Polytechnic GORAKHPUR" />
<meta name="geo.position" content="22.351115;78.667743" />
<meta name="ICBM" content="22.351115, 78.667743" />



<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" media="all">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
<link href="css/animate.min.css" rel="stylesheet" type="text/css" media="all">
<link href="https://fonts.googleapis.com/css?family=Work+Sans" rel="stylesheet">

<!--<script src="js/sb-admin-datatables.min.js"></script>-->
<style>
#mainav a{
text-decoration:none;
}
*{
font-family: 'Work Sans', sans-serif;
margin:0px;
padding:0px;
}
#phone{
font-size:16px;
}
@media (max-width: 991px){
#gov {
display:none;
 
	}
	}
</style>
<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.HORIZONTAL}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>


<script type="text/javascript">
    $(window).on('load',function(){
        $('#myModal').modal('show');
    });
</script>
</head>
<body id="top">

<div class="wrapper row0">
  <div id="topbar" class="hoc clear"> 
   
    <div class="fl_left">
      <ul class="nospace inline pushright">
   <li><i class="fa fa-envelope-o" style="color:#FFFF33;font-size:20px;"></i> <span style="font-size:20px;">mppolygorakhpur@rediffmail.com</span></li>
       <!--<li><i class="fa fa-phone" style="color:#3a9fe5;font-size:20px;"></i> <span style="font-size:20px;">+91 888 766 7635</span></li>
       <li><strong>A GOVERNMENT POLYTECHNIC (U.P) INDIA</strong></li>-->
               <li> <div id="google_translate_element"></div></li>

         
      </ul>
    </div>
    <div class="fl_right">
      <ul class="faico clear">
        <li><i class="fa fa-phone" style="color:#FFFF33;font-size:20px;"></i> <span style="font-size:20px;">0551 2255551</span></li>
         <li><a href="https://www.facebook.com/mppolygkp" target="_blank" style="color:#3b5998;font-size:25px;"><i class="fa fa-facebook"></i></a></li>
    </ul>
    </div>
    
  </div>
</div>
<!-- ################################################################################################ -->

<div class="wrapper row1">
  <header id="header"> 
 
    <div  class="row" id="logo" >
    <div class="col-lg-8 col-12">
      <a href="index.php"><img src="images/new-mpp.png" class="img-fluid"></a>
    </div>
    
    <div class="col-lg-4 col-12" id="gov">
    
      <a href="#" target="_blank"><img src="images/logo/mahant-circle.png" class="img-fluid"></a>


         </div>
         
    <!--<div class="col-lg-2 col-6" >
          <a href="https://swachhbharatmission.gov.in" target="_blank" ><img src="images/logo/swach-bharat-logo.png" class="img-fluid"></a>    </div>-->
   
 </div>
 
   
  </header>
</div>
<!-- ################################################################################################ -->


<!--<div class="wrapper row2" style="font-size:12px;">-->
<nav class="navbar  navbar-expand-lg  sticky-top row2" >
   <a class="navbar-brand" href="index.php" style="color:#FFFFFF;"><i class="fa fa-institution"></i> </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"><i class="fa fa-navicon"></i></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav" style="color:#FFFFFF;"> 
    <ul class="navbar-nav">
    <li class="nav-item active">
      <a class="nav-item nav-link active" href="index.php" style="color:#FFFFFF;">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="about-us.php" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          About Us
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="about-us.php">About Institute</a>
          <a class="dropdown-item" href="mission-vision.php">Mission &#038; Vision</a>
          <a class="dropdown-item" href="principal-msg.php">Principal’s Message</a>
          <a class="dropdown-item" href="#">Rules and Regulations</a>
          <a class="dropdown-item" href="#">Infrastructure</a>
          
        </div>
      </li>
            <li class="nav-item dropdown">
                  <!--     <a class="nav-item nav-link active" href="commitee.php" style="color:#FFFFFF;">Governance</span></a>-->
  <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Governance
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="chairman.php">List of Chairman</a>
          <a class="dropdown-item" href="List-of-principal.php">List of Principal</a>
          <a class="dropdown-item" href="commitee.php">List of Committee</a>
       </div>
   <!--  <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Governance
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="principal-msg.php">Principal</a>
          <a class="dropdown-item" href="commitee.php">Academic Committee</a>
          <a class="dropdown-item" href="finance-commitee.php">Finance Committee</a>
          <a class="dropdown-item" href="aicte-commitee.php">AICTE Committee</a>
          <a class="dropdown-item" href="scholarship-commitee.php">Scholarship Committee</a>
          <a class="dropdown-item" href="sport-commitee.php">Sports Committee</a>
          <a class="dropdown-item" href="proctorial-commitee.php">Proctorial Committee</a>
          <a class="dropdown-item" href="security-commitee.php">Security &amp; Gardening Committee</a>
          <a class="dropdown-item" href="tnp-commitee.php">Training &#038; Placement Committee</a>
       </div>-->
      </li>
        <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          AICTE
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            


     <a href="attachment/EOA_AICTE/EOA_Report_2019-20.PDF" target="_blank" class="dropdown-item">EOA Letter</a>

           <a class="dropdown-item" href="#"></a>
       </div>
      </li>
      <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Academics
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="academic-programmes.php">Academic Programmes</a>
          
          <a class="dropdown-item" href="syllabus.php">Syllabus</a>
           <a class="dropdown-item" href="online-study-material.php">Study Material</a>
          <a class="dropdown-item" href="admission.php">Admissions</a>
          <a class="dropdown-item" href="fee-structure.php">Fees Structure</a>
           


        </div>
      </li>
     

      <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Departments
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
        <a class="dropdown-item" href="civil-department.php">Civil Engineering</a>
         <a class="dropdown-item" href="electrical-department.php">Electrical Engineering</a>
          <a class="dropdown-item" href="mechanical-department.php">Mechanical (Production)</a>
           <a class="dropdown-item" href="mechanical-cad-department.php">Mechanical (CAD)</a>
         <a class="dropdown-item" href="computer-science-department.php">Computer Science &amp; Engineering</a>
           <a class="dropdown-item" href="electronics-department.php">Electronics Engineering</a>
             <a class="dropdown-item" href="architecture-department.php">Architectural Assistantship</a>
          
                    <a class="dropdown-item" href="marketing-sales-management.php">Marketing &amp; Sales Management</a>

      
          
        </div>
      </li>
    
      <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Training &#038; Placement
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
        <a class="dropdown-item" href="#">Training Statistics</a>
          <a class="dropdown-item" href="#">Placement Statistics</a>
          <a class="dropdown-item" href="single-student-placement.php">Placed Students Details</a>
          <a class="dropdown-item" href="#">Recruiting Partners</a>
         
        </div>
      </li>
     
      <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Facilities &#038; Resources
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="hostel.php">Hostels</a>
          <a class="dropdown-item" href="library.php">Central Library</a>
          <a class="dropdown-item" href="sport.php">Sport &#038; Atheletics</a>
          <a class="dropdown-item" href="seminar.php">Auditorium &#038; Seminar Halls</a>
           <a class="dropdown-item" href="power.php">24*7 Power Supply</a>
          
        </div>
      </li>
    
     <!-- <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="#" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Alumni
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="alumni.php">Alumni Registration</a>
       </div>
      </li>
      <li class="nav-item active">
      <a class="nav-item nav-link" href="alumni.php" style="color:#FFFFFF;">Alumni</span></a>
      </li>-->
      
      <li class="nav-item dropdown">
     <a class="nav-link dropdown-toggle" href="contact-us.php" style="color:#FFFFFF;" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Contact us
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="contact-us.php">Address</a>
          <a class="dropdown-item" href="map-location.php">Maps &#038; Location</a>
          <a class="dropdown-item" href="phone-directory.php">Phone Directory</a>
          <a class="dropdown-item" href="feedback.php" role="tab" aria-controls="settings">Feedback / Query</a>
       </div>
      </li>
   </ul>
    </div>
  </div>
</nav>
<!--</div>-->
    <!-- ################################################################################################ -->
    <div>
    
    


    
    </div>
    <!-- ################################################################################################ -->

<style>
.btn{
padding:2px;
}

div.polaroid {
  width: 100%;
  background-color: white;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  margin-bottom: 25px;
  margin-top: 25px;
}

div.container {
  text-align: center;
  padding: 10px 20px;
}


</style>
<div class=" container-fluid row3" style="padding:20px;">
<div class="row">
  <div class="col-lg-3">
    <div class="list-group" id="list-tab" role="tablist">
      <a class="list-group-item list-group-item-action " id="list-hostel-list" data-toggle="list" href="#list-hostel" role="tab" aria-controls="home">Hostels</a>
                  <a class="list-group-item list-group-item-action " id="list-library-list" data-toggle="list" href="#list-library" role="tab" aria-controls="home">Central Library</a>

      <a class="list-group-item list-group-item-action active" id="list-sport-list" data-toggle="list" href="#list-sport" role="tab" aria-controls="profile">Sport &#038; Atheletics</a>
      <a class="list-group-item list-group-item-action" id="list-hall-list" data-toggle="list" href="#list-hall" role="tab" aria-controls="messages">Auditorium &#038; Seminar Halls</a>
       <a class="list-group-item list-group-item-action" id="list-power-list" data-toggle="list" href="#list-power" role="tab" aria-controls="settings">24*7 Power Supply</a>
      
    </div>
  </div>
  <div class="col-lg-9">
  
    <div class="tab-content" id="nav-tabContent">
      <div class="tab-pane fade" id="list-hostel" role="tabcard" aria-labelledby="list-hostel-list">
      <div class="row">
   <div class="col-lg-12">
      <div class="card">
          <div class="card-heading" style="background-color:#af0202;color:#FFFFFF;">
       <center> <i class="fa fa-bed" style="font-size:36px; color:#ffffff;"></i><font style="font-size:30px;">  <strong>Hostels</strong></font></center>
           </div>
              <div class="card-body ">
                <h2><strong>Maharana Pratap Polytechnic, Gorakhpur is offering residential facility to student.</strong> </h2>
                <strong>Boys Hostel: 3 Seated 40 Rooms.<br>
                Total capacity: 120 Students</strong><br>
         	<!--  <div class="row">
<div class="col-lg-3">
<div class="polaroid" id="pic-show">
<a href="images/hostel/DSC_0049.jpg" target="_blank"><img class="img-fluid"  src="images/hostel/DSC_0049.jpg"  alt="Post" /></a>


</div>
</div>
<div class="col-lg-3">
<div class="polaroid" id="pic-show">
<a href="images/hostel/DSC_0051.jpg" target="_blank"><img class="img-fluid"  src="images/hostel/DSC_0051.jpg"  alt="Post" /></a>


</div>
</div>
<div class="col-lg-3">
<div class="polaroid" id="pic-show">
<a href="images/hostel/DSC_0052.jpg" target="_blank"><img class="img-fluid"  src="images/hostel/DSC_0052.jpg"  alt="Post" /></a>


</div>
</div>
<div class="col-lg-3">
<div class="polaroid" id="pic-show">
<a href="images/hostel/DSC_0053.jpg" target="_blank"><img class="img-fluid"  src="images/hostel/DSC_0053.jpg"  alt="Post" /></a>


</div>
</div>
</div>--><!---->
              </div>
      
      </div>
   </div>
</div>
      </div><!---Firrst aab closed here-->
      
      <div class="tab-pane fade " id="list-library" role="tabcard" aria-labelledby="list-library-list">

       <div class="row">
   <div class="col-lg-12">
      <div class="card">
          <div class="card-heading" style="background-color:#af0202;color:#FFFFFF;">
       <center> <i class="fa fa-book" style="font-size:36px; color:#ffffff;"></i><font style="font-size:30px;">  <strong>Central Library</strong></font></center>
           </div>
              <div class="card-body ">
                <strong>Maharana Pratap Polytechnic has approximatialy 19500 books of diploma technical level & also many reference books for upper technical level</strong>
      <!---->  <div class="row">
<div class="col-lg-3">
<div class="polaroid" id="pic-show">
<a href="images/library/DSC_0100.jpg" target="_blank"><img class="img-fluid"  src='images/library/DSC_0100.jpg'  alt="Post" /></a>


</div>
</div>
<div class="col-lg-3">
<div class="polaroid" id="pic-show">
<a href="images/library/DSC_0102.jpg" target="_blank"><img class="img-fluid"  src="images/library/DSC_0102.jpg"  alt="Post" /></a>


</div>
</div>
<div class="col-lg-3">
<div class="polaroid" id="pic-show">
<a href="images/library/DSC_0103.jpg" target="_blank"><img class="img-fluid"  src="images/library/DSC_0103.jpg"  alt="Post" /></a>


</div>
</div>
<div class="col-lg-3">
<div class="polaroid" id="pic-show">
<a href="images/library/DSC_0106.jpg" target="_blank"><img class="img-fluid"  src="images/library/DSC_0106.jpg"  alt="Post" /></a>


</div>
</div>
</div><!---->
              </div>
      
      </div>
   </div>
</div>
      
    </div><!---second aab closed here-->
      <div class="tab-pane fade  show active" id="list-sport" role="tabcard" aria-labelledby="list-sport-list">

      <!---------->
      <div class="row">
    <div class="col-lg-12">
    <div class="card">
          <div class="card-heading" style="background-color:#af0202;color:#FFFFFF;">
          <center> <i class="fa fa-child" style="font-size:36px; color:#ffffff;"></i><font style="font-size:30px;"><strong>&nbsp; Sports & Games </strong></font></center>
           </div>
              <div class="card-body ">
       
        <div class="row">
   

 
	
	<div class="col-lg-3">
<div class="polaroid" id="pic-show">					<a href="gallery/SPORTS/IMG_7923.jpg" target="_blank"><img class="img-fluid"  src="gallery/SPORTS/IMG_7923.jpg"  alt="Post" /></a>
							
						<div class="container">
  <p style="text-transform: uppercase;"><strong>Zonal Game Maharana Pratap Polytechnic, Gorakhpur - 2019</strong></p>
  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-3">
<div class="polaroid" id="pic-show">					<a href="gallery/SPORTS/IMG_7931.jpg" target="_blank"><img class="img-fluid"  src="gallery/SPORTS/IMG_7931.jpg"  alt="Post" /></a>
							
						<div class="container">
  <p style="text-transform: uppercase;"><strong>Zonal Game Maharana Pratap Polytechnic, Gorakhpur - 2019</strong></p>
  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-3">
<div class="polaroid" id="pic-show">					<a href="gallery/SPORTS/IMG_7933.jpg" target="_blank"><img class="img-fluid"  src="gallery/SPORTS/IMG_7933.jpg"  alt="Post" /></a>
							
						<div class="container">
  <p style="text-transform: uppercase;"><strong>Zonal Game Maharana Pratap Polytechnic, Gorakhpur - 2019</strong></p>
  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-3">
<div class="polaroid" id="pic-show">					<a href="gallery/SPORTS/IMG_7937.jpg" target="_blank"><img class="img-fluid"  src="gallery/SPORTS/IMG_7937.jpg"  alt="Post" /></a>
							
						<div class="container">
  <p style="text-transform: uppercase;"><strong>Zonal Game Maharana Pratap Polytechnic, Gorakhpur - 2019</strong></p>
  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-3">
<div class="polaroid" id="pic-show">					<a href="gallery/SPORTS/IMG_7948.jpg" target="_blank"><img class="img-fluid"  src="gallery/SPORTS/IMG_7948.jpg"  alt="Post" /></a>
							
						<div class="container">
  <p style="text-transform: uppercase;"><strong>Zonal Game Maharana Pratap Polytechnic, Gorakhpur - 2019</strong></p>
  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-3">
<div class="polaroid" id="pic-show">					<a href="gallery/SPORTS/IMG_7966.jpg" target="_blank"><img class="img-fluid"  src="gallery/SPORTS/IMG_7966.jpg"  alt="Post" /></a>
							
						<div class="container">
  <p style="text-transform: uppercase;"><strong>Zonal Game Maharana Pratap Polytechnic, Gorakhpur - 2019</strong></p>
  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-3">
<div class="polaroid" id="pic-show">					<a href="gallery/SPORTS/IMG_7968.jpg" target="_blank"><img class="img-fluid"  src="gallery/SPORTS/IMG_7968.jpg"  alt="Post" /></a>
							
						<div class="container">
  <p style="text-transform: uppercase;"><strong>Zonal Game Maharana Pratap Polytechnic, Gorakhpur - 2019</strong></p>
  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-3">
<div class="polaroid" id="pic-show">					<a href="gallery/SPORTS/IMG_7973.jpg" target="_blank"><img class="img-fluid"  src="gallery/SPORTS/IMG_7973.jpg"  alt="Post" /></a>
							
						<div class="container">
  <p style="text-transform: uppercase;"><strong>Zonal Game Maharana Pratap Polytechnic, Gorakhpur - 2019</strong></p>
  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-3">
<div class="polaroid" id="pic-show">					<a href="gallery/SPORTS/IMG_7978.jpg" target="_blank"><img class="img-fluid"  src="gallery/SPORTS/IMG_7978.jpg"  alt="Post" /></a>
							
						<div class="container">
  <p style="text-transform: uppercase;"><strong>Zonal Game Maharana Pratap Polytechnic, Gorakhpur - 2019</strong></p>
  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-3">
<div class="polaroid" id="pic-show">					<a href="gallery/SPORTS/IMG_7986.jpg" target="_blank"><img class="img-fluid"  src="gallery/SPORTS/IMG_7986.jpg"  alt="Post" /></a>
							
						<div class="container">
  <p style="text-transform: uppercase;"><strong>Zonal Game Maharana Pratap Polytechnic, Gorakhpur - 2019</strong></p>
  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-3">
<div class="polaroid" id="pic-show">					<a href="gallery/SPORTS/IMG_7993.jpg" target="_blank"><img class="img-fluid"  src="gallery/SPORTS/IMG_7993.jpg"  alt="Post" /></a>
							
						<div class="container">
  <p style="text-transform: uppercase;"><strong>Zonal Game Maharana Pratap Polytechnic, Gorakhpur - 2019</strong></p>
  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-3">
<div class="polaroid" id="pic-show">					<a href="gallery/SPORTS/IMG_7997.jpg" target="_blank"><img class="img-fluid"  src="gallery/SPORTS/IMG_7997.jpg"  alt="Post" /></a>
							
						<div class="container">
  <p style="text-transform: uppercase;"><strong>Zonal Game Maharana Pratap Polytechnic, Gorakhpur - 2019</strong></p>
  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-3">
<div class="polaroid" id="pic-show">					<a href="gallery/SPORTS/IMG_7999.jpg" target="_blank"><img class="img-fluid"  src="gallery/SPORTS/IMG_7999.jpg"  alt="Post" /></a>
							
						<div class="container">
  <p style="text-transform: uppercase;"><strong>Zonal Game Maharana Pratap Polytechnic, Gorakhpur - 2019</strong></p>
  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-3">
<div class="polaroid" id="pic-show">					<a href="gallery/SPORTS/IMG_8008.jpg" target="_blank"><img class="img-fluid"  src="gallery/SPORTS/IMG_8008.jpg"  alt="Post" /></a>
							
						<div class="container">
  <p style="text-transform: uppercase;"><strong>Zonal Game Maharana Pratap Polytechnic, Gorakhpur - 2019</strong></p>
  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-3">
<div class="polaroid" id="pic-show">					<a href="gallery/SPORTS/IMG_8011.jpg" target="_blank"><img class="img-fluid"  src="gallery/SPORTS/IMG_8011.jpg"  alt="Post" /></a>
							
						<div class="container">
  <p style="text-transform: uppercase;"><strong>Zonal Game Maharana Pratap Polytechnic, Gorakhpur - 2019</strong></p>
  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-3">
<div class="polaroid" id="pic-show">					<a href="gallery/SPORTS/IMG_8039.jpg" target="_blank"><img class="img-fluid"  src="gallery/SPORTS/IMG_8039.jpg"  alt="Post" /></a>
							
						<div class="container">
  <p style="text-transform: uppercase;"><strong>Zonal Game Maharana Pratap Polytechnic, Gorakhpur - 2019</strong></p>
  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-3">
<div class="polaroid" id="pic-show">					<a href="gallery/SPORTS/IMG_8120.jpg" target="_blank"><img class="img-fluid"  src="gallery/SPORTS/IMG_8120.jpg"  alt="Post" /></a>
							
						<div class="container">
  <p style="text-transform: uppercase;"><strong>Zonal Game Maharana Pratap Polytechnic, Gorakhpur - 2019</strong></p>
  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-3">
<div class="polaroid" id="pic-show">					<a href="gallery/SPORTS/IMG_8143.jpg" target="_blank"><img class="img-fluid"  src="gallery/SPORTS/IMG_8143.jpg"  alt="Post" /></a>
							
						<div class="container">
  <p style="text-transform: uppercase;"><strong>Zonal Game Maharana Pratap Polytechnic, Gorakhpur - 2019</strong></p>
  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-3">
<div class="polaroid" id="pic-show">					<a href="gallery/SPORTS/IMG_8145.jpg" target="_blank"><img class="img-fluid"  src="gallery/SPORTS/IMG_8145.jpg"  alt="Post" /></a>
							
						<div class="container">
  <p style="text-transform: uppercase;"><strong>Zonal Game Maharana Pratap Polytechnic, Gorakhpur - 2019</strong></p>
  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-3">
<div class="polaroid" id="pic-show">					<a href="gallery/SPORTS/IMG_8147.jpg" target="_blank"><img class="img-fluid"  src="gallery/SPORTS/IMG_8147.jpg"  alt="Post" /></a>
							
						<div class="container">
  <p style="text-transform: uppercase;"><strong>Zonal Game Maharana Pratap Polytechnic, Gorakhpur - 2019</strong></p>
  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-3">
<div class="polaroid" id="pic-show">					<a href="gallery/SPORTS/IMG_8174.jpg" target="_blank"><img class="img-fluid"  src="gallery/SPORTS/IMG_8174.jpg"  alt="Post" /></a>
							
						<div class="container">
  <p style="text-transform: uppercase;"><strong>Zonal Game Maharana Pratap Polytechnic, Gorakhpur - 2019</strong></p>
  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-3">
<div class="polaroid" id="pic-show">					<a href="gallery/SPORTS/IMG_8192.jpg" target="_blank"><img class="img-fluid"  src="gallery/SPORTS/IMG_8192.jpg"  alt="Post" /></a>
							
						<div class="container">
  <p style="text-transform: uppercase;"><strong>Zonal Game Maharana Pratap Polytechnic, Gorakhpur - 2019</strong></p>
  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-3">
<div class="polaroid" id="pic-show">					<a href="gallery/SPORTS/IMG_8200.jpg" target="_blank"><img class="img-fluid"  src="gallery/SPORTS/IMG_8200.jpg"  alt="Post" /></a>
							
						<div class="container">
  <p style="text-transform: uppercase;"><strong>Zonal Game Maharana Pratap Polytechnic, Gorakhpur - 2019</strong></p>
  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-3">
<div class="polaroid" id="pic-show">					<a href="gallery/SPORTS/IMG_8204.jpg" target="_blank"><img class="img-fluid"  src="gallery/SPORTS/IMG_8204.jpg"  alt="Post" /></a>
							
						<div class="container">
  <p style="text-transform: uppercase;"><strong>Zonal Game Maharana Pratap Polytechnic, Gorakhpur - 2019</strong></p>
  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-3">
<div class="polaroid" id="pic-show">					<a href="gallery/SPORTS/IMG_8246.jpg" target="_blank"><img class="img-fluid"  src="gallery/SPORTS/IMG_8246.jpg"  alt="Post" /></a>
							
						<div class="container">
  <p style="text-transform: uppercase;"><strong>Zonal Game Maharana Pratap Polytechnic, Gorakhpur - 2019</strong></p>
  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-3">
<div class="polaroid" id="pic-show">					<a href="gallery/SPORTS/IMG_8255.jpg" target="_blank"><img class="img-fluid"  src="gallery/SPORTS/IMG_8255.jpg"  alt="Post" /></a>
							
						<div class="container">
  <p style="text-transform: uppercase;"><strong>Zonal Game Maharana Pratap Polytechnic, Gorakhpur - 2019</strong></p>
  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-3">
<div class="polaroid" id="pic-show">					<a href="gallery/SPORTS/IMG_8263.jpg" target="_blank"><img class="img-fluid"  src="gallery/SPORTS/IMG_8263.jpg"  alt="Post" /></a>
							
						<div class="container">
  <p style="text-transform: uppercase;"><strong>Zonal Game Maharana Pratap Polytechnic, Gorakhpur - 2019</strong></p>
  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-3">
<div class="polaroid" id="pic-show">					<a href="gallery/SPORTS/IMG_8316.jpg" target="_blank"><img class="img-fluid"  src="gallery/SPORTS/IMG_8316.jpg"  alt="Post" /></a>
							
						<div class="container">
  <p style="text-transform: uppercase;"><strong>Zonal Game Maharana Pratap Polytechnic, Gorakhpur - 2019</strong></p>
  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-3">
<div class="polaroid" id="pic-show">					<a href="gallery/SPORTS/IMG_8362.jpg" target="_blank"><img class="img-fluid"  src="gallery/SPORTS/IMG_8362.jpg"  alt="Post" /></a>
							
						<div class="container">
  <p style="text-transform: uppercase;"><strong>Zonal Game Maharana Pratap Polytechnic, Gorakhpur - 2019</strong></p>
  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-3">
<div class="polaroid" id="pic-show">					<a href="gallery/SPORTS/IMG_8795.jpg" target="_blank"><img class="img-fluid"  src="gallery/SPORTS/IMG_8795.jpg"  alt="Post" /></a>
							
						<div class="container">
  <p style="text-transform: uppercase;"><strong>Zonal Game Maharana Pratap Polytechnic, Gorakhpur - 2019</strong></p>
  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-3">
<div class="polaroid" id="pic-show">					<a href="gallery/SPORTS/IMG_8801.jpg" target="_blank"><img class="img-fluid"  src="gallery/SPORTS/IMG_8801.jpg"  alt="Post" /></a>
							
						<div class="container">
  <p style="text-transform: uppercase;"><strong>Zonal Game Maharana Pratap Polytechnic, Gorakhpur - 2019</strong></p>
  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-3">
<div class="polaroid" id="pic-show">					<a href="gallery/SPORTS/IMG_8809.jpg" target="_blank"><img class="img-fluid"  src="gallery/SPORTS/IMG_8809.jpg"  alt="Post" /></a>
							
						<div class="container">
  <p style="text-transform: uppercase;"><strong>Zonal Game Maharana Pratap Polytechnic, Gorakhpur - 2019</strong></p>
  </div>
	</div>					
			</div>		
                 
	
	<div class="col-lg-3">
<div class="polaroid" id="pic-show">					<a href="gallery/SPORTS/IMG_9154.jpg" target="_blank"><img class="img-fluid"  src="gallery/SPORTS/IMG_9154.jpg"  alt="Post" /></a>
							
						<div class="container">
  <p style="text-transform: uppercase;"><strong>Zonal Game Maharana Pratap Polytechnic, Gorakhpur - 2019</strong></p>
  </div>
	</div>					
			</div>		
                          
    </div>
    </div>
 </div>
   </div>
   </div>
  
      <!----->
      
    </div><!---second aab closed here-->
      <div class="tab-pane fade" id="list-hall" role="tabcard" aria-labelledby="list-hall-list">
      
        <div class="row">
   <div class="col-lg-12">
      <div class="card">
          <div class="card-heading" style="background-color:#af0202;color:#FFFFFF;">
       <center> <i class="fa fa-home" style="font-size:36px; color:#ffffff;"></i><font style="font-size:30px;">  <strong>Auditorium &#038; Seminar Halls</strong></font></center>
           </div>
              <div class="card-body ">
                <h1><strong>UNDER CONSTRUCTION.</strong></h1>
              </div>
      
      </div>
   </div>
</div>
      


      
      
      </div><!---thiirrds aab closed here-->
      
      <!----->
      <!---second aab closed here-->
      <div class="tab-pane fade" id="list-power" role="tabcard" aria-labelledby="list-power-list">
      

    <div class="row">
   <div class="col-lg-12">
      <div class="card">
          <div class="card-heading" style="background-color:#af0202;color:#FFFFFF;">
       <center> <i class="fa fa-clock-o" style="font-size:36px; color:#ffffff;"></i><font style="font-size:30px;">  <strong>24*7 Power Supply</strong></font></center>
           </div>
              <div class="card-body ">
                <!--   <strong>We have 24*7 Power Supply in our College As our SunRoof's Installed Solar Panels Generated Sufficient Amount of Power Supply for our Huge Campus. </strong>
 <div class="row">
<div class="col-lg-12">
<div class="polaroid" id="pic-show">
<a href="images/slider/new-slide2.jpg" target="_blank"><img class="img-fluid"  src='images/slider/new-slide2.jpg'  alt="Post" /></a>


</div>
</div>

</div>   -->
              </div>
   
      </div>
   </div>
</div>
      
      
      </div><!----end here--->
     
          	
    </div>
  </div>
</div>

</div>
</div>



<div class="wrapper" style="color:#ffffff;background-color:#010101; border-bottom: 3px solid #FFFFFF;" class=" animate-box fadeInUp animated">
  <footer id="footer" class="hoc clear" > 
    <!-- ################################################################################################ -->
    <div class="one_third first">
      <h6 class="title"  style="color:#FFFFFF">CONTACT US</h6>
      <ul class="nospace linklist contact">
        <li><i class="fa fa-map-marker"></i>
          <address>
          Sonauli Road, Gorakhnath,Gorakhpur, U.P - 273015
          </address>
        </li>
        <li><i class="fa fa-phone"></i> 0551 225 5551<br>
        
        <li><i class="fa fa-envelope-o"></i> mppolygorakhpur@rediffmail.com</li>
      </ul>
    </div>
    
    <div class="one_third">
      <h6 class="title"  style="color:#FFFFFF">CURRICULAR ACTIVITIES</h6>
       <ul class="nospace linklist contact">
       <li><img src="images/new_red.gif">  <a href="ncc-gallery.php"  style="color:#FFFFFF;" >NCC</a></li>
         <li> <img src="images/new_red.gif">  <a href="Cultural-Programme.php"  style="color:#FFFFFF;" >Cultural Programme</a></li>
       <li> <img src="images/new_red.gif">  <a href="Sports-Games.php"  style="color:#FFFFFF;" >Sports & Games</a></li>
       <li> <img src="images/new_red.gif">  <a href="News-Events.php"  style="color:#FFFFFF;" >News & Events</a></li>

       </ul>
    </div>
    
    <div class="one_third">
    <h6 class="title"  style="color:#FFFFFF">REACH OUT HERE</h6>
     <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3561.8977588410266!2d83.35591823938272!3d26.77952881370108!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x399144352e291fd5%3A0x325bdd828ebafd4d!2sMaharana+Pratap+Polytechnic!5e0!3m2!1sen!2sin!4v1554976095101!5m2!1sen!2sin" width="400" height="300" frameborder="0" style="border:0" allowfullscreen></iframe>
    </div>
    <!-- ################################################################################################ -->
  </footer>
</div>

<!-- ################################################################################################ -->
<div class="wrapper" style="background-color:#1a1a1a; color:#FFFFFF;">
  <div id="copyright" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <p class="fl_left">Copyright &copy; 2020 - All Rights Reserved - <a href="https://mppolytechnic.ac.in"  style="color:#FFFFFF;">MP Polytechnic - Gorakhpur(U.P).</a> </p>
  
    <p class="fl_right">Designed by <a target="_blank" href="https://www.techsrijan.com/"  style="color:#FFFFFF;"style="color:#FFFFFF;" title="Techsrijan Consultancy Services Pvt Ltd">Techsrijan Consultancy Services Pvt Ltd.</a></p>
    <!-- ################################################################################################ -->
  </div>
  
   <center>
<p> Visitor Counter
  

<img src=digits/4/2.gif><img src=digits/4/6.gif><img src=digits/4/7.gif><img src=digits/4/0.gif><img src=digits/4/2.gif><img src=digits/4/2.gif>
  </center>
  
  
  
  
  
  
  

</div>
<!-- ################################################################################################ -->

<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS-->

<script src="js/validate.js"> </script>
<script src="layout/scripts/jquery.min.js"></script> 
<script src="layout/scripts/jquery.backtotop.js"></script>
<script src="layout/scripts/jquery.mobilemenu.js"></script>
<script src="layout/scripts/jquery.flexslider-min.js"></script>
<script src="js/bootstrap.min.js"> </script>
</body>
</html>